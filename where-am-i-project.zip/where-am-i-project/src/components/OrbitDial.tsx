interface Props {
  percentile: number;
  active: boolean;
}

export default function OrbitDial({ percentile, active }: Props) {
  const size = 300;
  const c = size / 2;
  const maxR = 132;
  const radiusFor = (p: number) => 12 + maxR * Math.pow(p / 100, 1.55);
  const rings = [10, 30, 50, 70, 90, 99];
  const userR = radiusFor(percentile);
  const angle = -40;

  return (
    <div className="relative mx-auto" style={{ width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="overflow-visible">
        <defs>
          <radialGradient id="dial-core" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#4C7CFF" stopOpacity="0.9" />
            <stop offset="60%" stopColor="#12224F" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#12224F" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="dial-mark" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#FFF4CE" />
            <stop offset="100%" stopColor="#D4AF37" />
          </radialGradient>
        </defs>

        {rings.map((p) => (
          <circle
            key={p}
            cx={c}
            cy={c}
            r={radiusFor(p)}
            fill="none"
            stroke="#2A3564"
            strokeWidth="1"
            strokeDasharray={p === 99 ? "2 4" : "1 0"}
            opacity={0.55}
          />
        ))}

        <circle cx={c} cy={c} r="26" fill="url(#dial-core)" />
        <circle cx={c} cy={c} r="5" fill="#EAF0FF" />

        <g style={{ transformOrigin: `${c}px ${c}px`, animation: active ? "dial-spin 46s linear infinite" : "none" }}>
          <g transform={`rotate(${angle} ${c} ${c})`}>
            <line x1={c} y1={c} x2={c + userR} y2={c} stroke="#D4AF37" strokeWidth="1" opacity="0.35" />
            <circle
              cx={c + userR}
              cy={c}
              r={active ? 8 : 0}
              fill="url(#dial-mark)"
              style={{ transition: "r 900ms cubic-bezier(.2,.9,.25,1), cx 900ms cubic-bezier(.2,.9,.25,1)" }}
            />
            <circle
              cx={c + userR}
              cy={c}
              r={active ? 14 : 0}
              fill="none"
              stroke="#F2C94C"
              strokeWidth="1"
              opacity="0.5"
              style={{ transition: "r 900ms cubic-bezier(.2,.9,.25,1)" }}
            />
          </g>
        </g>
      </svg>
      <style>{`
        @keyframes dial-spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @media (prefers-reduced-motion: reduce) {
          svg g { animation: none !important; }
        }
      `}</style>
    </div>
  );
}
