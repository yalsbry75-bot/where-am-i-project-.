import { ChangeEvent } from "react";

interface NumberFieldProps {
  label: string;
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
  step?: number;
  suffix?: string;
  hint?: string;
}

export default function NumberField({ label, value, onChange, min = 0, max, step = 1, suffix, hint }: NumberFieldProps) {
  const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
    const parsed = Number(event.target.value);
    onChange(Number.isFinite(parsed) ? parsed : 0);
  };

  return (
    <label className="block">
      <span className="mb-2 flex items-center justify-between gap-3 text-sm font-display font-bold">
        <span>{label}</span>
        {suffix && <span className="text-xs text-muted font-normal">{suffix}</span>}
      </span>
      <input
        type="number"
        inputMode="decimal"
        value={value}
        min={min}
        max={max}
        step={step}
        onChange={handleChange}
        className="w-full rounded-xl border border-line bg-void/70 px-4 py-3 font-num text-ivory outline-none transition focus:border-glow focus:ring-2 focus:ring-glow/20"
      />
      {hint && <span className="mt-1.5 block text-[11px] leading-relaxed text-muted">{hint}</span>}
    </label>
  );
}
