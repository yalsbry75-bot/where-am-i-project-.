/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        void: "#05070F",
        panel: "#12224F",
        glow: "#4C7CFF",
        gold: "#D4AF37",
        goldBright: "#F2C94C",
        ivory: "#F5F1E6",
        muted: "#93A0C4",
        line: "#2A3564",
      },
      fontFamily: {
        display: ["Tajawal", "sans-serif"],
        num: ["Space Grotesk", "sans-serif"],
      },
      boxShadow: {
        glow: "0 0 40px -8px rgba(76,124,255,0.45)",
        gold: "0 0 40px -10px rgba(212,175,55,0.45)",
        premium: "0 20px 60px -20px rgba(0,0,0,0.6)",
        "card-hover": "0 24px 48px -16px rgba(76,124,255,0.25), 0 8px 20px -8px rgba(212,175,55,0.15)",
      },
      keyframes: {
        float: {
          "0%, 100%": { transform: "translateY(0px) translateX(0px)" },
          "50%": { transform: "translateY(-18px) translateX(10px)" },
        },
        "float-slow": {
          "0%, 100%": { transform: "translateY(0px) scale(1)" },
          "50%": { transform: "translateY(14px) scale(1.04)" },
        },
        "fade-up": {
          from: { opacity: 0, transform: "translateY(16px)" },
          to: { opacity: 1, transform: "translateY(0)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
      },
      animation: {
        float: "float 9s ease-in-out infinite",
        "float-slow": "float-slow 13s ease-in-out infinite",
        "fade-up": "fade-up 0.7s cubic-bezier(.2,.8,.2,1) both",
        shimmer: "shimmer 2.5s linear infinite",
      },
    },
  },
  plugins: [],
};
