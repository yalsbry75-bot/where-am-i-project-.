export function registerServiceWorker() {
  if (!("serviceWorker" in navigator)) return;

  // نسجّل بعد اكتمال تحميل الصفحة عشان ما نأخر أول عرض للمحتوى
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch((err) => {
      console.warn("تعذّر تسجيل Service Worker:", err);
    });
  });
}
