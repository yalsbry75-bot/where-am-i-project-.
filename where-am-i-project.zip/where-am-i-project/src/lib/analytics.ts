// ⚠️ هذا نظام تتبّع محلي بالكامل (localStorage) — يُستخدم كواجهة عرض لبيانات وهمية/تجريبية
// حتى يتم ربط المشروع بباكيند حقيقي (Node.js + Express) وقاعدة بيانات (Firebase/Supabase) كما في خطة المرحلة 2.
// بيانات localStorage محصورة بجهاز/متصفح الزائر نفسه — ما تمثّل كل الزوار، وتُفرَّغ لو المستخدم مسح بيانات المتصفح.

export type AnalyticsEvent =
  | { type: "page_view"; page: string }
  | { type: "calculator_used"; calculator: string }
  | { type: "share_click"; calculator: string; platform: string }
  | { type: "country_selected"; countryCode: string; context: string };

interface LoggedEvent {
  event: AnalyticsEvent;
  timestamp: number;
}

const STORAGE_KEY = "waitw_analytics_log";
const MAX_EVENTS = 2000; // سقف عشان ما يتضخم localStorage بلا حدود

export function track(event: AnalyticsEvent) {
  try {
    const log = readLog();
    log.push({ event, timestamp: Date.now() });
    const trimmed = log.length > MAX_EVENTS ? log.slice(log.length - MAX_EVENTS) : log;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(trimmed));
  } catch {
    // نتجاهل بصمت لو localStorage غير متاح (وضع خاص، إلخ)
  }
}

export function readLog(): LoggedEvent[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as LoggedEvent[]) : [];
  } catch {
    return [];
  }
}

export function clearLog() {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    // تجاهل
  }
}

export interface AnalyticsSummary {
  totalEvents: number;
  pageViews: number;
  calculatorUsage: Record<string, number>;
  shareClicks: Record<string, number>;
  topCountries: { code: string; count: number }[];
}

export function summarize(): AnalyticsSummary {
  const log = readLog();
  const calculatorUsage: Record<string, number> = {};
  const shareClicks: Record<string, number> = {};
  const countryCounts: Record<string, number> = {};
  let pageViews = 0;

  for (const { event } of log) {
    if (event.type === "page_view") pageViews++;
    if (event.type === "calculator_used") {
      calculatorUsage[event.calculator] = (calculatorUsage[event.calculator] || 0) + 1;
    }
    if (event.type === "share_click") {
      shareClicks[event.platform] = (shareClicks[event.platform] || 0) + 1;
    }
    if (event.type === "country_selected") {
      countryCounts[event.countryCode] = (countryCounts[event.countryCode] || 0) + 1;
    }
  }

  const topCountries = Object.entries(countryCounts)
    .map(([code, count]) => ({ code, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 8);

  return { totalEvents: log.length, pageViews, calculatorUsage, shareClicks, topCountries };
}
