import { useState, useEffect } from "react";
import { useLocation, Link } from "react-router-dom";
import { useLanguage } from "../i18n/LanguageContext";
import OrbitVisual from "../components/OrbitVisual";
import WhySection from "../components/WhySection";
import CalculatorsSection from "../components/CalculatorsSection";
import FinancialCenterSection from "../components/FinancialCenterSection";
import ResultsShowcase from "../components/ResultsShowcase";
import CtaSection from "../components/CtaSection";
import UserDataForm from "../components/UserDataForm";
import IncomeResultCard from "../components/IncomeResultCard";
import PurchasingPowerSection from "../components/PurchasingPowerSection";
import TimeValueSection from "../components/TimeValueSection";
import CountryComparisonSection from "../components/CountryComparisonSection";
import WellnessAgeSection from "../components/WellnessAgeSection";
import CountryLinksSection from "../components/CountryLinksSection";
import HeroBackground from "../components/HeroBackground";
import HeroStatsBar from "../components/HeroStatsBar";
import PopularToolsSection from "../components/PopularToolsSection";
import Reveal from "../components/Reveal";
import AdSlot from "../components/ads/AdSlot";
import SponsorBanner from "../components/ads/SponsorBanner";
import AffiliateSection from "../components/AffiliateSection";
import PremiumReportCTA from "../components/PremiumReportCTA";
import { useCountries } from "../hooks/useCountries";
import { UserData } from "../types";
import { calculateIncomeResult } from "../lib/incomeCalculator";
import { useSEO } from "../hooks/useSEO";
import { track } from "../lib/analytics";
import { ADSENSE_SLOT_HERO, ADSENSE_SLOT_INLINE } from "../config";

export default function Home() {
  const { t, lang } = useLanguage();
  const COUNTRIES = useCountries();
  const [userData, setUserData] = useState<UserData | null>(null);
  const country = userData ? COUNTRIES.find((c) => c.code === userData.countryCode) : undefined;
  const result = userData && country ? calculateIncomeResult(userData, country) : null;

  useEffect(() => {
    track({ type: "page_view", page: "home" });
  }, []);

  useSEO({
    title:
      lang === "ar"
        ? "أين أنا من العالم؟ | اكتشف مكانك الحقيقي بين سكان العالم"
        : "Where Am I In The World? | Discover your place among the world's population",
    description:
      lang === "ar"
        ? "احسب ترتيب دخلك عالمياً، قوتك الشرائية، وقيمة وقتك — وقارن نفسك بأي دولة في العالم."
        : "Calculate your global income ranking, purchasing power, and time value — and compare yourself to any country in the world.",
    path: "/",
  });

  const location = useLocation();
  useEffect(() => {
    if (location.hash) {
      const el = document.querySelector(location.hash);
      if (el) setTimeout(() => el.scrollIntoView({ behavior: "smooth" }), 100);
    }
  }, [location.hash]);

  return (
    <main className="max-w-5xl mx-auto px-6">
      {/* Hero */}
      <section className="relative pt-16 pb-8 text-center overflow-hidden">
        <HeroBackground />

        <Reveal>
          <p className="font-display text-sm tracking-wide text-gold mb-3">{t.tagline}</p>
          <h1 className="font-display font-extrabold leading-tight text-4xl md:text-6xl bg-gradient-to-b from-ivory to-ivory/70 bg-clip-text text-transparent">
            {t.heroTitle}
          </h1>
          <p className="font-display text-muted mt-4 max-w-xl mx-auto leading-relaxed">
            {t.heroSubtitle}
          </p>

          <div className="flex flex-wrap items-center justify-center gap-3 mt-8">
            <a href="#income-calculator" className="btn-premium-primary">
              {t.ctaStart}
            </a>
            <Link to="/tools" className="btn-premium-secondary">
              {t.heroCtaSecondary}
            </Link>
          </div>
        </Reveal>

        <Reveal delay={150} className="mt-10">
          <HeroStatsBar />
        </Reveal>
      </section>

      <PopularToolsSection />

      <div className="py-6">
        <OrbitVisual />
      </div>

      <div className="max-w-2xl mx-auto mb-4">
        <SponsorBanner />
      </div>

      <WhySection />
      <CalculatorsSection />
      <FinancialCenterSection />
      <ResultsShowcase />

      <div className="max-w-2xl mx-auto mb-4">
        <AdSlot slotId={ADSENSE_SLOT_HERO} label="أعلى الحاسبة" />
      </div>

      {/* حاسبة ترتيب الدخل العالمي — المرحلة 5 */}
      <section id="income-calculator" className="py-10 border-t border-line/40 scroll-mt-8">
        {!userData || !country || !result ? (
          <UserDataForm onSubmit={setUserData} />
        ) : (
          <div>
            <IncomeResultCard result={result} country={country} />
            <AffiliateSection />
            <PremiumReportCTA />
            <button
              onClick={() => setUserData(null)}
              className="block mx-auto mt-6 text-xs font-display text-muted underline hover:text-ivory"
            >
              {t.formEditAgain}
            </button>
          </div>
        )}
      </section>
      <PurchasingPowerSection monthlyUSD={result ? result.monthlyUSD : null} />
      <div className="max-w-2xl mx-auto my-4">
        <AdSlot slotId={ADSENSE_SLOT_INLINE} label="منتصف الصفحة" />
      </div>
      <TimeValueSection monthlyUSD={result ? result.monthlyUSD : null} />
      <CountryComparisonSection defaultCountryCode={country?.code} />
      <WellnessAgeSection />
      <CountryLinksSection />

      <CtaSection />
    </main>
  );
}
