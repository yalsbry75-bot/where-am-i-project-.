import { Briefcase, GraduationCap, Landmark, ExternalLink } from "lucide-react";
import { useLanguage } from "../i18n/LanguageContext";
import { AFFILIATE_LINKS } from "../data/affiliateLinks";
import { track } from "../lib/analytics";

const ICONS = { jobs: Briefcase, education: GraduationCap, finance: Landmark };

export default function AffiliateSection() {
  const { t, lang } = useLanguage();

  return (
    <div className="rounded-2xl p-5 md:p-6 bg-panel/20 border border-line max-w-2xl mx-auto mt-6">
      <p className="font-display font-bold text-sm mb-1">{t.affiliateTitle}</p>
      <p className="text-xs text-muted font-display mb-4">{t.affiliateSubtitle}</p>

      <div className="grid sm:grid-cols-3 gap-3">
        {AFFILIATE_LINKS.map((link) => {
          const Icon = ICONS[link.category];
          return (
            <a
              key={link.id}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer sponsored"
              onClick={() => track({ type: "share_click", calculator: "affiliate", platform: link.id })}
              className="rounded-xl p-4 bg-void/40 border border-line hover:border-glow transition-colors"
            >
              <Icon className="w-4 h-4 text-glow mb-2" />
              <p className="font-display font-bold text-xs mb-1">{lang === "ar" ? link.title : link.titleEn}</p>
              <p className="text-[11px] text-muted font-display leading-relaxed mb-2">
                {lang === "ar" ? link.description : link.descriptionEn}
              </p>
              <span className="text-[10px] text-goldBright font-display flex items-center gap-1">
                {t.affiliateCta}
                <ExternalLink className="w-2.5 h-2.5" />
              </span>
            </a>
          );
        })}
      </div>
      <p className="text-[10px] text-muted/50 font-display mt-3">{t.affiliateDisclosure}</p>
    </div>
  );
}
