import { useState, useEffect } from "react";
import { useLanguage } from "../i18n/LanguageContext";
import { useCountries } from "../hooks/useCountries";
import { compareCountries } from "../lib/countryComparison";
import ShareCard from "./ShareCard";
import { track } from "../lib/analytics";

interface Props {
  defaultCountryCode?: string;
}

export default function CountryComparisonSection({ defaultCountryCode }: Props) {
  const { t, lang } = useLanguage();
  const COUNTRIES = useCountries();
  const [codeA, setCodeA] = useState(defaultCountryCode || COUNTRIES[0].code);
  const [codeB, setCodeB] = useState(
    COUNTRIES.find((c) => c.code !== (defaultCountryCode || COUNTRIES[0].code))!.code
  );

  const countryA = COUNTRIES.find((c) => c.code === codeA)!;
  const countryB = COUNTRIES.find((c) => c.code === codeB)!;
  const cmp = compareCountries(countryA, countryB);

  useEffect(() => {
    track({ type: "calculator_used", calculator: "country_comparison" });
    track({ type: "country_selected", countryCode: codeA, context: "comparison" });
    track({ type: "country_selected", countryCode: codeB, context: "comparison" });
  }, [codeA, codeB]);

  const nameOf = (c: typeof countryA) => (lang === "ar" ? c.name : c.nameEn);

  return (
    <section id="country-comparison" className="py-14 border-t border-line/40 scroll-mt-8">
      <h2 className="font-display font-extrabold text-2xl md:text-3xl text-center mb-2">{t.ccTitle}</h2>
      <p className="text-sm text-muted font-display text-center mb-8">{t.ccSubtitle}</p>

      <div className="max-w-2xl mx-auto grid sm:grid-cols-2 gap-4 mb-8">
        <div>
          <label className="block font-display text-sm text-muted mb-1.5">{t.ccCountryA}</label>
          <select
            value={codeA}
            onChange={(e) => setCodeA(e.target.value)}
            className="w-full font-display bg-void border border-line rounded-xl px-3 py-2.5 outline-none focus:border-gold transition-colors"
          >
            {COUNTRIES.map((c) => (
              <option key={c.code} value={c.code}>
                {nameOf(c)}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block font-display text-sm text-muted mb-1.5">{t.ccCountryB}</label>
          <select
            value={codeB}
            onChange={(e) => setCodeB(e.target.value)}
            className="w-full font-display bg-void border border-line rounded-xl px-3 py-2.5 outline-none focus:border-glow transition-colors"
          >
            {COUNTRIES.map((c) => (
              <option key={c.code} value={c.code}>
                {nameOf(c)}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="max-w-2xl mx-auto space-y-6">
        <ComparisonRow
          title={t.ccAvgSalary}
          nameA={nameOf(countryA)}
          nameB={nameOf(countryB)}
          valueA={countryA.avgMonthlyUSD}
          valueB={countryB.avgMonthlyUSD}
          format={(v) => `$${v.toLocaleString()}`}
        />
        <ComparisonRow
          title={t.ccCostOfLiving}
          nameA={nameOf(countryA)}
          nameB={nameOf(countryB)}
          valueA={countryA.costOfLivingIndex}
          valueB={countryB.costOfLivingIndex}
          format={(v) => `${v}`}
        />
        <div>
          <ComparisonRow
            title={t.ccPurchasingPower}
            nameA={nameOf(countryA)}
            nameB={nameOf(countryB)}
            valueA={cmp.purchasingPowerA}
            valueB={cmp.purchasingPowerB}
            format={(v) => Math.round(v).toString()}
          />
          <p className="text-[11px] text-muted/70 font-display mt-2">{t.ccPurchasingPowerNote}</p>
        </div>

        <div className="grid sm:grid-cols-2 gap-4 pt-2">
          <DiffStat label={t.ccDiffSalary} pct={cmp.salaryDiffPct} />
          <DiffStat label={t.ccDiffPower} pct={cmp.purchasingPowerDiffPct} />
        </div>
      </div>

      <p className="text-[11px] text-muted/70 font-display text-center mt-8">{t.ccNote}</p>

      <ShareCard
        calculator="country_comparison"
        text={
          lang === "ar"
            ? `🌍 قارنت بين ${nameOf(countryA)} و${nameOf(countryB)} — فرق الراتب ${cmp.salaryDiffPct >= 0 ? "+" : ""}${cmp.salaryDiffPct}٪! جرب مقارنتك أنت`
            : `🌍 I compared ${nameOf(countryA)} vs ${nameOf(countryB)} — salary difference ${cmp.salaryDiffPct >= 0 ? "+" : ""}${cmp.salaryDiffPct}%! Try your own comparison`
        }
      />
    </section>
  );
}

function ComparisonRow({
  title,
  nameA,
  nameB,
  valueA,
  valueB,
  format,
}: {
  title: string;
  nameA: string;
  nameB: string;
  valueA: number;
  valueB: number;
  format: (v: number) => string;
}) {
  const max = Math.max(valueA, valueB, 1);
  return (
    <div className="rounded-xl p-4 bg-panel/25 border border-line">
      <p className="font-display font-bold text-sm mb-3">{title}</p>
      <div className="space-y-2.5">
        <div>
          <div className="flex justify-between text-xs font-display text-muted mb-1">
            <span>{nameA}</span>
            <span className="font-num">{format(valueA)}</span>
          </div>
          <div className="h-2.5 rounded-full bg-void/60 overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-700"
              style={{ width: `${(valueA / max) * 100}%`, background: "linear-gradient(90deg,#D4AF37,#F2C94C)" }}
            />
          </div>
        </div>
        <div>
          <div className="flex justify-between text-xs font-display text-muted mb-1">
            <span>{nameB}</span>
            <span className="font-num">{format(valueB)}</span>
          </div>
          <div className="h-2.5 rounded-full bg-void/60 overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-700"
              style={{ width: `${(valueB / max) * 100}%`, background: "linear-gradient(90deg,#2A3564,#4C7CFF)" }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function DiffStat({ label, pct }: { label: string; pct: number }) {
  return (
    <div className="rounded-xl p-4 bg-void/40 border border-line text-center">
      <div className="font-num font-bold text-2xl mb-1" style={{ color: pct >= 0 ? "#8FE3A0" : "#F5A3A3" }}>
        {pct >= 0 ? "+" : ""}
        {pct}٪
      </div>
      <p className="text-xs font-display text-muted">{label}</p>
    </div>
  );
}
