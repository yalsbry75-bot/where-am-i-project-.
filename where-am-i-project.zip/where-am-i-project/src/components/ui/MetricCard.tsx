import { ReactNode } from "react";

interface MetricCardProps {
  label: string;
  value: string;
  note?: string;
  icon?: ReactNode;
  emphasis?: boolean;
}

export default function MetricCard({ label, value, note, icon, emphasis = false }: MetricCardProps) {
  return (
    <div className={`rounded-2xl border p-5 transition duration-300 hover:-translate-y-0.5 ${emphasis ? "border-gold/60 bg-gold/10" : "border-line/80 bg-panel/25"}`}>
      <div className="mb-3 flex items-center justify-between gap-3 text-xs text-muted">
        <span className="font-display">{label}</span>
        {icon}
      </div>
      <div className="font-num text-2xl font-bold tracking-tight text-ivory">{value}</div>
      {note && <p className="mt-2 text-[11px] leading-relaxed text-muted">{note}</p>}
    </div>
  );
}
