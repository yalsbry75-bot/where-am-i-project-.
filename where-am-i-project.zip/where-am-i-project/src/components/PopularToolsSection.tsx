import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { TOOL_REGISTRY } from "../data/toolRegistry";
import { useLanguage } from "../i18n/LanguageContext";
import ToolCard from "./ToolCard";
import Reveal from "./Reveal";

export default function PopularToolsSection() {
  const { lang } = useLanguage();
  const popular = TOOL_REGISTRY.filter((t) => t.featured).slice(0, 6);
  const fallback = popular.length >= 3 ? popular : TOOL_REGISTRY.slice(0, 6);

  return (
    <section className="py-14">
      <Reveal>
        <div className="mb-8 flex items-end justify-between gap-4">
          <div>
            <p className="font-display text-sm text-gold mb-1.5">
              {lang === "ar" ? "الأكثر استخداماً" : "Most used"}
            </p>
            <h2 className="font-display font-extrabold text-2xl md:text-3xl">
              {lang === "ar" ? "الأدوات الشائعة" : "Popular Tools"}
            </h2>
          </div>
          <Link
            to="/tools"
            className="hidden sm:flex items-center gap-1 text-sm font-display text-muted hover:text-gold transition-colors shrink-0"
          >
            {lang === "ar" ? "كل الأدوات" : "All tools"}
            <ArrowLeft className="w-3.5 h-3.5 rtl:rotate-180" />
          </Link>
        </div>
      </Reveal>

      <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
        {fallback.map((tool, i) => (
          <Reveal key={tool.slug} delay={i * 60}>
            <ToolCard tool={tool} />
          </Reveal>
        ))}
      </div>

      <div className="mt-6 text-center sm:hidden">
        <Link to="/tools" className="text-sm font-display text-gold underline">
          {lang === "ar" ? "شوف كل الأدوات" : "See all tools"}
        </Link>
      </div>
    </section>
  );
}
