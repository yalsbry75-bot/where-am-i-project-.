export interface UserData {
  countryCode: string;
  monthlyIncome: number;
  age?: number;
  profession?: string;
  familySize?: number;
}

export interface FormErrors {
  countryCode?: string;
  monthlyIncome?: string;
  age?: string;
  familySize?: string;
}
