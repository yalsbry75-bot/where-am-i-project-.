const WORKDAYS_PER_MONTH = 22;
const WORK_HOURS_PER_DAY = 8;

export interface TimeValue {
  yearly: number;
  monthly: number;
  daily: number;
  hourly: number;
  perMinute: number;
}

export function calculateTimeValue(monthlyUSD: number): TimeValue {
  const daily = monthlyUSD / WORKDAYS_PER_MONTH;
  const hourly = daily / WORK_HOURS_PER_DAY;
  return {
    yearly: monthlyUSD * 12,
    monthly: monthlyUSD,
    daily,
    hourly,
    perMinute: hourly / 60,
  };
}
