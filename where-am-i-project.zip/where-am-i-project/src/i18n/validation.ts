import { UserData, FormErrors } from "../types";
import { Lang } from "./translations";

const messages: Record<Lang, Record<string, string>> = {
  ar: {
    countryRequired: "اختر دولتك من القائمة",
    incomeRequired: "أدخل دخلك الشهري",
    incomeInvalid: "أدخل رقماً أكبر من صفر",
    incomeTooHigh: "الرقم يبدو كبيراً جداً — تأكد من الوحدة المدخلة",
    ageInvalid: "العمر يجب أن يكون بين 1 و120",
    familyInvalid: "عدد الأفراد يجب أن يكون رقماً موجباً",
  },
  en: {
    countryRequired: "Please select your country",
    incomeRequired: "Enter your monthly income",
    incomeInvalid: "Enter a number greater than zero",
    incomeTooHigh: "That number looks too large — check the unit entered",
    ageInvalid: "Age must be between 1 and 120",
    familyInvalid: "Family size must be a positive number",
  },
};

export function validateUserData(
  data: Partial<UserData>,
  lang: Lang
): FormErrors {
  const m = messages[lang];
  const errors: FormErrors = {};

  if (!data.countryCode) {
    errors.countryCode = m.countryRequired;
  }

  if (data.monthlyIncome === undefined || Number.isNaN(data.monthlyIncome)) {
    errors.monthlyIncome = m.incomeRequired;
  } else if (data.monthlyIncome <= 0) {
    errors.monthlyIncome = m.incomeInvalid;
  } else if (data.monthlyIncome > 1_000_000_000) {
    errors.monthlyIncome = m.incomeTooHigh;
  }

  if (data.age !== undefined && !Number.isNaN(data.age)) {
    if (data.age < 1 || data.age > 120) errors.age = m.ageInvalid;
  }

  if (data.familySize !== undefined && !Number.isNaN(data.familySize)) {
    if (data.familySize < 1) errors.familySize = m.familyInvalid;
  }

  return errors;
}
