export default function OrbitVisual() {
  const size = 320;
  const c = size / 2;
  const rings = [40, 70, 100, 130];

  return (
    <div style={{ width: size, height: size }} className="relative mx-auto">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="overflow-visible">
        <defs>
          <radialGradient id="hero-core" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#4C7CFF" stopOpacity="0.9" />
            <stop offset="60%" stopColor="#12224F" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#12224F" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="hero-mark" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#FFF4CE" />
            <stop offset="100%" stopColor="#D4AF37" />
          </radialGradient>
        </defs>

        {rings.map((r) => (
          <circle key={r} cx={c} cy={c} r={r} fill="none" stroke="#2A3564" strokeWidth="1" opacity={0.55} />
        ))}

        <circle cx={c} cy={c} r="28" fill="url(#hero-core)" />
        <circle cx={c} cy={c} r="5" fill="#EAF0FF" />

        <g style={{ transformOrigin: `${c}px ${c}px`, animation: "hero-spin 40s linear infinite" }}>
          <circle cx={c + 130} cy={c} r="7" fill="url(#hero-mark)" />
        </g>
        <g style={{ transformOrigin: `${c}px ${c}px`, animation: "hero-spin 26s linear infinite reverse" }}>
          <circle cx={c + 70} cy={c} r="4" fill="#4C7CFF" />
        </g>
      </svg>
      <style>{`
        @keyframes hero-spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        @media (prefers-reduced-motion: reduce) {
          svg g { animation: none !important; }
        }
      `}</style>
    </div>
  );
}
