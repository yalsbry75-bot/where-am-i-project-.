import { Link } from "react-router-dom";
import { Compass } from "lucide-react";
import { useLanguage } from "../i18n/LanguageContext";
import { useSEO } from "../hooks/useSEO";

export default function NotFound() {
  const { lang } = useLanguage();
  useSEO({ title: lang === "ar" ? "الصفحة غير موجودة | Where Am I" : "Page not found | Where Am I", description: "Page not found", path: "/404" });
  return <main className="mx-auto flex min-h-[65vh] max-w-3xl flex-col items-center justify-center px-6 text-center"><Compass className="mb-5 h-12 w-12 text-gold" /><p className="font-num text-6xl font-bold text-glow">404</p><h1 className="mt-4 font-display text-2xl font-bold">{lang === "ar" ? "هذه الصفحة خارج المدار" : "This page is outside the orbit"}</h1><p className="mt-3 text-sm text-muted">{lang === "ar" ? "الرابط غير موجود أو تم نقله." : "The link does not exist or has moved."}</p><Link to="/" className="mt-7 rounded-xl bg-gold px-5 py-3 text-sm font-bold text-void">{lang === "ar" ? "العودة للرئيسية" : "Back home"}</Link></main>;
}
