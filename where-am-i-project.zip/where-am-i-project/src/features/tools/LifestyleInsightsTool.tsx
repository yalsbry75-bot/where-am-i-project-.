import { useMemo, useState } from "react";
import { Footprints, HeartPulse, MoonStar, UserRound } from "lucide-react";
import NumberField from "../../components/ui/NumberField";
import MetricCard from "../../components/ui/MetricCard";
import DonutGauge from "../../components/charts/DonutGauge";
import AIInsightPanel from "../../components/AIInsightPanel";
import ReportActions from "../../components/ReportActions";
import { calculateLifestyle } from "../../lib/lifestyle";
import { formatNumber } from "../../lib/format";
import { useLanguage } from "../../i18n/LanguageContext";

export default function LifestyleInsightsTool() {
  const { lang } = useLanguage();
  const locale = lang === "ar" ? "ar-SA" : "en-US";
  const [age, setAge] = useState(32);
  const [sleep, setSleep] = useState(7);
  const [activeDays, setActiveDays] = useState(3);
  const [stress, setStress] = useState(5);
  const [water, setWater] = useState(6);
  const [smoker, setSmoker] = useState(false);
  const [restingHours, setRestingHours] = useState(8);
  const result = useMemo(() => calculateLifestyle({ age, sleepHours: sleep, activeDays, stressLevel: stress, waterGlasses: water, smoker, restingHours }, lang), [age, sleep, activeDays, stress, water, smoker, restingHours, lang]);
  const recommendations = useMemo(() => [...result.insights, lang === "ar" ? "أي أعراض أو مخاوف صحية تحتاج تقييماً من مختص صحي." : "Any symptoms or health concerns require assessment by a qualified professional."], [result.insights, lang]);

  return (
    <div className="tool-grid">
      <section className="tool-form-card">
        <h2 className="tool-section-title">{lang === "ar" ? "عاداتك اليومية" : "Daily habits"}</h2>
        <div className="space-y-5">
          <NumberField label={lang === "ar" ? "العمر" : "Age"} value={age} onChange={setAge} min={12} max={100} suffix={lang === "ar" ? "سنة" : "years"} />
          <NumberField label={lang === "ar" ? "ساعات النوم" : "Sleep hours"} value={sleep} onChange={setSleep} min={0} max={16} step={0.5} suffix={lang === "ar" ? "ساعة" : "hours"} />
          <NumberField label={lang === "ar" ? "أيام النشاط أسبوعياً" : "Active days per week"} value={activeDays} onChange={setActiveDays} min={0} max={7} />
          <NumberField label={lang === "ar" ? "مستوى الضغط" : "Stress level"} value={stress} onChange={setStress} min={1} max={10} suffix="/10" />
          <NumberField label={lang === "ar" ? "أكواب الماء يومياً" : "Water glasses per day"} value={water} onChange={setWater} min={0} max={20} />
          <NumberField label={lang === "ar" ? "ساعات الجلوس/الخمول" : "Sedentary hours"} value={restingHours} onChange={setRestingHours} min={0} max={24} />
          <label className="flex items-center gap-3 rounded-xl border border-line bg-void/50 p-3 text-sm"><input type="checkbox" checked={smoker} onChange={(event) => setSmoker(event.target.checked)} className="h-4 w-4 accent-gold" /><span>{lang === "ar" ? "أستخدم منتجات التدخين" : "I use smoking products"}</span></label>
        </div>
      </section>
      <div className="space-y-6 min-w-0">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <MetricCard label={lang === "ar" ? "العمر الحيوي التقديري" : "Estimated biological age"} value={`${formatNumber(result.biologicalAge, locale)} ${lang === "ar" ? "سنة" : "years"}`} icon={<UserRound className="h-4 w-4 text-gold" />} emphasis />
          <MetricCard label={lang === "ar" ? "الدرجة الصحية" : "Health score"} value={`${formatNumber(result.healthScore, locale)}/100`} icon={<HeartPulse className="h-4 w-4 text-glow" />} />
          <MetricCard label={lang === "ar" ? "جودة النوم" : "Sleep quality"} value={`${formatNumber(result.sleepScore, locale)}/100`} icon={<MoonStar className="h-4 w-4 text-glow" />} />
          <MetricCard label={lang === "ar" ? "الخطوات اليومية المقترحة" : "Recommended daily steps"} value={formatNumber(result.recommendedSteps, locale, 0)} icon={<Footprints className="h-4 w-4 text-gold" />} />
        </section>
        <section className="grid gap-4 sm:grid-cols-2"><DonutGauge value={result.healthScore} label={lang === "ar" ? "الدرجة الصحية" : "Health score"} /><DonutGauge value={result.sleepScore} label={lang === "ar" ? "جودة النوم" : "Sleep quality"} /></section>
        <AIInsightPanel tool={lang === "ar" ? "الصحة ونمط الحياة" : "Health & Lifestyle"} metrics={{ age, biologicalAge: result.biologicalAge, healthScore: result.healthScore, sleepScore: result.sleepScore, recommendedSteps: result.recommendedSteps }} additionalInsights={result.insights} />
        <ReportActions toolName="Where Am I Lifestyle Center" title={lang === "ar" ? "تقرير نمط الحياة" : "Lifestyle report"} summary={lang === "ar" ? "قراءة مبسطة للعادات اليومية ومؤشرات الصحة العامة." : "A simplified reading of daily habits and general wellness indicators."} userInfo={[{ label: lang === "ar" ? "العمر" : "Age", value: `${age}` }, { label: lang === "ar" ? "النوم" : "Sleep", value: `${sleep} ${lang === "ar" ? "ساعة" : "hours"}` }, { label: lang === "ar" ? "أيام النشاط" : "Active days", value: `${activeDays}/7` }, { label: lang === "ar" ? "مستوى الضغط" : "Stress level", value: `${stress}/10` }]} metrics={[{ label: lang === "ar" ? "العمر الحيوي" : "Biological age", value: `${formatNumber(result.biologicalAge, locale)} ${lang === "ar" ? "سنة" : "years"}` }, { label: lang === "ar" ? "الدرجة الصحية" : "Health score", value: `${formatNumber(result.healthScore, locale)}/100` }, { label: lang === "ar" ? "جودة النوم" : "Sleep score", value: `${formatNumber(result.sleepScore, locale)}/100` }, { label: lang === "ar" ? "الخطوات" : "Steps", value: formatNumber(result.recommendedSteps, locale, 0) }]} recommendations={recommendations} calculator="lifestyle-insights" />
        <p className="rounded-xl border border-amber-300/20 bg-amber-300/5 p-3 text-[11px] leading-relaxed text-muted">{lang === "ar" ? "هذه الأداة تثقيفية وليست تشخيصاً طبياً ولا بديلاً عن الاستشارة المهنية." : "This tool is educational and is not a medical diagnosis or a substitute for professional care."}</p>
      </div>
    </div>
  );
}
