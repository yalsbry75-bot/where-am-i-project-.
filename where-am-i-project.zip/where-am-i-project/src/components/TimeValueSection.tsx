import { CalendarDays, Calendar, Sun, Clock, Timer, Lock } from "lucide-react";
import { useLanguage } from "../i18n/LanguageContext";
import { calculateTimeValue } from "../lib/timeValue";
import ShareCard from "./ShareCard";
import { useEffect } from "react";
import { track } from "../lib/analytics";

interface Props {
  monthlyUSD: number | null;
}

function formatUSD(v: number): string {
  if (v >= 1) return `$${v.toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
  if (v >= 0.01) return `$${v.toFixed(2)}`;
  return `$${v.toFixed(3)}`;
}

export default function TimeValueSection({ monthlyUSD }: Props) {
  const { t } = useLanguage();

  useEffect(() => {
    if (monthlyUSD !== null) track({ type: "calculator_used", calculator: "time_value" });
  }, [monthlyUSD !== null]);

  return (
    <section id="time-value" className="py-14 border-t border-line/40 scroll-mt-8">
      <h2 className="font-display font-extrabold text-2xl md:text-3xl text-center mb-2">{t.tvTitle}</h2>
      <p className="text-sm text-muted font-display text-center mb-8">{t.tvSubtitle}</p>

      {monthlyUSD === null ? (
        <div className="max-w-md mx-auto rounded-xl p-6 border border-line border-dashed text-center flex flex-col items-center gap-2">
          <Lock className="w-5 h-5 text-muted" />
          <p className="text-sm text-muted font-display">{t.tvLocked}</p>
        </div>
      ) : (
        <>
          <TimeScale monthlyUSD={monthlyUSD} />
          <p className="text-[11px] text-muted/70 font-display text-center mt-6">{t.tvNote}</p>
          <ShareTimeValue monthlyUSD={monthlyUSD} />
        </>
      )}
    </section>
  );
}

function ShareTimeValue({ monthlyUSD }: { monthlyUSD: number }) {
  const { lang } = useLanguage();
  const tv = calculateTimeValue(monthlyUSD);
  const text =
    lang === "ar"
      ? `⏱️ ساعتي تساوي $${tv.hourly.toFixed(2)}! شوف كم تساوي ساعتك أنت`
      : `⏱️ My hour is worth $${tv.hourly.toFixed(2)}! Find out what yours is worth`;
  return <ShareCard text={text} calculator="time_value" />;
}

function TimeScale({ monthlyUSD }: { monthlyUSD: number }) {
  const { t } = useLanguage();
  const tv = calculateTimeValue(monthlyUSD);

  const rows = [
    { label: t.tvYear, value: tv.yearly, Icon: CalendarDays },
    { label: t.tvMonth, value: tv.monthly, Icon: Calendar },
    { label: t.tvDay, value: tv.daily, Icon: Sun },
    { label: t.tvHour, value: tv.hourly, Icon: Clock },
    { label: t.tvMinute, value: tv.perMinute, Icon: Timer },
  ];

  const logs = rows.map((r) => Math.log10(r.value + 1));
  const maxLog = Math.max(...logs);
  const minLog = Math.min(...logs);

  return (
    <div className="max-w-2xl mx-auto space-y-4">
      {rows.map((r, i) => {
        const pct = maxLog === minLog ? 100 : 15 + (85 * (logs[i] - minLog)) / (maxLog - minLog);
        return (
          <div key={r.label} className="rounded-xl p-4 bg-panel/25 border border-line">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <r.Icon className="w-4 h-4 text-glow" />
                <span className="font-display font-bold text-sm">{r.label}</span>
              </div>
              <span className="font-num font-bold text-lg text-goldBright">{formatUSD(r.value)}</span>
            </div>
            <div className="h-2 rounded-full bg-void/60 overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-700"
                style={{ width: `${pct}%`, background: "linear-gradient(90deg,#4C7CFF,#D4AF37)" }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}
