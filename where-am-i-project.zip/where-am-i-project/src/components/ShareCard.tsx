import { useMemo, useRef, useState } from "react";
import { Copy, Check, ImageDown, Loader2 } from "lucide-react";
import { useLanguage } from "../i18n/LanguageContext";
import { SITE_URL } from "../config";
import { track } from "../lib/analytics";

interface Props {
  text: string;
  calculator?: string;
}

export default function ShareCard({ text, calculator = "unknown" }: Props) {
  const { t, lang } = useLanguage();
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  const links = useMemo(() => {
    const encodedText = encodeURIComponent(text);
    const encodedUrl = encodeURIComponent(SITE_URL);
    return {
      whatsapp: `https://wa.me/?text=${encodedText}%20${encodedUrl}`,
      telegram: `https://t.me/share/url?url=${encodedUrl}&text=${encodedText}`,
      x: `https://twitter.com/intent/tweet?text=${encodedText}&url=${encodedUrl}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}&quote=${encodedText}`,
    };
  }, [text]);

  const copyText = async () => {
    try {
      await navigator.clipboard.writeText(`${text} ${SITE_URL}`);
      track({ type: "share_click", calculator, platform: "copy" });
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // تجاهل صامت — بعض المتصفحات تمنع الوصول للحافظة بدون تفاعل مباشر
    }
  };

  const handleLinkClick = (platform: string) => track({ type: "share_click", calculator, platform });

  const downloadImage = async () => {
    if (!cardRef.current || downloading) return;
    setDownloading(true);
    try {
      // نحمّل html2canvas فقط وقت الحاجة الفعلية — عشان ما يثقّل الحزمة الأساسية
      const { default: html2canvas } = await import("html2canvas");
      const canvas = await html2canvas(cardRef.current, {
        backgroundColor: "#05070F",
        scale: 2,
        logging: false,
      });
      const url = canvas.toDataURL("image/png");
      const link = document.createElement("a");
      link.href = url;
      link.download = "where-am-i-result.png";
      link.click();
      track({ type: "share_click", calculator, platform: "download_image" });
    } catch {
      // تجاهل صامت — لو فشل التصدير لأي سبب (متصفح قديم مثلاً)
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="pt-6 mt-6 border-t border-line/40">
      <p className="text-xs text-muted font-display mb-3 text-center">{t.shareTitle}</p>

      {/* البطاقة القابلة للتصدير كصورة */}
      <div className="flex justify-center mb-4">
        <div
          ref={cardRef}
          className="w-full max-w-md rounded-2xl p-6 relative overflow-hidden"
          style={{
            background: "linear-gradient(160deg, #0B1030 0%, #12224F 55%, #0B1030 100%)",
            border: "1px solid rgba(212,175,55,0.25)",
          }}
        >
          <div
            className="absolute -top-10 -right-10 h-32 w-32 rounded-full opacity-40 blur-2xl"
            style={{ background: "radial-gradient(circle, #4C7CFF 0%, transparent 70%)" }}
          />
          <div className="relative flex items-center gap-1.5 mb-4">
            <svg width="18" height="18" viewBox="0 0 96 96">
              <circle cx="48" cy="48" r="34" fill="none" stroke="#2A3564" strokeWidth="3" />
              <circle cx="48" cy="48" r="12" fill="#4C7CFF" />
              <circle cx="80" cy="48" r="6" fill="#D4AF37" />
            </svg>
            <span className="font-display font-bold text-xs text-ivory/90">
              {lang === "ar" ? "أين أنا من العالم؟" : "Where Am I In The World"}
            </span>
          </div>
          <p className="relative font-display text-lg font-bold text-ivory text-center leading-relaxed py-4">
            {text}
          </p>
          <p className="relative text-[10px] font-display text-muted text-center mt-2">{SITE_URL}</p>
        </div>
      </div>

      <div className="flex flex-wrap justify-center gap-2.5">
        <ShareLink href={links.whatsapp} color="#25D366" label={t.shareWhatsapp} onClick={() => handleLinkClick("whatsapp")} />
        <ShareLink href={links.telegram} color="#29A9EA" label={t.shareTelegram} onClick={() => handleLinkClick("telegram")} />
        <ShareLink href={links.x} color="#EAF0FF" dark label={t.shareX} onClick={() => handleLinkClick("x")} />
        <ShareLink href={links.facebook} color="#1877F2" label={t.shareFacebook} onClick={() => handleLinkClick("facebook")} />
        <button
          onClick={downloadImage}
          disabled={downloading}
          className="font-display text-sm flex items-center gap-1.5 px-4 py-2 rounded-full border border-gold/40 text-goldBright hover:bg-gold/10 transition-colors disabled:opacity-60"
        >
          {downloading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ImageDown className="w-3.5 h-3.5" />}
          {t.shareDownloadImage}
        </button>
        <button
          onClick={copyText}
          className="font-display text-sm flex items-center gap-1.5 px-4 py-2 rounded-full border border-line hover:border-glow transition-colors"
        >
          {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
          {copied ? t.shareCopied : t.shareCopy}
        </button>
      </div>
    </div>
  );
}

function ShareLink({
  href,
  color,
  label,
  dark,
  onClick,
}: {
  href: string;
  color: string;
  label: string;
  dark?: boolean;
  onClick?: () => void;
}) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      onClick={onClick}
      className="font-display text-sm font-bold px-4 py-2 rounded-full transition-transform active:scale-95"
      style={{ background: color, color: dark ? "#0B1030" : "#05070F" }}
    >
      {label}
    </a>
  );
}
