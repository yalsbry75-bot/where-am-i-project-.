import { useLanguage } from "../i18n/LanguageContext";

export default function CalculatorsSection() {
  const { t } = useLanguage();

  return (
    <section className="py-14">
      <h2 className="font-display font-extrabold text-2xl md:text-3xl text-center mb-8">
        {t.calculatorsTitle}
      </h2>
      <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
        {t.calculators.map((calc, i) => (
          <div
            key={i}
            className={`rounded-xl p-5 border ${
              calc.status === "live" ? "border-gold/50 bg-gold/5" : "border-line border-dashed bg-panel/20"
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="font-display font-bold text-sm">{calc.title}</span>
              <span
                className={`text-[10px] font-display px-2 py-0.5 rounded-full ${
                  calc.status === "live" ? "bg-goldBright text-panel" : "text-muted border border-line"
                }`}
              >
                {calc.status === "live" ? t.statusLive : t.statusSoon}
              </span>
            </div>
            <p className="text-xs text-muted font-display leading-relaxed">{calc.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
