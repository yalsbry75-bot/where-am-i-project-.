# Where Am I — Version 2.0

A bilingual Arabic/English global platform for financial intelligence, wealth analysis, salary ranking, cost-of-living comparison, purchasing power, life planning, and lifestyle indicators.

Version 2.0 extends the existing React application in place. The original home page, country pages, calculators, PWA, SEO, admin dashboard, advertising components, routing, and visual identity remain available.

## Main features

- Financial Center: savings, wealth growth, compound interest, and debt payoff.
- Global Living Comparison: estimated rent, food, fuel, internet, overall basket, disposable income, and best-country ranking for a salary.
- Global Ranking: global income percentile, country percentile, top 1% estimate, purchasing power, and living-standard score.
- Health & Lifestyle: estimated biological age, health score, sleep score, and recommended walking steps.
- Financial Life Journey: instant timeline for a first car, home deposit, and first million.
- AI Assistant: built-in local explanation engine plus an adapter for an external AI API.
- PDF Reports: direct multilingual PDF download with user inputs, results, visual charts, summaries, and recommendations.
- Social Sharing: downloadable 1200×630 result cards and sharing links for WhatsApp, Telegram, X, Facebook, and LinkedIn.
- Scalable Tool Registry: each tool receives its own URL, metadata, structured data, related links, responsive layout, and lazy-loaded bundle.
- Widget and notification preparation: reusable local/remote adapter architecture without native widget implementation.

## Technology

- React 18
- TypeScript
- Vite
- Tailwind CSS
- React Router
- Lucide React
- jsPDF and html2canvas, loaded only when a report is requested

## Install and run

```bash
npm install
npm run dev
```

Production verification:

```bash
npm run verify
npm run preview
```

`npm run verify` runs calculation checks followed by the full TypeScript and Vite production build.

## Optional environment configuration

Copy `.env.example` to `.env` when connecting external services:

```bash
cp .env.example .env
```

Available variables:

- `VITE_AI_API_ENDPOINT`
- `VITE_AI_API_KEY`
- `VITE_NOTIFICATION_API_ENDPOINT`

When no AI endpoint is configured, the built-in local insight provider remains fully functional. When no notification endpoint is configured, the local notification adapter is used.

## Version 2 architecture

```text
src/
  components/
    charts/             reusable SVG charts and gauges
    ui/                 shared form and metric components
    AIInsightPanel.tsx  provider-based explanation interface
    ReportActions.tsx   PDF and social sharing engine
    ToolCard.tsx
    ToolShell.tsx
  data/
    toolRegistry.ts     central registry for independent tool URLs and SEO
  features/tools/
    SavingsTool.tsx
    WealthGrowthTool.tsx
    CompoundInterestTool.tsx
    DebtPayoffTool.tsx
    LivingComparisonTool.tsx
    GlobalRankingTool.tsx
    LifestyleInsightsTool.tsx
    FinancialJourneyTool.tsx
  lib/
    financial.ts
    financialJourney.ts
    globalRanking.ts
    livingIntelligence.ts
    lifestyle.ts
    aiAssistant.ts
    notifications.ts
    widgetBridge.ts
  pages/
    ToolsIndex.tsx
    ToolPage.tsx
    NotFound.tsx
```

To add a future tool:

1. Add its metadata to `src/data/toolRegistry.ts`.
2. Add its lazy component mapping in `src/pages/ToolPage.tsx`.
3. Implement the tool under `src/features/tools/` using the shared UI, chart, report, and AI components.
4. Add the slug to `scripts/generate-sitemap.mjs`, then run `npm run generate:sitemap`.

## Data and deployment notes

Country salaries, exchange rates, cost-of-living indices, income distribution breakpoints, and category cost estimates are illustrative project data. Connect verified live providers before presenting them as official or real-time statistics.

The inherited `/admin` dashboard, sponsor settings, affiliate placeholders, and premium payment placeholder remain client-side demonstrations. A production deployment that exposes these features requires backend authentication, persistent storage, payment integration, and real advertising/affiliate credentials.

See `VERSION_2_IMPLEMENTATION_REPORT.md` for the complete implementation and verification record.

---

## حالة المراحل الـ١٥ (خطة المشروع الأصلية)

- [x] المرحلة 1 — الهوية البصرية والشعار
- [x] المرحلة 2 — هيكل المشروع (React + TS + Tailwind + Vite)
- [x] المرحلة 3 — الصفحة الرئيسية الكاملة
- [x] المرحلة 4 — نموذج إدخال بيانات المستخدم
- [x] المرحلة 5 — حاسبة ترتيب الدخل العالمي
- [x] المرحلة 6 — حاسبة القوة الشرائية
- [x] المرحلة 7 — حاسبة قيمة الوقت
- [x] المرحلة 8 — مقارنة الدول
- [x] المرحلة 9 — اختبار العمر والحياة
- [x] المرحلة 10 — نظام مشاركة النتائج
- [x] المرحلة 11 — PWA (تثبيت على الهاتف)
- [x] المرحلة 12 — تحسين السرعة وSEO
- [x] المرحلة 13 — لوحة التحكم
- [x] المرحلة 14 — نظام الربح (AdSense + بانر داخلي + أفلييت + تقرير مميز)
- [x] المرحلة 15 — الإطلاق النهائي (اختبار، إصلاح، دليل نشر، حزمة تسويق) — راجع `DEPLOYMENT.md` و`MARKETING_LAUNCH_KIT.md`

**زائد على الخطة الأصلية:** تحديث Version 2.0 كامل (مركز مالي، مقارنة معيشة عالمية، ترتيب متقدم، مؤشرات صحية، مساعد ذكاء اصطناعي، تقارير PDF، رحلة الحياة المالية، بنية تحتية للويدجت والإشعارات) — راجع `VERSION_2_IMPLEMENTATION_REPORT.md`.

### إصلاح مهم صار بالمرحلة 15

المشروع كان ناقص إعدادات إعادة توجيه للاستضافة الثابتة (Vercel/Netlify) — بدونها، أي صفحة فرعية زي `/country/yemen-salary-ranking` أو `/admin` كانت بترجع **404** لو انفتحت مباشرة أو انسوى لها Refresh (مشكلة معروفة بمشاريع React Router على استضافة Static). تمت إضافة `vercel.json` و`public/_redirects` لحل هذا قبل أي نشر فعلي.
