import { Lang } from "../i18n/translations";

const WORKDAYS_PER_MONTH = 22;
const WORKDAYS_PER_YEAR = WORKDAYS_PER_MONTH * 12;

export function workdaysNeeded(priceUSD: number, monthlyUSD: number): number {
  const dailyUSD = monthlyUSD / WORKDAYS_PER_MONTH;
  if (dailyUSD <= 0) return Infinity;
  return priceUSD / dailyUSD;
}

export function formatWorkDuration(days: number, lang: Lang): string {
  if (!Number.isFinite(days)) return lang === "ar" ? "غير محسوب" : "N/A";

  if (days < 1) {
    return lang === "ar" ? "أقل من يوم عمل واحد" : "Less than 1 workday";
  }
  if (days <= 90) {
    const v = Math.round(days);
    return lang === "ar" ? `${v} يوم عمل` : `${v} workdays`;
  }
  if (days <= WORKDAYS_PER_YEAR * 3) {
    const v = (days / WORKDAYS_PER_MONTH).toFixed(1);
    return lang === "ar" ? `${v} شهر عمل تقريباً` : `~${v} months of work`;
  }
  const v = (days / WORKDAYS_PER_YEAR).toFixed(1);
  return lang === "ar" ? `${v} سنة عمل تقريباً` : `~${v} years of work`;
}
