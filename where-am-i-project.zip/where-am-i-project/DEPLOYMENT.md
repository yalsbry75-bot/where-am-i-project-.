# دليل النشر — المرحلة 15

هذا المشروع Vite + React عادي (Static Build) — يعني ينشر على أي استضافة ثابتة بسهولة. الدليل هذا يغطي Vercel (الأسهل) وNetlify كبديل.

---

## ✅ قبل ما تنشر — قائمة تبديل الـ Placeholders (مهم جداً)

هذي القيم التجريبية لازم تتغيّر لقيمك الحقيقية، وإلا الموقع ينشر لكن ببيانات وهمية:

| الملف | القيمة الحالية | تبدّلها بـ |
|---|---|---|
| `src/config.ts` | `SITE_URL = "https://whereami-intheworld.app"` | دومينك الفعلي |
| `src/config.ts` | `ADSENSE_CLIENT_ID`, `ADSENSE_SLOT_HERO`, `ADSENSE_SLOT_INLINE` | معرّفات حساب AdSense الحقيقي (بعد الموافقة من جوجل) |
| `public/robots.txt` | رابط الـ Sitemap بنفس الدومين الوهمي | دومينك الفعلي |
| `scripts/generate-sitemap.mjs` | `SITE_URL` بأعلى الملف | دومينك الفعلي، ثم شغّل `npm run generate:sitemap` من جديد |
| `src/pages/AdminDashboard.tsx` | `ADMIN_PASSWORD = "admin123"` | كلمة مرور حقيقية — **وهذا لسا مو كافي كحماية حقيقية**، راجع التنويه بالـ README قبل ما تعتمد عليه بالإنتاج |

بعد أي تعديل على قائمة الدول في `src/data/countries.ts`، لازم تشغّل `npm run generate:sitemap` يدوياً عشان يواكب أي دولة جديدة.

---

## 1) النشر على Vercel (الأسهل — يدعم الدومين المخصص والـ HTTPS تلقائياً)

```bash
npm install -g vercel
cd where-am-i-project
npm install
npm run verify        # يتأكد إن الحسابات صحيحة والبناء ناجح قبل ما تنشر
vercel                # أول مرة بيسألك عن ربط المشروع — اتبع التعليمات
vercel --prod         # للنشر بالإنتاج
```

ملف `vercel.json` موجود مسبقاً بالمشروع ويحل مشكلة الصفحات الفرعية (زي `/country/yemen-salary-ranking`) اللي كانت بترجع 404 لو انعمل لها Refresh مباشر — لأنه مشروع React عادي (Client-Side Routing) وليس Next.js.

## 2) النشر على Netlify (بديل جيد)

```bash
npm install -g netlify-cli
npm run build
netlify deploy --prod --dir=dist
```

ملف `public/_redirects` موجود مسبقاً ويُنسخ تلقائياً لمجلد `dist` عند البناء، ويحل نفس مشكلة الـ 404 المذكورة فوق.

## 3) ربط الدومين المخصص

من لوحة تحكم Vercel/Netlify: Settings → Domains → أضف دومينك، واتبع تعليمات DNS (عادة سجل CNAME أو A). الشهادة الأمنية (HTTPS) تتفعّل تلقائياً — وهذا **شرط أساسي** لعمل الـ Service Worker وميزة PWA، فما تقدر تشغّلها على HTTP عادي.

## 4) بعد النشر مباشرة — تحقق يدوي سريع

- [ ] الصفحة الرئيسية تفتح صح على الجوال والديسكتوب
- [ ] جرّب حاسبة وحدة على الأقل من البداية للنهاية (مثلاً ترتيب الدخل) وتأكد النتيجة صحيحة
- [ ] افتح `/country/yemen-salary-ranking` مباشرة (مو بالنقر، اكتب الرابط بالمتصفح) وتأكد ما يطلع 404
- [ ] افتح `/admin` وتأكد تسجيل الدخول يشتغل
- [ ] من الجوال: جرّب "أضف للشاشة الرئيسية" وتأكد الأيقونة والاسم يطلعون صح
- [ ] Chrome DevTools → Lighthouse → شغّل تقرير PWA وتأكد كل شي أخضر
- [ ] Google Search Console: أضف الموقع، وأرسل رابط `sitemap.xml`

---

## ملاحظة صادقة

هذا نشر لموقع Static (Frontend بس). أي جزء يحتاج باكيند حقيقي — تسجيل مستخدمين، إحصائيات حقيقية لكل الزوار، دفع فعلي للتقارير المميزة — يحتاج مشروع خادم منفصل (Node.js/Express + قاعدة بيانات) لسا ما انبنى، ومذكور بوضوح بالـ README تحت "ملاحظة صادقة عن لوحة التحكم".
