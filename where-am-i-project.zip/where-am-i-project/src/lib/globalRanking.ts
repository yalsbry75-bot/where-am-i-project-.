import { Country } from "../data/countries";
import { getGlobalPercentile } from "./incomeCalculator";
import { clamp } from "./format";

export interface RankingResult {
  monthlyUSD: number;
  globalPercentile: number;
  countryPercentile: number;
  topOneGlobal: boolean;
  globalTopOneGap: number;
  purchasingPowerIndex: number;
  livingStandardScore: number;
  incomeVsCountry: number;
}

const GLOBAL_TOP_ONE_ANNUAL = 110000;

export function calculateRanking(monthlyUSD: number, country: Country): RankingResult {
  const monthly = Math.max(0, monthlyUSD);
  const annual = monthly * 12;
  const globalPercentile = getGlobalPercentile(annual);
  const ratio = monthly / Math.max(1, country.avgMonthlyUSD);
  const countryPercentile = clamp(50 + Math.log(Math.max(0.05, ratio)) * 22, 1, 99.9);
  const purchasingPowerIndex = monthly / Math.max(0.1, country.costOfLivingIndex / 100);
  const benchmarkPower = country.avgMonthlyUSD / Math.max(0.1, country.costOfLivingIndex / 100);
  const livingStandardScore = clamp(50 + (purchasingPowerIndex / Math.max(1, benchmarkPower) - 1) * 28, 0, 100);
  return {
    monthlyUSD: monthly,
    globalPercentile,
    countryPercentile,
    topOneGlobal: annual >= GLOBAL_TOP_ONE_ANNUAL,
    globalTopOneGap: Math.max(0, GLOBAL_TOP_ONE_ANNUAL - annual),
    purchasingPowerIndex,
    livingStandardScore,
    incomeVsCountry: (ratio - 1) * 100,
  };
}
