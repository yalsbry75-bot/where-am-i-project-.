import { useMemo, useState } from "react";
import { Fuel, Globe2, Home, ShoppingBasket, Wifi } from "lucide-react";
import NumberField from "../../components/ui/NumberField";
import MetricCard from "../../components/ui/MetricCard";
import BarComparison from "../../components/charts/BarComparison";
import AIInsightPanel from "../../components/AIInsightPanel";
import ReportActions from "../../components/ReportActions";
import { useCountries } from "../../hooks/useCountries";
import { rankCountriesForSalary } from "../../lib/livingIntelligence";
import { formatCurrency, formatNumber } from "../../lib/format";
import { useLanguage } from "../../i18n/LanguageContext";

export default function LivingComparisonTool() {
  const { lang } = useLanguage();
  const locale = lang === "ar" ? "ar-SA" : "en-US";
  const countries = useCountries();
  const [salaryUSD, setSalaryUSD] = useState(3500);
  const [selectedCode, setSelectedCode] = useState("SA");
  const ranking = useMemo(() => rankCountriesForSalary(salaryUSD, countries), [salaryUSD, countries]);
  const selected = ranking.find((item) => item.country.code === selectedCode) ?? ranking[0];
  const best = ranking[0];
  const recommendations = useMemo(() => lang === "ar" ? ["قارن صافي الدخل بعد الضرائب والتأمين قبل الانتقال الفعلي.", "تكلفة السكن تتغير كثيراً بين المدن داخل الدولة الواحدة.", "استخدم النتائج كفرز أولي ثم تحقق من مصادر محلية حديثة."] : ["Compare net income after tax and insurance before making a relocation decision.", "Housing costs vary materially between cities in the same country.", "Use the result as an initial screen, then validate it with current local sources."], [lang]);

  if (!selected || !best) return null;

  return (
    <div className="tool-grid">
      <section className="tool-form-card">
        <h2 className="tool-section-title">{lang === "ar" ? "الراتب والدولة" : "Salary and country"}</h2>
        <div className="space-y-5">
          <NumberField label={lang === "ar" ? "راتبك الشهري" : "Your monthly salary"} value={salaryUSD} onChange={setSalaryUSD} suffix="USD" />
          <label className="block"><span className="mb-2 block text-sm font-display font-bold">{lang === "ar" ? "الدولة المراد تحليلها" : "Country to analyze"}</span><select value={selectedCode} onChange={(event) => setSelectedCode(event.target.value)} className="w-full rounded-xl border border-line bg-void/70 px-4 py-3 text-sm outline-none focus:border-glow">{countries.map((country) => <option key={country.code} value={country.code}>{lang === "ar" ? country.name : country.nameEn}</option>)}</select></label>
        </div>
        <div className="mt-6 rounded-2xl border border-gold/30 bg-gold/10 p-4">
          <p className="text-xs text-muted">{lang === "ar" ? "أفضل دولة تقديرياً لهذا الراتب" : "Estimated best country for this salary"}</p>
          <p className="mt-1 font-display text-xl font-bold text-gold">{lang === "ar" ? best.country.name : best.country.nameEn}</p>
          <p className="mt-1 text-xs text-muted">{lang === "ar" ? "الدرجة" : "Score"}: {formatNumber(best.affordabilityScore, locale)}/100</p>
        </div>
      </section>
      <div className="space-y-6 min-w-0">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <MetricCard label={lang === "ar" ? "الإيجار التقديري" : "Estimated rent"} value={formatCurrency(selected.basket.rent, "USD", locale)} icon={<Home className="h-4 w-4 text-gold" />} />
          <MetricCard label={lang === "ar" ? "الغذاء" : "Food"} value={formatCurrency(selected.basket.food, "USD", locale)} icon={<ShoppingBasket className="h-4 w-4 text-glow" />} />
          <MetricCard label={lang === "ar" ? "الوقود" : "Fuel"} value={formatCurrency(selected.basket.fuel, "USD", locale)} icon={<Fuel className="h-4 w-4 text-glow" />} />
          <MetricCard label={lang === "ar" ? "الإنترنت" : "Internet"} value={formatCurrency(selected.basket.internet, "USD", locale)} icon={<Wifi className="h-4 w-4 text-glow" />} />
        </section>
        <section className="grid gap-4 sm:grid-cols-3">
          <MetricCard label={lang === "ar" ? "إجمالي السلة" : "Total basket"} value={formatCurrency(selected.basket.total, "USD", locale)} />
          <MetricCard label={lang === "ar" ? "الدخل المتبقي" : "Disposable income"} value={formatCurrency(selected.disposableIncome, "USD", locale)} emphasis />
          <MetricCard label={lang === "ar" ? "القوة الشرائية" : "Purchasing power"} value={formatCurrency(selected.purchasingPower, "USD", locale)} icon={<Globe2 className="h-4 w-4 text-gold" />} />
        </section>
        <section>
          <h2 className="tool-section-title">{lang === "ar" ? "أفضل خمس دول للراتب المدخل" : "Top five countries for the entered salary"}</h2>
          <BarComparison items={ranking.slice(0, 5).map((item) => ({ label: lang === "ar" ? item.country.name : item.country.nameEn, value: item.affordabilityScore, displayValue: `${formatNumber(item.affordabilityScore, locale)}/100` }))} />
        </section>
        <AIInsightPanel tool={lang === "ar" ? "مقارنة المعيشة العالمية" : "Global Living Comparison"} metrics={{ salaryUSD, selectedCountry: selected.country.nameEn, livingBasket: selected.basket.total, disposableIncome: selected.disposableIncome, affordabilityScore: selected.affordabilityScore }} />
        <ReportActions toolName="Where Am I Global Intelligence" title={lang === "ar" ? "تقرير مقارنة المعيشة" : "Living comparison report"} summary={lang === "ar" ? "مقارنة تقديرية بين الراتب وتكاليف المعيشة الرئيسية." : "An estimated comparison between salary and major living costs."} userInfo={[{ label: lang === "ar" ? "الراتب الشهري" : "Monthly salary", value: formatCurrency(salaryUSD, "USD", locale) }, { label: lang === "ar" ? "الدولة المختارة" : "Selected country", value: lang === "ar" ? selected.country.name : selected.country.nameEn }]} metrics={[{ label: lang === "ar" ? "الدولة" : "Country", value: lang === "ar" ? selected.country.name : selected.country.nameEn }, { label: lang === "ar" ? "سلة المعيشة" : "Living basket", value: formatCurrency(selected.basket.total, "USD", locale) }, { label: lang === "ar" ? "الدخل المتبقي" : "Disposable income", value: formatCurrency(selected.disposableIncome, "USD", locale) }, { label: lang === "ar" ? "أفضل دولة" : "Best country", value: lang === "ar" ? best.country.name : best.country.nameEn }]} recommendations={recommendations} calculator="living-comparison" />
        <p className="text-[11px] leading-relaxed text-muted/80">{lang === "ar" ? "جميع تكاليف الفئات تقديرية مشتقة من مؤشر تكلفة المعيشة الحالي في المشروع، وليست أسعاراً رسمية لحظية." : "Category costs are illustrative estimates derived from the project's cost-of-living index and are not live official prices."}</p>
      </div>
    </div>
  );
}
