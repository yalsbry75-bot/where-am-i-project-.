import { useLanguage } from "../i18n/LanguageContext";
import Reveal from "./Reveal";

export default function CtaSection() {
  const { t } = useLanguage();

  return (
    <section className="py-16">
      <Reveal>
        <div className="glass-card relative overflow-hidden p-10 text-center shadow-premium">
          <div
            className="pointer-events-none absolute -top-20 left-1/2 h-64 w-64 -translate-x-1/2 rounded-full bg-glow/20 blur-3xl"
            aria-hidden="true"
          />
          <h2 className="relative font-display font-extrabold text-2xl md:text-3xl mb-2">{t.ctaTitle}</h2>
          <p className="relative text-sm text-muted font-display mb-6">{t.ctaSubtitle}</p>
          <a href="#income-calculator" className="btn-premium-primary relative">
            {t.ctaButton}
          </a>
        </div>
      </Reveal>
    </section>
  );
}
