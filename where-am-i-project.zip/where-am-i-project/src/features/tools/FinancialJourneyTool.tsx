import { useEffect, useMemo, useState } from "react";
import { Car, GraduationCap, Home, Milestone, Wallet } from "lucide-react";
import NumberField from "../../components/ui/NumberField";
import MetricCard from "../../components/ui/MetricCard";
import LineChart from "../../components/charts/LineChart";
import AIInsightPanel from "../../components/AIInsightPanel";
import ReportActions from "../../components/ReportActions";
import { calculateFinancialJourney } from "../../lib/financialJourney";
import { formatCurrency, formatNumber } from "../../lib/format";
import { useLanguage } from "../../i18n/LanguageContext";
import { publishWidgetSnapshot } from "../../lib/widgetBridge";

export default function FinancialJourneyTool() {
  const { lang } = useLanguage();
  const locale = lang === "ar" ? "ar-SA" : "en-US";
  const [age, setAge] = useState(28);
  const [salary, setSalary] = useState(4500);
  const [expenses, setExpenses] = useState(2800);
  const [savingsRate, setSavingsRate] = useState(25);
  const [currentSavings, setCurrentSavings] = useState(12000);
  const [annualReturn, setAnnualReturn] = useState(5);
  const result = useMemo(() => calculateFinancialJourney({ age, monthlySalary: salary, monthlyExpenses: expenses, savingsRate, currentSavings, annualReturn }), [age, salary, expenses, savingsRate, currentSavings, annualReturn]);
  const milestoneText = (value: number | null) => value === null ? (lang === "ar" ? "أبعد من نطاق 60 سنة" : "Beyond 60-year horizon") : `${formatNumber(value, locale)} ${lang === "ar" ? "سنة" : "years old"}`;
  const car = result.milestones.find((item) => item.id === "car");
  const home = result.milestones.find((item) => item.id === "home");
  const million = result.milestones.find((item) => item.id === "million");
  const recommendations = useMemo(() => lang === "ar" ? [result.monthlySavings <= 0 ? "لا يوجد فائض ادخار حالياً؛ خفض المصروفات أو رفع الدخل هو الخطوة الأولى." : "ثبّت الادخار الشهري تلقائياً للحفاظ على المسار.", "عدّل أهداف السيارة والمنزل حسب الأسعار الفعلية في مدينتك.", "العائد الاستثماري افتراض وليس ضماناً، لذلك راجع سيناريو بعائد أقل."] : [result.monthlySavings <= 0 ? "There is no current savings surplus; reducing expenses or increasing income is the first step." : "Automate the monthly saving amount to stay on track.", "Adjust the car and home targets to actual prices in your city.", "Investment return is an assumption, not a guarantee, so review a lower-return scenario."], [lang, result.monthlySavings]);

  useEffect(() => {
    publishWidgetSnapshot({ id: "financial-journey", title: lang === "ar" ? "المعلم المالي القادم" : "Next financial milestone", primaryValue: car?.age ? milestoneText(car.age) : "—", secondaryValue: formatCurrency(result.monthlySavings, "USD", locale), updatedAt: new Date().toISOString(), deepLink: "/tools/financial-journey" });
  }, [lang, locale, result.monthlySavings, car?.age]);

  return (
    <div className="tool-grid">
      <section className="tool-form-card">
        <h2 className="tool-section-title">{lang === "ar" ? "بيانات الرحلة" : "Journey inputs"}</h2>
        <p className="mb-5 text-xs leading-relaxed text-muted">{lang === "ar" ? "جميع النتائج تتحدث فورياً عند تغيير أي قيمة." : "Every result updates instantly whenever an input changes."}</p>
        <div className="space-y-5">
          <NumberField label={lang === "ar" ? "العمر الحالي" : "Current age"} value={age} onChange={setAge} min={18} max={80} />
          <NumberField label={lang === "ar" ? "الراتب الشهري" : "Monthly salary"} value={salary} onChange={setSalary} suffix="USD" />
          <NumberField label={lang === "ar" ? "المصروفات الشهرية" : "Monthly expenses"} value={expenses} onChange={setExpenses} suffix="USD" />
          <NumberField label={lang === "ar" ? "نسبة الادخار" : "Savings rate"} value={savingsRate} onChange={setSavingsRate} min={0} max={100} suffix="%" />
          <NumberField label={lang === "ar" ? "المدخرات الحالية" : "Current savings"} value={currentSavings} onChange={setCurrentSavings} suffix="USD" />
          <NumberField label={lang === "ar" ? "العائد السنوي المفترض" : "Assumed annual return"} value={annualReturn} onChange={setAnnualReturn} min={-20} max={30} step={0.1} suffix="%" />
        </div>
      </section>
      <div className="space-y-6 min-w-0">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <MetricCard label={lang === "ar" ? "الوضع الحالي" : "Current situation"} value={formatCurrency(currentSavings, "USD", locale)} icon={<GraduationCap className="h-4 w-4 text-glow" />} />
          <MetricCard label={lang === "ar" ? "أول سيارة" : "Estimated first car"} value={milestoneText(car?.age ?? null)} note={formatCurrency(car?.target ?? 25000, "USD", locale)} icon={<Car className="h-4 w-4 text-gold" />} emphasis />
          <MetricCard label={lang === "ar" ? "دفعة أول منزل" : "Estimated first home"} value={milestoneText(home?.age ?? null)} note={formatCurrency(home?.target ?? 50000, "USD", locale)} icon={<Home className="h-4 w-4 text-glow" />} />
          <MetricCard label={lang === "ar" ? "أول مليون" : "Estimated first million"} value={milestoneText(million?.age ?? null)} note={formatCurrency(million?.target ?? 1000000, "USD", locale)} icon={<Milestone className="h-4 w-4 text-gold" />} />
        </section>
        <MetricCard label={lang === "ar" ? "الادخار الشهري الفعلي" : "Effective monthly savings"} value={formatCurrency(result.monthlySavings, "USD", locale)} icon={<Wallet className="h-4 w-4 text-gold" />} emphasis />
        <section><h2 className="tool-section-title">{lang === "ar" ? "الخط الزمني المالي" : "Financial timeline"}</h2><LineChart labels={result.projection.map((point) => point.label)} series={[{ name: lang === "ar" ? "الثروة المتوقعة" : "Projected wealth", values: result.projection.map((point) => point.value) }]} valueFormatter={(value) => formatCurrency(value, "USD", locale)} /></section>
        <section className="relative overflow-hidden rounded-2xl border border-line/70 bg-void/45 p-5"><div className="absolute bottom-0 top-0 start-8 w-px bg-gradient-to-b from-glow via-gold to-line" /><div className="space-y-5">{[
          { icon: GraduationCap, title: lang === "ar" ? "الوضع الحالي" : "Current situation", value: `${lang === "ar" ? "العمر" : "Age"} ${age}` },
          { icon: Car, title: lang === "ar" ? "أول سيارة" : "First car", value: milestoneText(car?.age ?? null) },
          { icon: Home, title: lang === "ar" ? "أول منزل" : "First home", value: milestoneText(home?.age ?? null) },
          { icon: Milestone, title: lang === "ar" ? "أول مليون" : "First million", value: milestoneText(million?.age ?? null) },
        ].map((item) => { const Icon = item.icon; return <div key={item.title} className="relative flex items-center gap-4 ps-1"><span className="z-10 rounded-full border border-gold/40 bg-panel p-2 text-gold"><Icon className="h-4 w-4" /></span><div><p className="font-display text-sm font-bold">{item.title}</p><p className="text-xs text-muted">{item.value}</p></div></div>; })}</div></section>
        <AIInsightPanel tool={lang === "ar" ? "رحلة الحياة المالية" : "Financial Life Journey"} metrics={{ age, salary, expenses, savingsRate, currentSavings, monthlySavings: result.monthlySavings, carAge: car?.age ?? 0, homeAge: home?.age ?? 0, millionAge: million?.age ?? 0 }} />
        <ReportActions toolName="Where Am I Life Planning" title={lang === "ar" ? "تقرير رحلة الحياة المالية" : "Financial life journey report"} summary={lang === "ar" ? "خط زمني تقديري لأهم المحطات المالية بناءً على القيم الحالية." : "An estimated timeline for key financial milestones based on current inputs."} userInfo={[{ label: lang === "ar" ? "العمر" : "Age", value: `${age}` }, { label: lang === "ar" ? "الراتب" : "Salary", value: formatCurrency(salary, "USD", locale) }, { label: lang === "ar" ? "المصروفات" : "Expenses", value: formatCurrency(expenses, "USD", locale) }, { label: lang === "ar" ? "نسبة الادخار" : "Savings rate", value: `${savingsRate}%` }, { label: lang === "ar" ? "المدخرات الحالية" : "Current savings", value: formatCurrency(currentSavings, "USD", locale) }]} metrics={[{ label: lang === "ar" ? "الادخار الشهري" : "Monthly savings", value: formatCurrency(result.monthlySavings, "USD", locale) }, { label: lang === "ar" ? "أول سيارة" : "First car", value: milestoneText(car?.age ?? null) }, { label: lang === "ar" ? "أول منزل" : "First home", value: milestoneText(home?.age ?? null) }, { label: lang === "ar" ? "أول مليون" : "First million", value: milestoneText(million?.age ?? null) }]} recommendations={recommendations} calculator="financial-journey" />
      </div>
    </div>
  );
}
