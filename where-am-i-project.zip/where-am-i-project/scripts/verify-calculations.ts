import assert from "node:assert/strict";
import { calculateCompoundInterest, calculateDebt, calculateRequiredDebtPayment, calculateSavings } from "../src/lib/financial";
import { rankCountriesForSalary } from "../src/lib/livingIntelligence";
import { calculateRanking } from "../src/lib/globalRanking";
import { calculateLifestyle } from "../src/lib/lifestyle";
import { calculateFinancialJourney } from "../src/lib/financialJourney";
import { COUNTRIES } from "../src/data/countries";

const savings = calculateSavings({ monthlyIncome: 4000, monthlyExpenses: 2500, savingsRate: 20, months: 24 });
assert.equal(savings.monthlySavings, 800);
assert.equal(savings.totalSavings, 19200);
assert.ok(savings.projection.length > 2);

const compound = calculateCompoundInterest({ initialInvestment: 10000, monthlyContribution: 500, annualReturn: 7, years: 10 });
assert.ok(compound.futureValue > compound.totalContributions);
assert.ok(compound.totalInterest > 0);

const debt = calculateDebt({ principal: 25000, annualInterestRate: 8, monthlyPayment: 650 });
assert.equal(debt.isPaymentSufficient, true);
assert.ok(Number.isFinite(debt.months));
assert.equal(debt.schedule.at(-1)?.balance, 0);
const requiredDebtPayment = calculateRequiredDebtPayment(25000, 8, 60);
assert.ok(requiredDebtPayment > 0 && requiredDebtPayment < 1000);

const living = rankCountriesForSalary(3500, COUNTRIES);
assert.equal(living.length, COUNTRIES.length);
assert.ok(living[0].affordabilityScore >= living.at(-1)!.affordabilityScore);

const saudi = COUNTRIES.find((country) => country.code === "SA");
assert.ok(saudi);
const ranking = calculateRanking(4000, saudi);
assert.ok(ranking.globalPercentile >= 0 && ranking.globalPercentile <= 100);
assert.ok(ranking.countryPercentile >= 0 && ranking.countryPercentile <= 100);

const lifestyle = calculateLifestyle({ age: 30, sleepHours: 8, activeDays: 4, stressLevel: 4, waterGlasses: 8, smoker: false, restingHours: 6 }, "en");
assert.ok(lifestyle.healthScore >= 0 && lifestyle.healthScore <= 100);
assert.ok(lifestyle.recommendedSteps >= 5000);

const journey = calculateFinancialJourney({ age: 28, monthlySalary: 5000, monthlyExpenses: 2800, savingsRate: 25, currentSavings: 15000, annualReturn: 5 });
assert.ok(journey.monthlySavings > 0);
assert.equal(journey.milestones.length, 3);
assert.ok(journey.projection.length >= 60);

console.log("✓ Financial, ranking, living, lifestyle, and journey calculation checks passed.");
