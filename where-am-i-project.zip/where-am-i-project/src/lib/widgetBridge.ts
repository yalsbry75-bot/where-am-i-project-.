export interface WidgetSnapshot {
  id: string;
  title: string;
  primaryValue: string;
  secondaryValue?: string;
  updatedAt: string;
  deepLink: string;
}

const STORAGE_KEY = "wai_widget_snapshots_v2";

export function publishWidgetSnapshot(snapshot: WidgetSnapshot): void {
  const current = readWidgetSnapshots().filter((item) => item.id !== snapshot.id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify([snapshot, ...current].slice(0, 10)));
  window.dispatchEvent(new CustomEvent("wai:widget-snapshot", { detail: snapshot }));
}

export function readWidgetSnapshots(): WidgetSnapshot[] {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]") as WidgetSnapshot[];
  } catch {
    return [];
  }
}
