// يُشغَّل يدوياً كل ما تتغيّر قائمة الدول: node scripts/generate-sitemap.mjs
// ملاحظة: القائمة هنا نسخة مبسطة (JS بدون TypeScript) عشان يشتغل السكربت بدون خطوة بناء إضافية.
// لو أضفت دولة في src/data/countries.ts لازم تضيفها هنا بنفس nameEn.
import { writeFileSync } from "fs";

const SITE_URL = "https://whereami-intheworld.app";

const COUNTRY_NAMES_EN = [
  "Yemen", "Saudi Arabia", "UAE", "Egypt", "Jordan", "Iraq", "Morocco", "Algeria",
  "Tunisia", "Kuwait", "Qatar", "Bahrain", "Oman", "Lebanon", "Sudan", "Syria",
  "Palestine", "Turkey", "India", "Pakistan", "United States", "United Kingdom",
  "Germany", "France", "Brazil", "Nigeria", "South Africa", "China", "Japan",
];

function slugify(text) {
  return text.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

const TOOL_SLUGS = [
  "savings-calculator",
  "wealth-growth",
  "compound-interest",
  "debt-payoff",
  "living-comparison",
  "global-ranking",
  "lifestyle-insights",
  "financial-journey",
];

const staticUrls = [
  { loc: "/", priority: "1.0", changefreq: "weekly" },
  { loc: "/tools", priority: "0.9", changefreq: "weekly" },
];

const toolUrls = TOOL_SLUGS.map((slug) => ({
  loc: `/tools/${slug}`,
  priority: slug === "financial-journey" ? "0.9" : "0.8",
  changefreq: "monthly",
}));

const countryUrls = COUNTRY_NAMES_EN.map((name) => ({
  loc: `/country/${slugify(name)}-salary-ranking`,
  priority: "0.7",
  changefreq: "monthly",
}));

const urls = [...staticUrls, ...toolUrls, ...countryUrls];

const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls
  .map(
    (u) => `  <url>
    <loc>${SITE_URL}${u.loc}</loc>
    <changefreq>${u.changefreq}</changefreq>
    <priority>${u.priority}</priority>
  </url>`
  )
  .join("\n")}
</urlset>
`;

writeFileSync(new URL("../public/sitemap.xml", import.meta.url), xml);
console.log(`✓ sitemap.xml generated with ${urls.length} URLs`);
