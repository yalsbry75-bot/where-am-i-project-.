import { useState } from "react";
import { FileText, Lock } from "lucide-react";
import { useLanguage } from "../i18n/LanguageContext";
import { track } from "../lib/analytics";

export default function PremiumReportCTA() {
  const { t } = useLanguage();
  const [clicked, setClicked] = useState(false);

  const handleClick = () => {
    track({ type: "share_click", calculator: "premium_report", platform: "cta_click" });
    setClicked(true);
  };

  return (
    <div className="rounded-2xl p-5 md:p-6 max-w-2xl mx-auto mt-4 bg-gradient-to-l from-glow/10 to-panel/25 border border-glow/25">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-9 h-9 rounded-lg bg-void flex items-center justify-center shrink-0">
          <FileText className="w-4 h-4 text-glow" />
        </div>
        <div>
          <p className="font-display font-bold text-sm">{t.premiumTitle}</p>
          <p className="text-xs text-muted font-display">{t.premiumSubtitle}</p>
        </div>
      </div>

      {!clicked ? (
        <button
          onClick={handleClick}
          className="w-full mt-3 font-display text-sm font-bold rounded-xl py-2.5 border border-glow/40 text-ivory/90 hover:bg-glow/10 transition-colors flex items-center justify-center gap-1.5"
        >
          <Lock className="w-3.5 h-3.5" />
          {t.premiumCta}
        </button>
      ) : (
        <p className="text-xs text-muted font-display mt-3 text-center leading-relaxed">{t.premiumComingSoon}</p>
      )}
    </div>
  );
}
