import { ReactNode } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Home, LayoutGrid } from "lucide-react";
import { ToolDefinition, TOOL_REGISTRY } from "../data/toolRegistry";
import { useLanguage } from "../i18n/LanguageContext";
import ToolCard from "./ToolCard";

interface ToolShellProps {
  tool: ToolDefinition;
  children: ReactNode;
}

export default function ToolShell({ tool, children }: ToolShellProps) {
  const { lang, dir } = useLanguage();
  const Icon = tool.icon;
  const related = TOOL_REGISTRY.filter((item) => item.slug !== tool.slug && item.category === tool.category).slice(0, 3);
  return (
    <main className="mx-auto max-w-6xl px-5 pb-20 pt-8 md:px-6">
      <nav className="mb-8 flex flex-wrap items-center gap-2 text-xs text-muted" aria-label="Breadcrumb">
        <Link to="/" className="inline-flex items-center gap-1.5 hover:text-ivory"><Home className="h-3.5 w-3.5" />{lang === "ar" ? "الرئيسية" : "Home"}</Link>
        <span>/</span>
        <Link to="/tools" className="inline-flex items-center gap-1.5 hover:text-ivory"><LayoutGrid className="h-3.5 w-3.5" />{lang === "ar" ? "مركز الأدوات" : "Tools center"}</Link>
        <span>/</span><span className="text-ivory">{tool.title[lang]}</span>
      </nav>
      <header className="mb-8 rounded-3xl border border-line/70 bg-gradient-to-br from-panel/55 to-void/70 p-6 md:p-9">
        <div className="flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
          <div className="max-w-3xl">
            <span className="mb-4 inline-flex rounded-2xl border border-gold/30 bg-gold/10 p-3 text-gold"><Icon className="h-6 w-6" /></span>
            <h1 className="font-display text-3xl font-extrabold md:text-4xl">{tool.title[lang]}</h1>
            <p className="mt-3 max-w-2xl text-sm leading-relaxed text-muted md:text-base">{tool.description[lang]}</p>
          </div>
          <Link to="/tools" className="inline-flex items-center justify-center gap-2 self-start rounded-xl border border-line px-4 py-2 text-xs text-muted transition hover:border-glow hover:text-ivory">
            <ArrowLeft className={`h-4 w-4 ${dir === "rtl" ? "rotate-180" : ""}`} />{lang === "ar" ? "كل الأدوات" : "All tools"}
          </Link>
        </div>
      </header>
      {children}
      {related.length > 0 && (
        <section className="mt-16 border-t border-line/50 pt-10">
          <h2 className="mb-5 font-display text-xl font-bold">{lang === "ar" ? "أدوات مرتبطة" : "Related tools"}</h2>
          <div className="grid gap-4 md:grid-cols-3">{related.map((item) => <ToolCard key={item.slug} tool={item} />)}</div>
        </section>
      )}
    </main>
  );
}
