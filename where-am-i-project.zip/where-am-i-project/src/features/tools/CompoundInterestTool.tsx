import { useMemo, useState } from "react";
import { Coins, Landmark, Sparkles } from "lucide-react";
import NumberField from "../../components/ui/NumberField";
import MetricCard from "../../components/ui/MetricCard";
import LineChart from "../../components/charts/LineChart";
import AIInsightPanel from "../../components/AIInsightPanel";
import ReportActions from "../../components/ReportActions";
import { calculateCompoundInterest } from "../../lib/financial";
import { formatCurrency } from "../../lib/format";
import { useLanguage } from "../../i18n/LanguageContext";

export default function CompoundInterestTool() {
  const { lang } = useLanguage();
  const locale = lang === "ar" ? "ar-SA" : "en-US";
  const [initial, setInitial] = useState(10000);
  const [monthly, setMonthly] = useState(500);
  const [annualReturn, setAnnualReturn] = useState(7);
  const [years, setYears] = useState(15);
  const result = useMemo(() => calculateCompoundInterest({ initialInvestment: initial, monthlyContribution: monthly, annualReturn, years }), [initial, monthly, annualReturn, years]);
  const recommendations = useMemo(() => lang === "ar"
    ? ["اختبر عائداً أقل من المتوقع لمعرفة السيناريو المحافظ.", "الاستمرارية في المساهمة الشهرية أهم من محاولة توقيت السوق.", "ضع في الاعتبار الرسوم والتضخم والضرائب حسب بلدك."]
    : ["Test a lower expected return to understand the conservative scenario.", "Consistent monthly contributions generally matter more than market timing.", "Account for fees, inflation, and taxes in your jurisdiction."], [lang]);

  return (
    <div className="tool-grid">
      <section className="tool-form-card">
        <h2 className="tool-section-title">{lang === "ar" ? "مدخلات الاستثمار" : "Investment inputs"}</h2>
        <div className="space-y-5">
          <NumberField label={lang === "ar" ? "الاستثمار الأولي" : "Initial investment"} value={initial} onChange={setInitial} suffix="USD" />
          <NumberField label={lang === "ar" ? "المساهمة الشهرية" : "Monthly contribution"} value={monthly} onChange={setMonthly} suffix="USD" />
          <NumberField label={lang === "ar" ? "العائد السنوي المتوقع" : "Expected annual return"} value={annualReturn} onChange={setAnnualReturn} min={-20} max={50} step={0.1} suffix="%" />
          <NumberField label={lang === "ar" ? "مدة الاستثمار" : "Investment duration"} value={years} onChange={setYears} min={1} max={60} suffix={lang === "ar" ? "سنة" : "years"} />
        </div>
      </section>
      <div className="space-y-6 min-w-0">
        <section className="grid gap-4 sm:grid-cols-3">
          <MetricCard label={lang === "ar" ? "القيمة المستقبلية" : "Future value"} value={formatCurrency(result.futureValue, "USD", locale)} icon={<Sparkles className="h-4 w-4 text-gold" />} emphasis />
          <MetricCard label={lang === "ar" ? "إجمالي المساهمات" : "Total contributions"} value={formatCurrency(result.totalContributions, "USD", locale)} icon={<Landmark className="h-4 w-4 text-glow" />} />
          <MetricCard label={lang === "ar" ? "العائد التراكمي" : "Compound return"} value={formatCurrency(result.totalInterest, "USD", locale)} icon={<Coins className="h-4 w-4 text-glow" />} />
        </section>
        <LineChart labels={result.projection.map((point) => point.label)} series={[{ name: lang === "ar" ? "القيمة" : "Value", values: result.projection.map((point) => point.value) }, { name: lang === "ar" ? "المساهمات" : "Contributions", values: result.projection.map((point) => point.contribution ?? 0), dashed: true }]} valueFormatter={(value) => formatCurrency(value, "USD", locale)} />
        <AIInsightPanel tool={lang === "ar" ? "الفائدة المركبة" : "Compound Interest"} metrics={{ initial, monthly, annualReturn, years, futureValue: result.futureValue }} />
        <ReportActions toolName="Where Am I Financial Center" title={lang === "ar" ? "تقرير الفائدة المركبة" : "Compound interest report"} summary={lang === "ar" ? "توقع تراكمي للاستثمار وفق المدخلات الحالية." : "A compounding projection based on the current assumptions."} userInfo={[{ label: lang === "ar" ? "الاستثمار الأولي" : "Initial investment", value: formatCurrency(initial, "USD", locale) }, { label: lang === "ar" ? "المساهمة الشهرية" : "Monthly contribution", value: formatCurrency(monthly, "USD", locale) }, { label: lang === "ar" ? "العائد السنوي" : "Annual return", value: `${annualReturn}%` }, { label: lang === "ar" ? "المدة" : "Duration", value: `${years} ${lang === "ar" ? "سنة" : "years"}` }]} metrics={[{ label: lang === "ar" ? "القيمة المستقبلية" : "Future value", value: formatCurrency(result.futureValue, "USD", locale) }, { label: lang === "ar" ? "المساهمات" : "Contributions", value: formatCurrency(result.totalContributions, "USD", locale) }, { label: lang === "ar" ? "العائد" : "Return", value: formatCurrency(result.totalInterest, "USD", locale) }]} recommendations={recommendations} calculator="compound-interest" />
      </div>
    </div>
  );
}
