export interface WellnessInput {
  age: number;
  sleepHours: number;
  activityLevel: "low" | "medium" | "high";
  habits: string[]; // ids من WELLNESS_HABITS
}

export interface WellnessHabit {
  id: string;
  label: string;
  labelEn: string;
  effect: number; // + يزيد "العمر الصحي" التقديري، - ينقصه
}

export const WELLNESS_HABITS: WellnessHabit[] = [
  { id: "exercise", label: "أمارس رياضة بانتظام", labelEn: "I exercise regularly", effect: -2 },
  { id: "water", label: "أشرب كمية كافية من الماء", labelEn: "I drink enough water", effect: -1 },
  { id: "balanced_meals", label: "غذائي متوازن غالباً", labelEn: "My meals are usually balanced", effect: -1 },
  { id: "smoking", label: "أدخن", labelEn: "I smoke", effect: 4 },
  { id: "sedentary", label: "أجلس لساعات طويلة يومياً", labelEn: "I sit for long hours daily", effect: 2 },
  { id: "late_sleep", label: "أسهر لوقت متأخر باستمرار", labelEn: "I stay up very late regularly", effect: 1 },
  { id: "high_stress", label: "أشعر بتوتر أو ضغط مستمر", labelEn: "I feel constant stress", effect: 2 },
  { id: "social", label: "أقضي وقت جيد مع أهلي وأصدقائي", labelEn: "I spend good time with family/friends", effect: -1 },
];

export interface WellnessResult {
  estimatedAge: number;
  diff: number; // موجب = أكبر من العمر الفعلي، سالب = أصغر
}

export function calculateWellnessAge(input: WellnessInput): WellnessResult {
  let adjustment = 0;

  // النوم المثالي تقريباً بين 7-9 ساعات
  if (input.sleepHours >= 7 && input.sleepHours <= 9) adjustment -= 1;
  else if (input.sleepHours < 5 || input.sleepHours > 10) adjustment += 2;
  else adjustment += 0.5;

  if (input.activityLevel === "high") adjustment -= 3;
  else if (input.activityLevel === "low") adjustment += 2;

  for (const habitId of input.habits) {
    const habit = WELLNESS_HABITS.find((h) => h.id === habitId);
    if (habit) adjustment += habit.effect;
  }

  // تحديد الحد الأقصى للتغيير عشان النتيجة تظل معقولة وترفيهية
  adjustment = Math.max(-10, Math.min(10, adjustment));

  const estimatedAge = Math.max(1, Math.round(input.age + adjustment));

  return {
    estimatedAge,
    diff: estimatedAge - input.age,
  };
}
