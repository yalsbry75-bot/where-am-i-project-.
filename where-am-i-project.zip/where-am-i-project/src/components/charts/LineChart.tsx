export interface ChartSeries {
  name: string;
  values: number[];
  stroke?: string;
  dashed?: boolean;
}

interface LineChartProps {
  labels: string[];
  series: ChartSeries[];
  height?: number;
  valueFormatter?: (value: number) => string;
}

export default function LineChart({ labels, series, height = 240, valueFormatter = (value) => Math.round(value).toLocaleString() }: LineChartProps) {
  const width = 760;
  const padding = { top: 24, right: 18, bottom: 36, left: 74 };
  const allValues = series.flatMap((item) => item.values).filter(Number.isFinite);
  const max = Math.max(1, ...allValues);
  const min = Math.min(0, ...allValues);
  const range = Math.max(1, max - min);
  const plotWidth = width - padding.left - padding.right;
  const plotHeight = height - padding.top - padding.bottom;
  const x = (index: number, count: number) => padding.left + (count <= 1 ? plotWidth / 2 : index / (count - 1) * plotWidth);
  const y = (value: number) => padding.top + (max - value) / range * plotHeight;
  const gridValues = [0, 0.25, 0.5, 0.75, 1].map((ratio) => min + range * ratio);
  const defaultStrokes = ["#F2C94C", "#4C7CFF", "#93A0C4"];

  return (
    <div className="overflow-x-auto rounded-2xl border border-line/70 bg-void/45 p-3">
      <svg viewBox={`0 0 ${width} ${height}`} className="min-w-[620px] w-full" role="img" aria-label="Interactive financial projection chart">
        {gridValues.map((value) => (
          <g key={value}>
            <line x1={padding.left} y1={y(value)} x2={width - padding.right} y2={y(value)} stroke="#2A3564" strokeWidth="1" opacity="0.7" />
            <text x={padding.left - 10} y={y(value) + 4} textAnchor="end" fill="#93A0C4" fontSize="11">{valueFormatter(value)}</text>
          </g>
        ))}
        {labels.map((label, index) => {
          const every = Math.max(1, Math.ceil(labels.length / 7));
          if (index % every !== 0 && index !== labels.length - 1) return null;
          return <text key={`${label}-${index}`} x={x(index, labels.length)} y={height - 12} textAnchor="middle" fill="#93A0C4" fontSize="11">{label}</text>;
        })}
        {series.map((item, seriesIndex) => {
          const points = item.values.map((value, index) => `${x(index, item.values.length)},${y(value)}`).join(" ");
          const stroke = item.stroke ?? defaultStrokes[seriesIndex % defaultStrokes.length];
          return (
            <g key={item.name}>
              <polyline points={points} fill="none" stroke={stroke} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" strokeDasharray={item.dashed ? "8 7" : undefined} />
              {item.values.map((value, index) => (
                <circle key={`${item.name}-${index}`} cx={x(index, item.values.length)} cy={y(value)} r="3.5" fill={stroke}>
                  <title>{`${item.name}: ${valueFormatter(value)}`}</title>
                </circle>
              ))}
            </g>
          );
        })}
      </svg>
      <div className="flex flex-wrap justify-center gap-4 pb-2 text-xs text-muted">
        {series.map((item, index) => (
          <span key={item.name} className="flex items-center gap-2">
            <span className="h-0.5 w-5" style={{ background: item.stroke ?? defaultStrokes[index % defaultStrokes.length] }} />
            {item.name}
          </span>
        ))}
      </div>
    </div>
  );
}
