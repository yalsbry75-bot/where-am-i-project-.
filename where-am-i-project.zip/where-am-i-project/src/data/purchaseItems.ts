export interface PurchaseItem {
  id: string;
  name: string;
  nameEn: string;
  priceUSD: number;
  icon: string; // اسم أيقونة من lucide-react
}

// ⚠️ أسعار تقريبية توضيحية لأغراض العرض فقط — تختلف بشدة حسب البلد والمدينة والموديل.
export const PURCHASE_ITEMS: PurchaseItem[] = [
  { id: "phone", name: "هاتف حديث", nameEn: "Modern smartphone", priceUSD: 800, icon: "Smartphone" },
  { id: "laptop", name: "لابتوب", nameEn: "Laptop", priceUSD: 1200, icon: "Laptop" },
  { id: "tv", name: "تلفزيون ذكي", nameEn: "Smart TV", priceUSD: 500, icon: "Tv" },
  { id: "trip", name: "رحلة سفر (أسبوع)", nameEn: "Trip (1 week)", priceUSD: 1500, icon: "Plane" },
  { id: "car", name: "سيارة اقتصادية", nameEn: "Economy car", priceUSD: 18000, icon: "Car" },
  { id: "apartment", name: "شقة صغيرة", nameEn: "Small apartment", priceUSD: 60000, icon: "Home" },
];
