import { useEffect } from "react";
import { useParams, Link, Navigate } from "react-router-dom";
import { useCountries } from "../hooks/useCountries";
import { countrySlug, countryPageMeta } from "../lib/seo";
import { useSEO } from "../hooks/useSEO";
import { useLanguage } from "../i18n/LanguageContext";
import { getGlobalPercentile } from "../lib/incomeCalculator";
import CountryComparisonSection from "../components/CountryComparisonSection";
import { track } from "../lib/analytics";
import { ArrowLeft } from "lucide-react";

export default function CountryPage() {
  const { slug } = useParams();
  const { lang } = useLanguage();
  const COUNTRIES = useCountries();
  const country = COUNTRIES.find((c) => countrySlug(c) === slug);

  useEffect(() => {
    track({ type: "page_view", page: `country/${slug}` });
  }, [slug]);

  const meta = country ? countryPageMeta(country, lang) : { title: "", description: "" };
  useSEO({
    title: meta.title,
    description: meta.description,
    path: country ? `/country/${countrySlug(country)}` : "/",
  });

  if (!country) return <Navigate to="/" replace />;

  const countryPercentile = getGlobalPercentile(country.avgMonthlyUSD * 12);
  const countryName = lang === "ar" ? country.name : country.nameEn;

  return (
    <main className="max-w-4xl mx-auto px-6 pt-10 pb-16">
      <Link to="/" className="inline-flex items-center gap-1.5 text-xs font-display text-muted hover:text-ivory mb-8">
        <ArrowLeft className="w-3.5 h-3.5 rotate-180" />
        {lang === "ar" ? "الصفحة الرئيسية" : "Home"}
      </Link>

      <h1 className="font-display font-extrabold text-3xl md:text-4xl mb-3">
        {lang === "ar"
          ? `متوسط الراتب في ${countryName} مقارنة بالعالم`
          : `Average Salary in ${countryName} vs the World`}
      </h1>
      <p className="font-display text-muted leading-relaxed max-w-xl mb-10">
        {lang === "ar"
          ? `نظرة سريعة على متوسط الدخل الشهري في ${countryName}، وكيف يقارن بمتوسط الدخل العالمي ومؤشر تكلفة المعيشة.`
          : `A quick look at the average monthly income in ${countryName}, and how it compares to the global income average and cost of living index.`}
      </p>

      <div className="grid sm:grid-cols-3 gap-4 mb-12">
        <StatBox
          label={lang === "ar" ? "متوسط الراتب الشهري" : "Average monthly salary"}
          value={`$${country.avgMonthlyUSD.toLocaleString()}`}
        />
        <StatBox
          label={lang === "ar" ? "مؤشر تكلفة المعيشة" : "Cost of living index"}
          value={`${country.costOfLivingIndex}`}
        />
        <StatBox
          label={lang === "ar" ? "الترتيب العالمي التقريبي" : "Approx. global percentile"}
          value={`${Math.round(countryPercentile)}٪`}
        />
      </div>

      <div className="rounded-2xl p-6 md:p-8 bg-panel/25 border border-gold/30 text-center mb-14">
        <p className="font-display mb-4">
          {lang === "ar" ? "شوف وين يقف دخلك أنت شخصياً بين سكان العالم" : "See where your own income stands"}
        </p>
        <Link
          to="/#income-calculator"
          className="inline-block font-display font-bold rounded-xl px-6 py-3 bg-gradient-to-l from-gold to-goldBright text-panel"
        >
          {lang === "ar" ? "احسب دخلك الآن" : "Calculate your income"}
        </Link>
      </div>

      <CountryComparisonSection defaultCountryCode={country.code} />

      <p className="text-[11px] text-muted/70 font-display text-center mt-10">
        {lang === "ar"
          ? "الأرقام تقديرية توضيحية لأغراض العرض، وليست بيانات اقتصادية رسمية."
          : "Numbers are illustrative estimates, not official economic data."}
      </p>
    </main>
  );
}

function StatBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl p-5 bg-void/40 border border-line text-center">
      <div className="font-num font-bold text-2xl text-goldBright mb-1">{value}</div>
      <div className="text-xs font-display text-muted">{label}</div>
    </div>
  );
}
