import { useEffect, useState } from "react";
import { Download, X } from "lucide-react";
import { useLanguage } from "../i18n/LanguageContext";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export default function InstallPrompt() {
  const { t } = useLanguage();
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [visible, setVisible] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      setVisible(true);
    };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  if (!visible || dismissed || !deferredPrompt) return null;

  const handleInstall = async () => {
    await deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    setVisible(false);
    setDeferredPrompt(null);
  };

  return (
    <div className="fixed bottom-4 inset-x-4 z-50 max-w-md mx-auto">
      <div className="rounded-2xl p-4 flex items-center gap-3 bg-panel/95 border border-gold/40 backdrop-blur-md shadow-xl">
        <div className="w-10 h-10 rounded-xl bg-void flex items-center justify-center shrink-0">
          <Download className="w-4 h-4 text-goldBright" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-display font-bold text-sm">{t.installTitle}</p>
          <p className="font-display text-xs text-muted">{t.installSubtitle}</p>
        </div>
        <button
          onClick={handleInstall}
          className="font-display text-xs font-bold px-3 py-2 rounded-lg bg-gradient-to-l from-gold to-goldBright text-panel shrink-0"
        >
          {t.installAction}
        </button>
        <button
          onClick={() => setDismissed(true)}
          className="text-muted hover:text-ivory shrink-0"
          aria-label={t.installDismiss}
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
