export interface InsightContext {
  tool: string;
  metrics: Record<string, number | string | boolean>;
  lang: "ar" | "en";
}

export interface AIProvider {
  explain(context: InsightContext): Promise<string[]>;
}

export class LocalInsightProvider implements AIProvider {
  async explain(context: InsightContext): Promise<string[]> {
    const { metrics, lang, tool } = context;
    const values = Object.values(metrics).filter((value): value is number => typeof value === "number" && Number.isFinite(value));
    const maxValue = values.length ? Math.max(...values) : 0;
    if (lang === "ar") {
      return [
        `يعتمد هذا التحليل على المدخلات الحالية في أداة ${tool} ويتحدث فوراً عند تعديلها.`,
        maxValue > 0 ? "ركّز على المؤشر الأكبر أثراً قبل إجراء تغييرات صغيرة متعددة." : "أدخل قيماً موجبة للحصول على توصيات أكثر دقة.",
        "جرّب سيناريو محافظ وآخر متفائل، ثم قارن الفارق قبل اتخاذ قرار مالي.",
      ];
    }
    return [
      `This explanation is generated from the current ${tool} inputs and updates whenever they change.`,
      maxValue > 0 ? "Prioritize the metric with the largest financial impact before optimizing smaller items." : "Enter positive values to receive more specific guidance.",
      "Compare a conservative scenario with an optimistic one before making a financial decision.",
    ];
  }
}

export class ExternalAIProvider implements AIProvider {
  constructor(private readonly endpoint: string, private readonly apiKey?: string) {}

  async explain(context: InsightContext): Promise<string[]> {
    if (!this.endpoint) return new LocalInsightProvider().explain(context);
    const response = await fetch(this.endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(this.apiKey ? { Authorization: `Bearer ${this.apiKey}` } : {}),
      },
      body: JSON.stringify(context),
    });
    if (!response.ok) throw new Error("AI provider request failed");
    const payload = await response.json() as { insights?: string[] };
    return payload.insights?.length ? payload.insights : new LocalInsightProvider().explain(context);
  }
}

const configuredEndpoint = import.meta.env.VITE_AI_API_ENDPOINT?.trim();
const configuredApiKey = import.meta.env.VITE_AI_API_KEY?.trim();

export const aiProvider: AIProvider = configuredEndpoint
  ? new ExternalAIProvider(configuredEndpoint, configuredApiKey)
  : new LocalInsightProvider();
