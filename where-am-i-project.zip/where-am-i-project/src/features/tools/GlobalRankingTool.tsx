import { useMemo, useState } from "react";
import { Award, Crown, Gauge, Globe2 } from "lucide-react";
import NumberField from "../../components/ui/NumberField";
import MetricCard from "../../components/ui/MetricCard";
import DonutGauge from "../../components/charts/DonutGauge";
import BarComparison from "../../components/charts/BarComparison";
import AIInsightPanel from "../../components/AIInsightPanel";
import ReportActions from "../../components/ReportActions";
import { useCountries } from "../../hooks/useCountries";
import { calculateRanking } from "../../lib/globalRanking";
import { formatCurrency, formatNumber } from "../../lib/format";
import { useLanguage } from "../../i18n/LanguageContext";

export default function GlobalRankingTool() {
  const { lang } = useLanguage();
  const locale = lang === "ar" ? "ar-SA" : "en-US";
  const countries = useCountries();
  const [countryCode, setCountryCode] = useState("SA");
  const country = countries.find((item) => item.code === countryCode) ?? countries[0];
  const [monthlyIncomeLocal, setMonthlyIncomeLocal] = useState(12000);
  const monthlyUSD = monthlyIncomeLocal / Math.max(0.0001, country.rateToUSD);
  const result = useMemo(() => calculateRanking(monthlyUSD, country), [monthlyUSD, country]);
  const recommendations = useMemo(() => lang === "ar" ? ["الترتيب النسبي لا يقيس وحده الاستقرار المالي أو جودة الحياة.", "قارن الدخل الصافي بعد التزامات السكن والديون والادخار.", "راقب القوة الشرائية لا الرقم الاسمي للراتب فقط."] : ["Relative rank alone does not measure financial stability or quality of life.", "Compare net income after housing, debt, and savings commitments.", "Track purchasing power rather than nominal salary alone."], [lang]);

  return (
    <div className="tool-grid">
      <section className="tool-form-card">
        <h2 className="tool-section-title">{lang === "ar" ? "بيانات الترتيب" : "Ranking inputs"}</h2>
        <div className="space-y-5">
          <label className="block"><span className="mb-2 block text-sm font-display font-bold">{lang === "ar" ? "الدولة" : "Country"}</span><select value={countryCode} onChange={(event) => setCountryCode(event.target.value)} className="w-full rounded-xl border border-line bg-void/70 px-4 py-3 text-sm outline-none focus:border-glow">{countries.map((item) => <option key={item.code} value={item.code}>{lang === "ar" ? item.name : item.nameEn}</option>)}</select></label>
          <NumberField label={lang === "ar" ? "الدخل الشهري" : "Monthly income"} value={monthlyIncomeLocal} onChange={setMonthlyIncomeLocal} suffix={country.currencyEn} />
          <div className="rounded-xl border border-line/60 bg-void/50 p-3 text-xs text-muted">{lang === "ar" ? "ما يعادل تقريباً" : "Approximately"} <strong className="font-num text-ivory">{formatCurrency(monthlyUSD, "USD", locale)}</strong></div>
        </div>
      </section>
      <div className="space-y-6 min-w-0">
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <MetricCard label={lang === "ar" ? "المئين العالمي" : "Global percentile"} value={`${formatNumber(result.globalPercentile, locale)}%`} icon={<Globe2 className="h-4 w-4 text-gold" />} emphasis />
          <MetricCard label={lang === "ar" ? "المئين داخل الدولة" : "Country percentile"} value={`${formatNumber(result.countryPercentile, locale)}%`} icon={<Award className="h-4 w-4 text-glow" />} />
          <MetricCard label={lang === "ar" ? "أعلى 1٪ عالمياً" : "Global top 1%"} value={result.topOneGlobal ? (lang === "ar" ? "مؤهل تقديرياً" : "Estimated eligible") : (lang === "ar" ? "غير محقق" : "Not reached")} icon={<Crown className="h-4 w-4 text-gold" />} />
          <MetricCard label={lang === "ar" ? "مؤشر القوة الشرائية" : "Purchasing power index"} value={formatCurrency(result.purchasingPowerIndex, "USD", locale)} icon={<Gauge className="h-4 w-4 text-glow" />} />
        </section>
        <section className="grid gap-4 sm:grid-cols-2"><DonutGauge value={result.globalPercentile} label={lang === "ar" ? "ترتيب الدخل عالمياً" : "Global income rank"} /><DonutGauge value={result.livingStandardScore} label={lang === "ar" ? "مؤشر مستوى المعيشة" : "Living standard score"} /></section>
        <section><h2 className="tool-section-title">{lang === "ar" ? "مقارنة المؤشرات" : "Indicator comparison"}</h2><BarComparison items={[{ label: lang === "ar" ? "العالمي" : "Global", value: result.globalPercentile, displayValue: `${formatNumber(result.globalPercentile, locale)}%` }, { label: lang === "ar" ? "داخل الدولة" : "Country", value: result.countryPercentile, displayValue: `${formatNumber(result.countryPercentile, locale)}%` }, { label: lang === "ar" ? "مستوى المعيشة" : "Living standard", value: result.livingStandardScore, displayValue: `${formatNumber(result.livingStandardScore, locale)}/100` }]} /></section>
        {!result.topOneGlobal && <div className="rounded-2xl border border-gold/30 bg-gold/10 p-4 text-sm"><span className="text-muted">{lang === "ar" ? "الفجوة السنوية التقديرية للوصول إلى أعلى 1٪ عالمياً:" : "Estimated annual gap to the global top 1%:"}</span> <strong className="font-num text-gold">{formatCurrency(result.globalTopOneGap, "USD", locale)}</strong></div>}
        <AIInsightPanel tool={lang === "ar" ? "الترتيب العالمي" : "Global Ranking"} metrics={{ monthlyUSD, globalPercentile: result.globalPercentile, countryPercentile: result.countryPercentile, topOneGlobal: result.topOneGlobal, purchasingPower: result.purchasingPowerIndex, livingStandard: result.livingStandardScore }} />
        <ReportActions toolName="Where Am I Global Intelligence" title={lang === "ar" ? "تقرير الترتيب العالمي" : "Global ranking report"} summary={lang === "ar" ? "تحليل تقريبي لترتيب الدخل والقوة الشرائية ومستوى المعيشة." : "An estimated analysis of income rank, purchasing power, and living standard."} userInfo={[{ label: lang === "ar" ? "الدولة" : "Country", value: lang === "ar" ? country.name : country.nameEn }, { label: lang === "ar" ? "الدخل المحلي" : "Local income", value: `${formatNumber(monthlyIncomeLocal, locale)} ${country.currencyEn}` }, { label: lang === "ar" ? "الدخل بالدولار" : "Income in USD", value: formatCurrency(monthlyUSD, "USD", locale) }]} metrics={[{ label: lang === "ar" ? "المئين العالمي" : "Global percentile", value: `${formatNumber(result.globalPercentile, locale)}%` }, { label: lang === "ar" ? "المئين المحلي" : "Country percentile", value: `${formatNumber(result.countryPercentile, locale)}%` }, { label: lang === "ar" ? "القوة الشرائية" : "Purchasing power", value: formatCurrency(result.purchasingPowerIndex, "USD", locale) }, { label: lang === "ar" ? "مستوى المعيشة" : "Living standard", value: `${formatNumber(result.livingStandardScore, locale)}/100` }]} recommendations={recommendations} calculator="global-ranking" />
        <p className="text-[11px] leading-relaxed text-muted/80">{lang === "ar" ? "الترتيبات تقديرية وتعتمد على منحنيات توزيع مبسطة وبيانات المشروع الحالية." : "Rankings are illustrative and use simplified distribution curves and the project's current data."}</p>
      </div>
    </div>
  );
}
