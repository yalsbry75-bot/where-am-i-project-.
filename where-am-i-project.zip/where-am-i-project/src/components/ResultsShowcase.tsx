import { useLanguage } from "../i18n/LanguageContext";

export default function ResultsShowcase() {
  const { t } = useLanguage();

  return (
    <section className="py-14">
      <h2 className="font-display font-extrabold text-2xl md:text-3xl text-center mb-2">
        {t.resultsTitle}
      </h2>
      <p className="text-xs text-muted font-display text-center mb-8">{t.resultsNote}</p>
      <div className="grid sm:grid-cols-3 gap-4">
        {t.resultsItems.map((r, i) => (
          <div key={i} className="rounded-xl p-5 bg-gradient-to-b from-glow/10 to-panel/20 border border-glow/20 text-center">
            <div className="font-num font-bold text-4xl text-goldBright mb-2">{r.pct}٪</div>
            <p className="text-sm font-display text-ivory/90">{r.line}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
