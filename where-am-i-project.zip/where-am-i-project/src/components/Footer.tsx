import { Link } from "react-router-dom";
import { TOOL_REGISTRY } from "../data/toolRegistry";
import { useLanguage } from "../i18n/LanguageContext";

export default function Footer() {
  const { t, lang } = useLanguage();
  return (
    <footer className="border-t border-line/40 bg-void/70">
      <div className="mx-auto grid max-w-6xl gap-8 px-6 py-12 sm:grid-cols-2 lg:grid-cols-4">
        <div className="sm:col-span-2"><p className="font-display font-extrabold">{t.siteName}</p><p className="mt-3 max-w-md text-xs leading-relaxed text-muted">{lang === "ar" ? "منصة عالمية للذكاء المالي والقوة الشرائية وتخطيط الحياة، مع حسابات محلية على جهاز المستخدم." : "A global platform for financial intelligence, purchasing power, and life planning, with local-first calculations."}</p></div>
        <div><p className="mb-3 text-xs font-bold text-ivory">{lang === "ar" ? "الأدوات" : "Tools"}</p><div className="space-y-2">{TOOL_REGISTRY.slice(0, 4).map((tool) => <Link key={tool.slug} to={`/tools/${tool.slug}`} className="block text-xs text-muted hover:text-gold">{tool.title[lang]}</Link>)}</div></div>
        <div><p className="mb-3 text-xs font-bold text-ivory">{lang === "ar" ? "المنصة" : "Platform"}</p><div className="space-y-2"><Link to="/tools" className="block text-xs text-muted hover:text-gold">{lang === "ar" ? "مركز الأدوات" : "Tools center"}</Link><Link to="/admin" className="block text-xs text-muted hover:text-gold">{lang === "ar" ? "لوحة التحكم" : "Admin dashboard"}</Link></div></div>
      </div>
      <div className="border-t border-line/30 px-6 py-5 text-center text-[11px] text-muted/70"><p>{t.footer} · Version 2.0</p></div>
    </footer>
  );
}
