import { useState } from "react";
import { useLanguage } from "../i18n/LanguageContext";
import { validateUserData } from "../i18n/validation";
import { useCountries } from "../hooks/useCountries";
import { UserData, FormErrors } from "../types";
import { track } from "../lib/analytics";

interface Props {
  onSubmit: (data: UserData) => void;
}

export default function UserDataForm({ onSubmit }: Props) {
  const { t, lang } = useLanguage();
  const COUNTRIES = useCountries();

  const [countryCode, setCountryCode] = useState("");
  const [income, setIncome] = useState("");
  const [age, setAge] = useState("");
  const [profession, setProfession] = useState("");
  const [familySize, setFamilySize] = useState("");
  const [errors, setErrors] = useState<FormErrors>({});
  const [touched, setTouched] = useState(false);

  const selectedCountry = COUNTRIES.find((c) => c.code === countryCode);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTouched(true);

    const data: Partial<UserData> = {
      countryCode: countryCode || undefined,
      monthlyIncome: income === "" ? NaN : parseFloat(income),
      age: age === "" ? undefined : parseFloat(age),
      profession: profession.trim() || undefined,
      familySize: familySize === "" ? undefined : parseFloat(familySize),
    };

    const validationErrors = validateUserData(data, lang);
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      track({ type: "calculator_used", calculator: "income" });
      track({ type: "country_selected", countryCode: data.countryCode!, context: "income" });
      onSubmit(data as UserData);
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      noValidate
      className="rounded-2xl p-6 md:p-7 bg-panel/25 border border-glow/20 backdrop-blur-sm max-w-lg mx-auto"
    >
      <h3 className="font-display font-bold text-lg mb-1">{t.formTitle}</h3>
      <p className="text-xs text-muted font-display mb-6">{t.formSubtitle}</p>

      {/* الدولة */}
      <div className="mb-4">
        <label className="block font-display text-sm text-muted mb-1.5">{t.fieldCountry}</label>
        <select
          value={countryCode}
          onChange={(e) => setCountryCode(e.target.value)}
          className={`w-full font-display bg-void border rounded-xl px-3 py-2.5 outline-none transition-colors ${
            touched && errors.countryCode ? "border-red-400" : "border-line focus:border-glow"
          }`}
        >
          <option value="">{t.fieldCountryPlaceholder}</option>
          {COUNTRIES.map((c) => (
            <option key={c.code} value={c.code}>
              {lang === "ar" ? c.name : c.nameEn}
            </option>
          ))}
        </select>
        {touched && errors.countryCode && (
          <p className="text-xs text-red-400 font-display mt-1">{errors.countryCode}</p>
        )}
      </div>

      {/* العملة (تلقائي) */}
      {selectedCountry && (
        <div className="mb-4">
          <label className="block font-display text-sm text-muted mb-1.5">{t.fieldCurrency}</label>
          <div className="w-full font-display bg-void/50 border border-line/60 rounded-xl px-3 py-2.5 text-muted">
            {lang === "ar" ? selectedCountry.currency : selectedCountry.currencyEn}
          </div>
        </div>
      )}

      {/* الدخل الشهري */}
      <div className="mb-4">
        <label className="block font-display text-sm text-muted mb-1.5">{t.fieldIncome}</label>
        <input
          type="number"
          inputMode="decimal"
          value={income}
          onChange={(e) => setIncome(e.target.value)}
          placeholder={t.fieldIncomePlaceholder}
          className={`w-full font-num text-lg bg-void border rounded-xl px-3 py-2.5 outline-none transition-colors placeholder:text-line ${
            touched && errors.monthlyIncome ? "border-red-400" : "border-line focus:border-glow"
          }`}
        />
        {touched && errors.monthlyIncome && (
          <p className="text-xs text-red-400 font-display mt-1">{errors.monthlyIncome}</p>
        )}
      </div>

      {/* حقول اختيارية */}
      <div className="grid grid-cols-2 gap-3 mb-2">
        <div>
          <label className="block font-display text-sm text-muted mb-1.5">{t.fieldAge}</label>
          <input
            type="number"
            inputMode="numeric"
            value={age}
            onChange={(e) => setAge(e.target.value)}
            placeholder={t.fieldAgePlaceholder}
            className={`w-full font-num bg-void border rounded-xl px-3 py-2.5 outline-none transition-colors placeholder:text-line ${
              touched && errors.age ? "border-red-400" : "border-line focus:border-glow"
            }`}
          />
          {touched && errors.age && <p className="text-xs text-red-400 font-display mt-1">{errors.age}</p>}
        </div>
        <div>
          <label className="block font-display text-sm text-muted mb-1.5">{t.fieldFamilySize}</label>
          <input
            type="number"
            inputMode="numeric"
            value={familySize}
            onChange={(e) => setFamilySize(e.target.value)}
            placeholder={t.fieldFamilySizePlaceholder}
            className={`w-full font-num bg-void border rounded-xl px-3 py-2.5 outline-none transition-colors placeholder:text-line ${
              touched && errors.familySize ? "border-red-400" : "border-line focus:border-glow"
            }`}
          />
          {touched && errors.familySize && (
            <p className="text-xs text-red-400 font-display mt-1">{errors.familySize}</p>
          )}
        </div>
      </div>

      <div className="mb-6">
        <label className="block font-display text-sm text-muted mb-1.5">{t.fieldProfession}</label>
        <input
          type="text"
          value={profession}
          onChange={(e) => setProfession(e.target.value)}
          placeholder={t.fieldProfessionPlaceholder}
          className="w-full font-display bg-void border border-line rounded-xl px-3 py-2.5 outline-none focus:border-glow transition-colors placeholder:text-line"
        />
      </div>

      <button
        type="submit"
        className="w-full font-display font-bold rounded-xl py-3 bg-gradient-to-l from-gold to-goldBright text-panel active:scale-[0.98] transition-transform"
      >
        {t.formSubmit}
      </button>
    </form>
  );
}
