import { useMemo, useState } from "react";
import { CalendarClock, CircleDollarSign, ReceiptText } from "lucide-react";
import NumberField from "../../components/ui/NumberField";
import MetricCard from "../../components/ui/MetricCard";
import LineChart from "../../components/charts/LineChart";
import AIInsightPanel from "../../components/AIInsightPanel";
import ReportActions from "../../components/ReportActions";
import { calculateDebt, calculateRequiredDebtPayment } from "../../lib/financial";
import { formatCurrency } from "../../lib/format";
import { useLanguage } from "../../i18n/LanguageContext";

export default function DebtPayoffTool() {
  const { lang } = useLanguage();
  const locale = lang === "ar" ? "ar-SA" : "en-US";
  const [principal, setPrincipal] = useState(30000);
  const [interestRate, setInterestRate] = useState(7.5);
  const [payment, setPayment] = useState(650);
  const [targetMonths, setTargetMonths] = useState(60);
  const result = useMemo(() => calculateDebt({ principal, annualInterestRate: interestRate, monthlyPayment: payment }), [principal, interestRate, payment]);
  const requiredPayment = useMemo(() => calculateRequiredDebtPayment(principal, interestRate, targetMonths), [principal, interestRate, targetMonths]);
  const monthsText = result.isPaymentSufficient ? `${result.months} ${lang === "ar" ? "شهر" : "months"}` : (lang === "ar" ? "دفعة غير كافية" : "Payment too low");
  const recommendations = useMemo(() => lang === "ar" ? ["أي دفعة إضافية تذهب لأصل الدين تقلل الفائدة والمدة.", "تأكد من عدم وجود غرامة سداد مبكر قبل زيادة الدفعات.", "قارن إعادة التمويل فقط بعد احتساب جميع الرسوم."] : ["Any extra principal payment reduces both interest and payoff time.", "Confirm that no early repayment penalty applies before increasing payments.", "Compare refinancing only after including all fees."], [lang]);

  return (
    <div className="tool-grid">
      <section className="tool-form-card">
        <h2 className="tool-section-title">{lang === "ar" ? "تفاصيل الدين" : "Debt details"}</h2>
        <div className="space-y-5">
          <NumberField label={lang === "ar" ? "الرصيد المتبقي" : "Remaining balance"} value={principal} onChange={setPrincipal} suffix="USD" />
          <NumberField label={lang === "ar" ? "نسبة الفائدة السنوية" : "Annual interest rate"} value={interestRate} onChange={setInterestRate} min={0} max={100} step={0.1} suffix="%" />
          <NumberField label={lang === "ar" ? "المدة المستهدفة" : "Target payoff term"} value={targetMonths} onChange={setTargetMonths} min={1} max={600} suffix={lang === "ar" ? "شهر" : "months"} />
          <NumberField label={lang === "ar" ? "الدفعة الشهرية" : "Monthly payment"} value={payment} onChange={setPayment} suffix="USD" hint={lang === "ar" ? `يجب أن تتجاوز الفائدة الشهرية: ${formatCurrency(result.minimumPayment, "USD", locale)}` : `Must exceed monthly interest: ${formatCurrency(result.minimumPayment, "USD", locale)}`} />
        </div>
      </section>
      <div className="space-y-6 min-w-0">
        {!result.isPaymentSufficient && principal > 0 && <div className="rounded-2xl border border-red-400/40 bg-red-400/10 p-4 text-sm text-red-100">{lang === "ar" ? "الدفعة الحالية لا تغطي الفائدة الشهرية، لذلك لن ينخفض الرصيد." : "The current payment does not cover monthly interest, so the balance will not decline."}</div>}
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <MetricCard label={lang === "ar" ? "الدفعة المقترحة للمدة" : "Payment for target term"} value={formatCurrency(requiredPayment, "USD", locale)} icon={<CircleDollarSign className="h-4 w-4 text-gold" />} />
          <MetricCard label={lang === "ar" ? "مدة السداد" : "Payoff timeline"} value={monthsText} icon={<CalendarClock className="h-4 w-4 text-gold" />} emphasis />
          <MetricCard label={lang === "ar" ? "إجمالي الفائدة" : "Total interest"} value={formatCurrency(result.totalInterest, "USD", locale)} icon={<CircleDollarSign className="h-4 w-4 text-glow" />} />
          <MetricCard label={lang === "ar" ? "إجمالي المدفوع" : "Total paid"} value={formatCurrency(result.totalPaid, "USD", locale)} icon={<ReceiptText className="h-4 w-4 text-glow" />} />
        </section>
        <LineChart labels={result.projection.map((point) => point.label)} series={[{ name: lang === "ar" ? "الرصيد المتبقي" : "Remaining balance", values: result.projection.map((point) => point.value) }]} valueFormatter={(value) => formatCurrency(value, "USD", locale)} />
        {result.schedule.length > 0 && <section className="rounded-2xl border border-line/70 bg-void/45 p-5"><h2 className="tool-section-title">{lang === "ar" ? "أول 12 دفعة" : "First 12 payments"}</h2><div className="overflow-x-auto"><table className="w-full min-w-[620px] text-xs"><thead className="text-muted"><tr><th className="table-cell">{lang === "ar" ? "الشهر" : "Month"}</th><th className="table-cell">{lang === "ar" ? "الدفعة" : "Payment"}</th><th className="table-cell">{lang === "ar" ? "الأصل" : "Principal"}</th><th className="table-cell">{lang === "ar" ? "الفائدة" : "Interest"}</th><th className="table-cell">{lang === "ar" ? "الرصيد" : "Balance"}</th></tr></thead><tbody>{result.schedule.slice(0, 12).map((row) => <tr key={row.month} className="border-t border-line/40"><td className="table-cell font-num">{row.month}</td><td className="table-cell font-num">{formatCurrency(row.payment, "USD", locale)}</td><td className="table-cell font-num">{formatCurrency(row.principal, "USD", locale)}</td><td className="table-cell font-num">{formatCurrency(row.interest, "USD", locale)}</td><td className="table-cell font-num">{formatCurrency(row.balance, "USD", locale)}</td></tr>)}</tbody></table></div></section>}
        <AIInsightPanel tool={lang === "ar" ? "سداد الديون" : "Debt Payoff"} metrics={{ principal, interestRate, monthlyPayment: payment, recommendedPayment: requiredPayment, months: Number.isFinite(result.months) ? result.months : 0, totalInterest: result.totalInterest }} />
        <ReportActions toolName="Where Am I Financial Center" title={lang === "ar" ? "تقرير سداد الدين" : "Debt payoff report"} summary={lang === "ar" ? "ملخص مسار السداد والفائدة وفق الدفعة الحالية." : "A summary of the payoff path and interest under the current payment."} userInfo={[{ label: lang === "ar" ? "الرصيد" : "Balance", value: formatCurrency(principal, "USD", locale) }, { label: lang === "ar" ? "الفائدة السنوية" : "Annual interest", value: `${interestRate}%` }, { label: lang === "ar" ? "الدفعة الحالية" : "Current payment", value: formatCurrency(payment, "USD", locale) }, { label: lang === "ar" ? "المدة المستهدفة" : "Target term", value: `${targetMonths} ${lang === "ar" ? "شهر" : "months"}` }]} metrics={[{ label: lang === "ar" ? "الدفعة المقترحة" : "Suggested payment", value: formatCurrency(requiredPayment, "USD", locale) }, { label: lang === "ar" ? "مدة السداد" : "Payoff timeline", value: monthsText }, { label: lang === "ar" ? "إجمالي الفائدة" : "Total interest", value: formatCurrency(result.totalInterest, "USD", locale) }, { label: lang === "ar" ? "إجمالي المدفوع" : "Total paid", value: formatCurrency(result.totalPaid, "USD", locale) }]} recommendations={recommendations} calculator="debt-payoff" />
      </div>
    </div>
  );
}
