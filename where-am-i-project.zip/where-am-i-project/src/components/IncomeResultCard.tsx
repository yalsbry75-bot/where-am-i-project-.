import { useLanguage } from "../i18n/LanguageContext";
import { useCountUp } from "../hooks/useCountUp";
import OrbitDial from "./OrbitDial";
import IncomeBarChart from "./IncomeBarChart";
import ShareCard from "./ShareCard";
import { IncomeResult, formatApproxPeople } from "../lib/incomeCalculator";
import { Country } from "../data/countries";

interface Props {
  result: IncomeResult;
  country: Country;
}

export default function IncomeResultCard({ result, country }: Props) {
  const { t, lang } = useLanguage();
  const animatedPct = useCountUp(result.globalPercentile, true);

  const continentName = lang === "ar" ? country.continent : country.continentEn;
  const countryName = lang === "ar" ? country.name : country.nameEn;

  const shareText =
    lang === "ar"
      ? `🌍 دخلي أعلى من ${Math.round(result.globalPercentile)}٪ من سكان العالم! اكتشف موقعك أنت أيضاً`
      : `🌍 My income is higher than ${Math.round(result.globalPercentile)}% of the world's population! Find your spot too`;

  return (
    <div className="rounded-2xl p-6 md:p-9 max-w-2xl mx-auto bg-gradient-to-b from-glow/10 to-panel/25 border border-gold/30">
      <div className="text-center">
        <p className="font-display text-muted mb-1">{t.resultHeading}</p>
        <div className="font-num font-bold text-6xl md:text-7xl text-goldBright">
          {animatedPct.toFixed(0)}٪
        </div>
        <p className="font-display text-muted mt-1">{t.resultOfWorld}</p>
        <p className="text-xs font-display text-muted/80 mt-2">
          {t.resultApproxRank} {formatApproxPeople(result.approxPeopleBelow, lang)}
        </p>
      </div>

      <div className="my-8">
        <OrbitDial percentile={result.globalPercentile} active />
      </div>

      <div className="grid sm:grid-cols-2 gap-3 mb-8">
        <div className="rounded-xl p-4 bg-void/40 border border-line text-center">
          <div className="font-num font-bold text-2xl mb-1" style={{ color: result.countryRatioPct >= 0 ? "#8FE3A0" : "#F5A3A3" }}>
            {result.countryRatioPct >= 0 ? "+" : ""}
            {result.countryRatioPct}٪
          </div>
          <p className="text-xs font-display text-muted">
            {result.countryRatioPct >= 0 ? t.higherThanCountry : t.lowerThanCountry} — {countryName}
          </p>
        </div>
        <div className="rounded-xl p-4 bg-void/40 border border-line text-center">
          <div className="font-num font-bold text-2xl mb-1" style={{ color: result.continentRatioPct >= 0 ? "#8FE3A0" : "#F5A3A3" }}>
            {result.continentRatioPct >= 0 ? "+" : ""}
            {result.continentRatioPct}٪
          </div>
          <p className="text-xs font-display text-muted">
            {result.continentRatioPct >= 0 ? t.higherThanContinent : t.lowerThanContinent} — {continentName}
          </p>
        </div>
      </div>

      <div className="rounded-xl p-5 bg-void/30 border border-line">
        <p className="text-sm font-display font-bold mb-4">{t.resultChartTitle}</p>
        <IncomeBarChart
          bars={[
            { label: t.chartYou, valueUSD: result.monthlyUSD, highlight: true },
            { label: t.chartCountry, valueUSD: country.avgMonthlyUSD },
            { label: t.chartContinent, valueUSD: result.continentAvgUSD },
            { label: t.chartWorld, valueUSD: result.globalMedianMonthlyUSD },
          ]}
        />
      </div>

      <ShareCard text={shareText} calculator="income" />
    </div>
  );
}
