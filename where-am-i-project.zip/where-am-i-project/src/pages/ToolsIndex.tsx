import { useMemo, useState } from "react";
import { BrainCircuit, Layers3, Search, ShieldCheck, Zap } from "lucide-react";
import ToolCard from "../components/ToolCard";
import { TOOL_REGISTRY, ToolCategory } from "../data/toolRegistry";
import { useLanguage } from "../i18n/LanguageContext";
import { useSEO } from "../hooks/useSEO";

export default function ToolsIndex() {
  const { lang } = useLanguage();
  const [category, setCategory] = useState<ToolCategory | "all">("all");
  const [query, setQuery] = useState("");
  const categories: Array<{ key: ToolCategory | "all"; ar: string; en: string }> = [
    { key: "all", ar: "الكل", en: "All" },
    { key: "finance", ar: "المال والثروة", en: "Finance" },
    { key: "global", ar: "المقارنات العالمية", en: "Global" },
    { key: "planning", ar: "تخطيط الحياة", en: "Planning" },
    { key: "health", ar: "الصحة", en: "Health" },
  ];
  const tools = useMemo(() => TOOL_REGISTRY.filter((tool) => {
    const categoryMatch = category === "all" || tool.category === category;
    const needle = query.trim().toLowerCase();
    const searchMatch = !needle || `${tool.title.ar} ${tool.title.en} ${tool.description.ar} ${tool.description.en}`.toLowerCase().includes(needle);
    return categoryMatch && searchMatch;
  }), [category, query]);

  useSEO({
    title: lang === "ar" ? "مركز الأدوات المالية والعالمية | Where Am I" : "Financial & Global Tools Center | Where Am I",
    description: lang === "ar" ? "أدوات احترافية للادخار والثروة والديون والقوة الشرائية والصحة وتخطيط الحياة." : "Professional tools for savings, wealth, debt, purchasing power, health, and life planning.",
    path: "/tools",
    structuredData: {
      "@context": "https://schema.org",
      "@type": "CollectionPage",
      name: lang === "ar" ? "مركز أدوات Where Am I" : "Where Am I Tools Center",
      hasPart: TOOL_REGISTRY.map((tool) => ({ "@type": "SoftwareApplication", name: tool.title[lang], url: `/tools/${tool.slug}` })),
    },
  });

  return (
    <main className="mx-auto max-w-6xl px-5 pb-20 pt-10 md:px-6">
      <section className="relative overflow-hidden rounded-3xl border border-line/70 bg-gradient-to-br from-panel/70 via-panel/30 to-void p-7 md:p-12">
        <div className="absolute -end-24 -top-24 h-72 w-72 rounded-full bg-glow/10 blur-3xl" />
        <div className="relative max-w-3xl">
          <p className="mb-3 text-xs font-bold uppercase tracking-[0.2em] text-gold">Where Am I · Version 2.0</p>
          <h1 className="font-display text-4xl font-extrabold leading-tight md:text-5xl">{lang === "ar" ? "مركز الذكاء المالي والحياة العالمية" : "Financial Intelligence & Global Life Center"}</h1>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-muted md:text-base">{lang === "ar" ? "منصة موحدة لتحليل الادخار والثروة والديون والمقارنات العالمية والقوة الشرائية والصحة وخطط الحياة." : "A unified platform for savings, wealth, debt, global comparisons, purchasing power, health, and life planning."}</p>
        </div>
        <div className="relative mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: Zap, ar: "حساب فوري", en: "Instant calculation" },
            { icon: BrainCircuit, ar: "تفسير ذكي", en: "Smart explanations" },
            { icon: ShieldCheck, ar: "بيانات محلية", en: "Local-first data" },
            { icon: Layers3, ar: "بنية قابلة للتوسع", en: "Scalable architecture" },
          ].map((item) => { const Icon = item.icon; return <div key={item.en} className="flex items-center gap-3 rounded-xl border border-line/60 bg-void/40 p-3 text-xs"><Icon className="h-4 w-4 text-gold" /><span>{lang === "ar" ? item.ar : item.en}</span></div>; })}
        </div>
      </section>

      <section className="py-10">
        <div className="mb-7 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap gap-2">{categories.map((item) => <button key={item.key} onClick={() => setCategory(item.key)} className={`rounded-full px-4 py-2 text-xs transition ${category === item.key ? "bg-gold text-void font-bold" : "border border-line text-muted hover:border-glow hover:text-ivory"}`}>{lang === "ar" ? item.ar : item.en}</button>)}</div>
          <label className="relative block min-w-[260px]"><Search className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={lang === "ar" ? "ابحث عن أداة..." : "Search tools..."} className="w-full rounded-xl border border-line bg-void/60 py-2.5 ps-10 pe-4 text-sm outline-none focus:border-glow" /></label>
        </div>
        {tools.length > 0 ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{tools.map((tool) => <ToolCard key={tool.slug} tool={tool} />)}</div> : <div className="rounded-2xl border border-dashed border-line p-12 text-center text-sm text-muted">{lang === "ar" ? "لا توجد أداة مطابقة للبحث." : "No matching tool found."}</div>}
      </section>
    </main>
  );
}
