// ⚠️ نفس ملاحظة countryStore.ts: هذا مخزَّن محلياً بمتصفح الأدمن، يحتاج ربط بباكيند
// حقيقي عشان يظهر لكل الزوار الفعليين لا بس لجهاز الأدمن.

const STORAGE_KEY = "waitw_sponsor_banner";

export interface SponsorBanner {
  enabled: boolean;
  sponsorName: string;
  title: string;
  description: string;
  linkUrl: string;
}

const DEFAULT_BANNER: SponsorBanner = {
  enabled: false,
  sponsorName: "",
  title: "",
  description: "",
  linkUrl: "",
};

export function getSponsorBanner(): SponsorBanner {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? { ...DEFAULT_BANNER, ...JSON.parse(raw) } : DEFAULT_BANNER;
  } catch {
    return DEFAULT_BANNER;
  }
}

export function setSponsorBanner(banner: SponsorBanner) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(banner));
  } catch {
    // تجاهل
  }
}
