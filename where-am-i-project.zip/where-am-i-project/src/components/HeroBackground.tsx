export default function HeroBackground() {
  return (
    <div className="pointer-events-none absolute inset-0 -z-10 overflow-hidden" aria-hidden="true">
      {/* توهّج أزرق كبير */}
      <div
        className="absolute -top-24 left-1/2 h-[420px] w-[420px] -translate-x-1/2 rounded-full opacity-40 blur-3xl animate-float-slow"
        style={{ background: "radial-gradient(circle, #4C7CFF 0%, transparent 70%)" }}
      />
      {/* توهّج ذهبي أصغر */}
      <div
        className="absolute top-10 right-[8%] h-[220px] w-[220px] rounded-full opacity-30 blur-3xl animate-float"
        style={{ background: "radial-gradient(circle, #D4AF37 0%, transparent 70%)" }}
      />
      <div
        className="absolute top-24 left-[6%] h-[180px] w-[180px] rounded-full opacity-25 blur-3xl animate-float"
        style={{ background: "radial-gradient(circle, #4C7CFF 0%, transparent 70%)", animationDelay: "-4s" }}
      />
      {/* نسيج نقطي خفيف */}
      <div className="absolute inset-0 bg-noise opacity-[0.35]" />
      {/* تدرّج تلاشي أسفل الهيرو */}
      <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-b from-transparent to-void" />
    </div>
  );
}
