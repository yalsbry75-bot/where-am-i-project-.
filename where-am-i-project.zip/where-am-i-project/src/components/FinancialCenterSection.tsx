import { ArrowUpRight } from "lucide-react";
import { Link } from "react-router-dom";
import { TOOL_REGISTRY } from "../data/toolRegistry";
import { useLanguage } from "../i18n/LanguageContext";
import ToolCard from "./ToolCard";

export default function FinancialCenterSection() {
  const { lang } = useLanguage();
  const featured = TOOL_REGISTRY.filter((tool) => tool.featured).slice(0, 6);
  return (
    <section className="py-14 border-t border-line/40">
      <div className="mb-7 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div><p className="mb-2 text-xs font-bold uppercase tracking-[0.18em] text-gold">Version 2.0</p><h2 className="font-display text-2xl font-extrabold md:text-3xl">{lang === "ar" ? "مركز الذكاء المالي والحياة" : "Financial & Life Intelligence Center"}</h2><p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted">{lang === "ar" ? "أدوات مترابطة تعطيك صورة أوسع من مجرد رقم واحد." : "Connected tools that give you a broader picture than a single calculation."}</p></div>
        <Link to="/tools" className="inline-flex items-center gap-2 text-sm font-bold text-gold hover:text-goldBright">{lang === "ar" ? "عرض كل الأدوات" : "View all tools"}<ArrowUpRight className="h-4 w-4" /></Link>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{featured.map((tool) => <ToolCard key={tool.slug} tool={tool} />)}</div>
    </section>
  );
}
