import { Suspense, lazy, useEffect } from "react";
import { BrowserRouter, Route, Routes, useLocation } from "react-router-dom";
import { LanguageProvider } from "./i18n/LanguageContext";
import Header from "./components/Header";
import Footer from "./components/Footer";
import InstallPrompt from "./components/InstallPrompt";

const Home = lazy(() => import("./pages/Home"));
const CountryPage = lazy(() => import("./pages/CountryPage"));
const AdminDashboard = lazy(() => import("./pages/AdminDashboard"));
const ToolsIndex = lazy(() => import("./pages/ToolsIndex"));
const ToolPage = lazy(() => import("./pages/ToolPage"));
const NotFound = lazy(() => import("./pages/NotFound"));

function RouteEffects() {
  const location = useLocation();
  useEffect(() => {
    if (!location.hash) window.scrollTo({ top: 0, behavior: "smooth" });
  }, [location.pathname, location.hash]);
  return null;
}

function AppRoutes() {
  return (
    <div className="min-h-screen w-full stars-bg">
      <RouteEffects />
      <Header />
      <Suspense fallback={<div className="tool-loading min-h-[60vh]"><span /><span /><span /></div>}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/tools" element={<ToolsIndex />} />
          <Route path="/tools/:slug" element={<ToolPage />} />
          <Route path="/country/:slug" element={<CountryPage />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Suspense>
      <Footer />
      <InstallPrompt />
    </div>
  );
}

export default function App() {
  return <LanguageProvider><BrowserRouter><AppRoutes /></BrowserRouter></LanguageProvider>;
}
