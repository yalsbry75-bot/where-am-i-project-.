export interface ProjectionPoint {
  label: string;
  value: number;
  contribution?: number;
  interest?: number;
}

export interface SavingsInput {
  monthlyIncome: number;
  monthlyExpenses: number;
  savingsRate: number;
  months: number;
}

export interface SavingsResult {
  monthlySavings: number;
  effectiveRate: number;
  totalSavings: number;
  totalIncome: number;
  projection: ProjectionPoint[];
}

export function calculateSavings(input: SavingsInput): SavingsResult {
  const income = Math.max(0, input.monthlyIncome);
  const expenses = Math.max(0, input.monthlyExpenses);
  const requested = income * Math.max(0, input.savingsRate) / 100;
  const available = Math.max(0, income - expenses);
  const monthlySavings = Math.min(requested || available, available);
  const months = Math.max(1, Math.round(input.months));
  const projection: ProjectionPoint[] = [];
  const interval = Math.max(1, Math.ceil(months / 24));
  for (let month = 0; month <= months; month += interval) {
    projection.push({ label: `${month}`, value: monthlySavings * month, contribution: monthlySavings * month });
  }
  if (projection[projection.length - 1]?.label !== `${months}`) {
    projection.push({ label: `${months}`, value: monthlySavings * months, contribution: monthlySavings * months });
  }
  return {
    monthlySavings,
    effectiveRate: income > 0 ? monthlySavings / income * 100 : 0,
    totalSavings: monthlySavings * months,
    totalIncome: income * months,
    projection,
  };
}

export interface CompoundInput {
  initialInvestment: number;
  monthlyContribution: number;
  annualReturn: number;
  years: number;
}

export interface CompoundResult {
  futureValue: number;
  totalContributions: number;
  totalInterest: number;
  projection: ProjectionPoint[];
}

export function calculateCompoundInterest(input: CompoundInput): CompoundResult {
  const initial = Math.max(0, input.initialInvestment);
  const monthly = Math.max(0, input.monthlyContribution);
  const years = Math.max(1, Math.round(input.years));
  const rate = Math.max(-99, input.annualReturn) / 100 / 12;
  let balance = initial;
  let interestTotal = 0;
  const projection: ProjectionPoint[] = [{ label: "0", value: balance, contribution: initial, interest: 0 }];
  for (let month = 1; month <= years * 12; month += 1) {
    const interest = balance * rate;
    interestTotal += interest;
    balance += interest + monthly;
    if (month % 12 === 0) {
      const contributions = initial + monthly * month;
      projection.push({
        label: `${month / 12}`,
        value: balance,
        contribution: contributions,
        interest: balance - contributions,
      });
    }
  }
  const totalContributions = initial + monthly * years * 12;
  return {
    futureValue: balance,
    totalContributions,
    totalInterest: balance - totalContributions,
    projection,
  };
}

export interface WealthInput extends CompoundInput {
  currentWealth: number;
}

export interface WealthResult {
  after5: number;
  after10: number;
  after20: number;
  projection: ProjectionPoint[];
}

export function calculateWealthGrowth(input: WealthInput): WealthResult {
  const maxYears = 20;
  const result = calculateCompoundInterest({
    initialInvestment: Math.max(0, input.currentWealth),
    monthlyContribution: Math.max(0, input.monthlyContribution),
    annualReturn: input.annualReturn,
    years: maxYears,
  });
  const at = (year: number) => result.projection.find((point) => point.label === `${year}`)?.value ?? 0;
  return { after5: at(5), after10: at(10), after20: at(20), projection: result.projection };
}


export function calculateRequiredDebtPayment(principal: number, annualInterestRate: number, months: number): number {
  const balance = Math.max(0, principal);
  const term = Math.max(1, Math.round(months));
  const monthlyRate = Math.max(0, annualInterestRate) / 100 / 12;
  if (monthlyRate === 0) return balance / term;
  return balance * monthlyRate / (1 - Math.pow(1 + monthlyRate, -term));
}

export interface DebtInput {
  principal: number;
  annualInterestRate: number;
  monthlyPayment: number;
}

export interface DebtPaymentRow {
  month: number;
  payment: number;
  principal: number;
  interest: number;
  balance: number;
}

export interface DebtResult {
  months: number;
  totalInterest: number;
  totalPaid: number;
  minimumPayment: number;
  schedule: DebtPaymentRow[];
  projection: ProjectionPoint[];
  isPaymentSufficient: boolean;
}

export function calculateDebt(input: DebtInput): DebtResult {
  const principal = Math.max(0, input.principal);
  const monthlyRate = Math.max(0, input.annualInterestRate) / 100 / 12;
  const payment = Math.max(0, input.monthlyPayment);
  const minimumPayment = principal * monthlyRate;
  const isPaymentSufficient = monthlyRate === 0 ? payment > 0 : payment > minimumPayment;
  if (!isPaymentSufficient || principal === 0) {
    return {
      months: principal === 0 ? 0 : Infinity,
      totalInterest: 0,
      totalPaid: 0,
      minimumPayment,
      schedule: [],
      projection: [{ label: "0", value: principal }],
      isPaymentSufficient,
    };
  }

  let balance = principal;
  let totalInterest = 0;
  let month = 0;
  const schedule: DebtPaymentRow[] = [];
  const projection: ProjectionPoint[] = [{ label: "0", value: principal }];
  while (balance > 0.01 && month < 1200) {
    month += 1;
    const interest = balance * monthlyRate;
    const actualPayment = Math.min(payment, balance + interest);
    const principalPaid = actualPayment - interest;
    balance = Math.max(0, balance - principalPaid);
    totalInterest += interest;
    schedule.push({ month, payment: actualPayment, principal: principalPaid, interest, balance });
    if (month % 3 === 0 || balance === 0) projection.push({ label: `${month}`, value: balance });
  }
  return {
    months: month,
    totalInterest,
    totalPaid: principal + totalInterest,
    minimumPayment,
    schedule,
    projection,
    isPaymentSufficient,
  };
}
