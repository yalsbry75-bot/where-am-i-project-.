export type NotificationTopic = "global-statistics" | "salary-changes" | "living-cost" | "new-tools";

export interface NotificationSubscription {
  topic: NotificationTopic;
  enabled: boolean;
  updatedAt: string;
}

export interface NotificationAdapter {
  subscribe(subscription: NotificationSubscription): Promise<void>;
  unsubscribe(topic: NotificationTopic): Promise<void>;
}

const KEY = "wai_notification_subscriptions_v2";

export class LocalNotificationAdapter implements NotificationAdapter {
  async subscribe(subscription: NotificationSubscription): Promise<void> {
    const entries = this.read().filter((entry) => entry.topic !== subscription.topic);
    localStorage.setItem(KEY, JSON.stringify([...entries, subscription]));
  }

  async unsubscribe(topic: NotificationTopic): Promise<void> {
    localStorage.setItem(KEY, JSON.stringify(this.read().filter((entry) => entry.topic !== topic)));
  }

  read(): NotificationSubscription[] {
    try {
      return JSON.parse(localStorage.getItem(KEY) ?? "[]") as NotificationSubscription[];
    } catch {
      return [];
    }
  }
}


export class RemoteNotificationAdapter implements NotificationAdapter {
  constructor(private readonly endpoint: string) {}

  async subscribe(subscription: NotificationSubscription): Promise<void> {
    const response = await fetch(`${this.endpoint}/subscriptions`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(subscription),
    });
    if (!response.ok) throw new Error("Notification subscription failed");
  }

  async unsubscribe(topic: NotificationTopic): Promise<void> {
    const response = await fetch(`${this.endpoint}/subscriptions/${topic}`, { method: "DELETE" });
    if (!response.ok) throw new Error("Notification unsubscription failed");
  }
}

const notificationEndpoint = import.meta.env.VITE_NOTIFICATION_API_ENDPOINT?.trim();
export const notificationAdapter: NotificationAdapter = notificationEndpoint
  ? new RemoteNotificationAdapter(notificationEndpoint)
  : new LocalNotificationAdapter();
