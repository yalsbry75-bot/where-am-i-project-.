import { useState } from "react";
import { Sparkles } from "lucide-react";
import { useLanguage } from "../i18n/LanguageContext";
import { WELLNESS_HABITS, calculateWellnessAge, WellnessInput, WellnessResult } from "../lib/wellnessAge";
import ShareCard from "./ShareCard";
import { track } from "../lib/analytics";

export default function WellnessAgeSection() {
  const { t, lang } = useLanguage();

  const [age, setAge] = useState("");
  const [sleep, setSleep] = useState("7");
  const [activity, setActivity] = useState<WellnessInput["activityLevel"]>("medium");
  const [habits, setHabits] = useState<string[]>([]);
  const [result, setResult] = useState<WellnessResult | null>(null);

  const toggleHabit = (id: string) => {
    setHabits((prev) => (prev.includes(id) ? prev.filter((h) => h !== id) : [...prev, id]));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const ageNum = parseFloat(age);
    if (!ageNum || ageNum <= 0) return;
    track({ type: "calculator_used", calculator: "wellness_age" });
    setResult(
      calculateWellnessAge({
        age: ageNum,
        sleepHours: parseFloat(sleep) || 7,
        activityLevel: activity,
        habits,
      })
    );
  };

  return (
    <section id="wellness-age" className="py-14 border-t border-line/40 scroll-mt-8">
      <h2 className="font-display font-extrabold text-2xl md:text-3xl text-center mb-2">{t.waTitle}</h2>
      <p className="text-sm text-muted font-display text-center mb-8">{t.waSubtitle}</p>

      {!result ? (
        <form onSubmit={handleSubmit} className="max-w-lg mx-auto rounded-2xl p-6 md:p-7 bg-panel/25 border border-line">
          <div className="mb-4">
            <label className="block font-display text-sm text-muted mb-1.5">{t.waAge}</label>
            <input
              type="number"
              inputMode="numeric"
              value={age}
              onChange={(e) => setAge(e.target.value)}
              className="w-full font-num bg-void border border-line rounded-xl px-3 py-2.5 outline-none focus:border-glow transition-colors"
              required
              min={1}
              max={120}
            />
          </div>

          <div className="mb-4">
            <label className="block font-display text-sm text-muted mb-1.5">{t.waSleep}</label>
            <input
              type="number"
              inputMode="decimal"
              value={sleep}
              onChange={(e) => setSleep(e.target.value)}
              className="w-full font-num bg-void border border-line rounded-xl px-3 py-2.5 outline-none focus:border-glow transition-colors"
              min={0}
              max={16}
              step={0.5}
            />
          </div>

          <div className="mb-5">
            <label className="block font-display text-sm text-muted mb-2">{t.waActivity}</label>
            <div className="grid grid-cols-3 gap-2">
              {(["low", "medium", "high"] as const).map((level) => (
                <button
                  type="button"
                  key={level}
                  onClick={() => setActivity(level)}
                  className={`font-display text-sm py-2 rounded-lg border transition-colors ${
                    activity === level ? "border-gold bg-gold/10 text-goldBright" : "border-line text-muted"
                  }`}
                >
                  {level === "low" ? t.waActivityLow : level === "medium" ? t.waActivityMedium : t.waActivityHigh}
                </button>
              ))}
            </div>
          </div>

          <div className="mb-6">
            <label className="block font-display text-sm text-muted mb-2">{t.waHabits}</label>
            <div className="space-y-2">
              {WELLNESS_HABITS.map((h) => (
                <label
                  key={h.id}
                  className="flex items-center gap-2.5 font-display text-sm text-ivory/90 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={habits.includes(h.id)}
                    onChange={() => toggleHabit(h.id)}
                    className="w-4 h-4 accent-[#D4AF37]"
                  />
                  {lang === "ar" ? h.label : h.labelEn}
                </label>
              ))}
            </div>
          </div>

          <button
            type="submit"
            className="w-full font-display font-bold rounded-xl py-3 bg-gradient-to-l from-gold to-goldBright text-panel active:scale-[0.98] transition-transform"
          >
            {t.waSubmit}
          </button>
        </form>
      ) : (
        <div className="max-w-md mx-auto rounded-2xl p-7 text-center bg-gradient-to-b from-glow/10 to-panel/25 border border-gold/30">
          <Sparkles className="w-5 h-5 mx-auto mb-2 text-goldBright" />
          <p className="font-display text-muted mb-1">{t.waResultTitle}</p>
          <div className="font-num font-bold text-6xl text-goldBright">{result.estimatedAge}</div>
          <p className="font-display text-muted mt-1 mb-4">{t.waYears}</p>

          <p className="font-display text-sm text-ivory/90">
            {result.diff === 0
              ? t.waSame
              : result.diff < 0
              ? `${t.waYounger} ${Math.abs(result.diff)} ${t.waYears}`
              : `${t.waOlder} ${result.diff} ${t.waYears}`}
          </p>

          <p className="text-[11px] text-muted/70 font-display mt-5 leading-relaxed">{t.waDisclaimer}</p>

          <button
            onClick={() => setResult(null)}
            className="mt-5 text-xs font-display text-muted underline hover:text-ivory"
          >
            {t.waRetry}
          </button>

          <ShareCard
            calculator="wellness_age"
            text={
              lang === "ar"
                ? `✨ عمري الصحي التقديري ${result.estimatedAge} سنة (ترفيهي)! جرب اختبارك أنت`
                : `✨ My estimated wellness age is ${result.estimatedAge} (just for fun)! Try the quiz yourself`
            }
          />
        </div>
      )}
    </section>
  );
}
