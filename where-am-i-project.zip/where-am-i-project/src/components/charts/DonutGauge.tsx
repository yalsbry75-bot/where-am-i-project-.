interface DonutGaugeProps {
  value: number;
  label: string;
  suffix?: string;
}

export default function DonutGauge({ value, label, suffix = "%" }: DonutGaugeProps) {
  const safe = Math.min(100, Math.max(0, value));
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - safe / 100);
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-line/70 bg-void/45 p-5 text-center">
      <svg viewBox="0 0 140 140" className="h-36 w-36 -rotate-90">
        <circle cx="70" cy="70" r={radius} fill="none" stroke="#2A3564" strokeWidth="12" />
        <circle cx="70" cy="70" r={radius} fill="none" stroke="#F2C94C" strokeWidth="12" strokeLinecap="round" strokeDasharray={circumference} strokeDashoffset={offset} className="transition-all duration-700" />
      </svg>
      <div className="-mt-[92px] mb-10 font-num text-3xl font-bold">{Math.round(value)}{suffix}</div>
      <p className="text-xs text-muted">{label}</p>
    </div>
  );
}
