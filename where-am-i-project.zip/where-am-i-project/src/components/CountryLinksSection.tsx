import { Link } from "react-router-dom";
import { useLanguage } from "../i18n/LanguageContext";
import { useCountries } from "../hooks/useCountries";
import { countrySlug } from "../lib/seo";

export default function CountryLinksSection() {
  const { t, lang } = useLanguage();
  const COUNTRIES = useCountries();

  return (
    <section className="py-14 border-t border-line/40">
      <h2 className="font-display font-extrabold text-2xl md:text-3xl text-center mb-2">{t.exploreTitle}</h2>
      <p className="text-sm text-muted font-display text-center mb-8">{t.exploreSubtitle}</p>

      <div className="flex flex-wrap justify-center gap-2 max-w-3xl mx-auto">
        {COUNTRIES.map((c) => (
          <Link
            key={c.code}
            to={`/country/${countrySlug(c)}`}
            className="text-xs font-display px-3 py-1.5 rounded-full border border-line text-muted hover:border-gold hover:text-ivory transition-colors"
          >
            {lang === "ar" ? c.name : c.nameEn}
          </Link>
        ))}
      </div>
    </section>
  );
}
