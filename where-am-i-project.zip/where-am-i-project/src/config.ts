// ⚠️ رابط مؤقت — يُستبدل بدومين الموقع الفعلي عند الإطلاق (المرحلة 15)
export const SITE_URL = "https://whereami-intheworld.app";

// ⚠️ معرّفات إعلانية مؤقتة (Google AdSense) — تُستبدل بمعرّفات حساب AdSense الحقيقي
// بعد الموافقة على الموقع من جوجل. بدونها الإعلانات ما راح تظهر فعلياً.
export const ADSENSE_CLIENT_ID = "ca-pub-0000000000000000";
export const ADSENSE_SLOT_HERO = "0000000000";
export const ADSENSE_SLOT_INLINE = "0000000000";
