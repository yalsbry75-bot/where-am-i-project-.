import { useMemo, useState } from "react";
import { Download, FileText, Linkedin, LoaderCircle, Send, Share2 } from "lucide-react";
import { SITE_URL } from "../config";
import { useLanguage } from "../i18n/LanguageContext";
import { track } from "../lib/analytics";

export interface ReportMetric {
  label: string;
  value: string;
}

interface ReportActionsProps {
  toolName: string;
  title: string;
  summary: string;
  metrics: ReportMetric[];
  userInfo?: ReportMetric[];
  recommendations: string[];
  calculator?: string;
}

function escapeHtml(value: string): string {
  return value.replace(/[&<>'"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[character] ?? character);
}

function parseMetricNumber(value: string): number {
  const arabicDigits = "٠١٢٣٤٥٦٧٨٩";
  const normalized = value
    .replace(/[٠-٩]/g, (digit) => `${arabicDigits.indexOf(digit)}`)
    .replace(/٬/g, "")
    .replace(/٫/g, ".")
    .replace(/,/g, "");
  const match = normalized.match(/-?\d+(?:\.\d+)?/);
  return match ? Math.abs(Number(match[0])) : 0;
}

function reportMarkup(lang: "ar" | "en", dir: "rtl" | "ltr", title: string, summary: string, metrics: ReportMetric[], userInfo: ReportMetric[], recommendations: string[], toolName: string): string {
  const metricCards = metrics.map((metric) => `<div style="border:1px solid #dfe4f2;border-radius:14px;padding:16px;background:#f7f9ff;min-height:92px"><span style="display:block;color:#64708d;font-size:13px">${escapeHtml(metric.label)}</span><strong style="display:block;margin-top:8px;font-size:22px;color:#101527">${escapeHtml(metric.value)}</strong></div>`).join("");
  const userInfoRows = userInfo.map((item) => `<div style="display:flex;justify-content:space-between;gap:20px;padding:9px 0;border-bottom:1px solid #edf0f7"><span style="color:#64708d">${escapeHtml(item.label)}</span><strong>${escapeHtml(item.value)}</strong></div>`).join("");
  const chartItems = metrics.map((metric) => ({ ...metric, numeric: parseMetricNumber(metric.value) })).filter((metric) => metric.numeric > 0);
  const chartMax = Math.max(1, ...chartItems.map((metric) => metric.numeric));
  const chartRows = chartItems.map((metric) => `<div style="margin:12px 0"><div style="display:flex;justify-content:space-between;gap:16px;font-size:12px;margin-bottom:6px"><span>${escapeHtml(metric.label)}</span><strong>${escapeHtml(metric.value)}</strong></div><div style="height:11px;border-radius:999px;background:#e7ebf5;overflow:hidden"><div style="width:${Math.max(3, metric.numeric / chartMax * 100)}%;height:100%;border-radius:999px;background:linear-gradient(90deg,#4c7cff,#d4af37)"></div></div></div>`).join("");
  const recommendationsHtml = recommendations.map((item) => `<li style="margin:11px 0;line-height:1.7">${escapeHtml(item)}</li>`).join("");
  return `<div dir="${dir}" lang="${lang}" style="width:794px;min-height:1123px;padding:54px;background:#ffffff;color:#101527;font-family:Arial,Tahoma,sans-serif;box-sizing:border-box">
    <header style="padding:30px;border-radius:22px;background:linear-gradient(135deg,#07102b,#17306c);color:#ffffff">
      <div style="color:#f2c94c;font-size:13px;font-weight:bold;letter-spacing:1.5px">WHERE AM I · VERSION 2.0</div>
      <h1 style="margin:12px 0 8px;font-size:34px;line-height:1.3">${escapeHtml(title)}</h1>
      <p style="margin:0;color:#d9e1f6;font-size:15px;line-height:1.8">${escapeHtml(summary)}</p>
    </header>
    ${userInfoRows ? `<section style="margin-top:28px"><h2 style="font-size:21px;border-bottom:3px solid #4c7cff;padding-bottom:10px;margin-bottom:8px">${lang === "ar" ? "بيانات المستخدم والمدخلات" : "User information & inputs"}</h2>${userInfoRows}</section>` : ""}
    <section style="display:grid;grid-template-columns:repeat(2,1fr);gap:14px;margin:28px 0">${metricCards}</section>
    ${chartRows ? `<section style="margin-top:28px"><h2 style="font-size:21px;border-bottom:3px solid #4c7cff;padding-bottom:10px;margin-bottom:16px">${lang === "ar" ? "الرسم البياني للنتائج" : "Results chart"}</h2>${chartRows}</section>` : ""}
    <section style="margin-top:28px">
      <h2 style="font-size:21px;border-bottom:3px solid #f2c94c;padding-bottom:10px;margin-bottom:16px">${lang === "ar" ? "التوصيات" : "Recommendations"}</h2>
      <ul style="padding-inline-start:24px;font-size:14px">${recommendationsHtml}</ul>
    </section>
    <p style="margin-top:36px;padding-top:16px;border-top:1px solid #e5e8f1;color:#6e7891;font-size:11px;line-height:1.7">${lang === "ar" ? "هذا التقرير تقديري وتعليمي ولا يمثل نصيحة مالية أو طبية أو استثمارية. تعتمد النتائج على المدخلات والافتراضات الحالية." : "This report is illustrative and educational and is not financial, medical, or investment advice. Results depend on the current inputs and assumptions."}</p>
    <footer style="margin-top:32px;text-align:center;color:#6e7891;font-size:11px">${escapeHtml(toolName)} · ${new Date().toLocaleDateString(lang === "ar" ? "ar-SA" : "en-US")}</footer>
  </div>`;
}

export default function ReportActions({ toolName, title, summary, metrics, userInfo = [], recommendations, calculator = "v2-tool" }: ReportActionsProps) {
  const { lang, dir } = useLanguage();
  const [downloaded, setDownloaded] = useState(false);
  const [generatingPdf, setGeneratingPdf] = useState(false);
  const [pdfError, setPdfError] = useState(false);
  const shareText = useMemo(() => `${title} — ${metrics.slice(0, 3).map((metric) => `${metric.label}: ${metric.value}`).join(" | ")}`, [title, metrics]);
  const encodedText = encodeURIComponent(shareText);
  const encodedUrl = encodeURIComponent(`${SITE_URL}/tools/${calculator}`);

  const openPrintFallback = () => {
    const report = window.open("", "_blank");
    if (!report) return;
    report.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${escapeHtml(title)}</title><style>@page{size:A4;margin:0}body{margin:0;background:#fff}@media print{body{-webkit-print-color-adjust:exact;print-color-adjust:exact}}</style></head><body>${reportMarkup(lang, dir, title, summary, metrics, userInfo, recommendations, toolName)}<script>window.onload=()=>setTimeout(()=>window.print(),300);<\/script></body></html>`);
    report.document.close();
  };

  const downloadPdfReport = async () => {
    if (generatingPdf) return;
    setGeneratingPdf(true);
    setPdfError(false);
    const reportElement = document.createElement("div");
    reportElement.setAttribute("aria-hidden", "true");
    reportElement.style.position = "fixed";
    reportElement.style.left = "-10000px";
    reportElement.style.top = "0";
    reportElement.style.zIndex = "-1";
    reportElement.innerHTML = reportMarkup(lang, dir, title, summary, metrics, userInfo, recommendations, toolName);
    document.body.appendChild(reportElement);
    try {
      await document.fonts.ready;
      const [{ default: html2canvas }, { jsPDF }] = await Promise.all([import("html2canvas"), import("jspdf")]);
      const target = reportElement.firstElementChild as HTMLElement | null;
      if (!target) throw new Error("Report target was not created");
      const canvas = await html2canvas(target, { scale: 2, backgroundColor: "#ffffff", useCORS: true, logging: false });
      const imageData = canvas.toDataURL("image/png", 1);
      const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4", compress: true });
      const pageWidth = 210;
      const pageHeight = 297;
      const margin = 8;
      const imageWidth = pageWidth - margin * 2;
      const imageHeight = canvas.height * imageWidth / canvas.width;
      const usableHeight = pageHeight - margin * 2;
      let y = margin;
      pdf.addImage(imageData, "PNG", margin, y, imageWidth, imageHeight, undefined, "FAST");
      let remaining = imageHeight - usableHeight;
      while (remaining > 0) {
        pdf.addPage();
        y = margin - (imageHeight - remaining);
        pdf.addImage(imageData, "PNG", margin, y, imageWidth, imageHeight, undefined, "FAST");
        remaining -= usableHeight;
      }
      const safeName = calculator.replace(/[^a-z0-9-_]+/gi, "-");
      pdf.save(`${safeName}-report.pdf`);
      track({ type: "share_click", calculator, platform: "pdf-report" });
    } catch {
      setPdfError(true);
      openPrintFallback();
    } finally {
      reportElement.remove();
      setGeneratingPdf(false);
    }
  };

  const createShareCanvas = (): HTMLCanvasElement | null => {
    const canvas = document.createElement("canvas");
    canvas.width = 1200;
    canvas.height = 630;
    const context = canvas.getContext("2d");
    if (!context) return null;
    const gradient = context.createLinearGradient(0, 0, 1200, 630);
    gradient.addColorStop(0, "#05070F");
    gradient.addColorStop(1, "#17306C");
    context.fillStyle = gradient;
    context.fillRect(0, 0, 1200, 630);
    context.strokeStyle = "#D4AF37";
    context.lineWidth = 4;
    context.strokeRect(34, 34, 1132, 562);
    context.fillStyle = "#F2C94C";
    context.font = "bold 28px Arial";
    context.textAlign = dir === "rtl" ? "right" : "left";
    const startX = dir === "rtl" ? 1100 : 100;
    context.fillText("WHERE AM I · V2.0", startX, 100);
    context.fillStyle = "#F5F1E6";
    context.font = "bold 52px Arial";
    context.fillText(title.slice(0, 42), startX, 180);
    metrics.slice(0, 3).forEach((metric, index) => {
      const y = 285 + index * 95;
      context.fillStyle = "#93A0C4";
      context.font = "24px Arial";
      context.fillText(metric.label.slice(0, 34), startX, y);
      context.fillStyle = "#F5F1E6";
      context.font = "bold 40px Arial";
      context.fillText(metric.value.slice(0, 30), startX, y + 43);
    });
    context.fillStyle = "#93A0C4";
    context.font = "20px Arial";
    context.fillText("whereami-intheworld.app", startX, 560);
    return canvas;
  };

  const downloadShareCard = () => {
    const canvas = createShareCanvas();
    if (!canvas) return;
    const link = document.createElement("a");
    link.download = `${calculator}-share-card.png`;
    link.href = canvas.toDataURL("image/png");
    link.click();
    setDownloaded(true);
    setTimeout(() => setDownloaded(false), 1800);
    track({ type: "share_click", calculator, platform: "share-card" });
  };

  const shareLinks = {
    whatsapp: `https://wa.me/?text=${encodedText}%20${encodedUrl}`,
    telegram: `https://t.me/share/url?url=${encodedUrl}&text=${encodedText}`,
    x: `https://twitter.com/intent/tweet?text=${encodedText}&url=${encodedUrl}`,
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}&quote=${encodedText}`,
    linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`,
  };

  return (
    <section className="rounded-2xl border border-line/70 bg-panel/20 p-5">
      <div className="mb-4 flex items-center gap-2"><Share2 className="h-4 w-4 text-gold" /><h3 className="font-display font-bold">{lang === "ar" ? "التقرير والمشاركة" : "Report & sharing"}</h3></div>
      <div className="flex flex-wrap gap-2">
        <button onClick={() => void downloadPdfReport()} disabled={generatingPdf} className="action-button disabled:cursor-wait disabled:opacity-60">{generatingPdf ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <FileText className="h-4 w-4" />}{generatingPdf ? (lang === "ar" ? "جارٍ إنشاء PDF" : "Generating PDF") : (lang === "ar" ? "تنزيل تقرير PDF" : "Download PDF report")}</button>
        <button onClick={downloadShareCard} className="action-button"><Download className="h-4 w-4" />{downloaded ? (lang === "ar" ? "تم التنزيل" : "Downloaded") : (lang === "ar" ? "تنزيل بطاقة المشاركة" : "Download share card")}</button>
        <a className="social-button" href={shareLinks.whatsapp} target="_blank" rel="noreferrer">WhatsApp</a>
        <a className="social-button" href={shareLinks.telegram} target="_blank" rel="noreferrer"><Send className="h-3.5 w-3.5" />Telegram</a>
        <a className="social-button" href={shareLinks.x} target="_blank" rel="noreferrer">X</a>
        <a className="social-button" href={shareLinks.facebook} target="_blank" rel="noreferrer">Facebook</a>
        <a className="social-button" href={shareLinks.linkedin} target="_blank" rel="noreferrer"><Linkedin className="h-3.5 w-3.5" />LinkedIn</a>
      </div>
      {pdfError && <p className="mt-3 text-[11px] text-amber-200">{lang === "ar" ? "تعذر التنزيل المباشر؛ تم فتح نسخة الطباعة للحفظ كملف PDF." : "Direct download failed, so the printable PDF fallback was opened."}</p>}
    </section>
  );
}
