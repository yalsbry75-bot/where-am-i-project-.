import { ProjectionPoint } from "./financial";

export interface JourneyInput {
  age: number;
  monthlySalary: number;
  monthlyExpenses: number;
  savingsRate: number;
  currentSavings: number;
  annualReturn: number;
}

export interface JourneyMilestone {
  id: "car" | "home" | "million";
  target: number;
  age: number | null;
  years: number | null;
}

export interface JourneyResult {
  monthlySavings: number;
  milestones: JourneyMilestone[];
  projection: ProjectionPoint[];
}

const TARGETS = [
  { id: "car" as const, target: 25000 },
  { id: "home" as const, target: 50000 },
  { id: "million" as const, target: 1000000 },
];

export function calculateFinancialJourney(input: JourneyInput): JourneyResult {
  const salary = Math.max(0, input.monthlySalary);
  const available = Math.max(0, salary - Math.max(0, input.monthlyExpenses));
  const desired = salary * Math.max(0, input.savingsRate) / 100;
  const monthlySavings = Math.min(available, desired || available);
  const monthlyRate = Math.max(-99, input.annualReturn) / 100 / 12;
  let balance = Math.max(0, input.currentSavings);
  const reached = new Map<string, number>();
  const projection: ProjectionPoint[] = [{ label: `${input.age}`, value: balance }];
  for (let month = 1; month <= 60 * 12; month += 1) {
    balance = balance * (1 + monthlyRate) + monthlySavings;
    for (const target of TARGETS) {
      if (!reached.has(target.id) && balance >= target.target) reached.set(target.id, month);
    }
    if (month % 12 === 0) projection.push({ label: `${input.age + month / 12}`, value: balance });
  }
  const milestones = TARGETS.map((target) => {
    const month = reached.get(target.id);
    return {
      ...target,
      age: month ? input.age + month / 12 : null,
      years: month ? month / 12 : null,
    };
  });
  return { monthlySavings, milestones, projection };
}
