import { clamp } from "./format";

export interface LifestyleInput {
  age: number;
  sleepHours: number;
  activeDays: number;
  stressLevel: number;
  waterGlasses: number;
  smoker: boolean;
  restingHours: number;
}

export interface LifestyleResult {
  biologicalAge: number;
  healthScore: number;
  sleepScore: number;
  recommendedSteps: number;
  insights: string[];
}

export function calculateLifestyle(input: LifestyleInput, lang: "ar" | "en"): LifestyleResult {
  const sleepPenalty = Math.abs(7.5 - input.sleepHours) * 2.2;
  const activityBenefit = input.activeDays * 1.25;
  const stressPenalty = Math.max(0, input.stressLevel - 4) * 1.1;
  const hydrationBenefit = Math.min(8, input.waterGlasses) * 0.35;
  const smokingPenalty = input.smoker ? 7 : 0;
  const sedentaryPenalty = Math.max(0, input.restingHours - 7) * 0.7;
  const ageDelta = sleepPenalty + stressPenalty + smokingPenalty + sedentaryPenalty - activityBenefit - hydrationBenefit;
  const biologicalAge = clamp(input.age + ageDelta, 12, 100);
  const sleepScore = clamp(100 - Math.abs(8 - input.sleepHours) * 18 - (input.sleepHours < 5 ? 15 : 0), 0, 100);
  const healthScore = clamp(100 - Math.max(0, ageDelta) * 4 + Math.max(0, -ageDelta) * 2, 0, 100);
  const recommendedSteps = Math.round(clamp(6000 + (5 - input.activeDays) * 500 + (input.restingHours - 6) * 250, 5000, 12000) / 500) * 500;
  const insights = lang === "ar"
    ? [
        sleepScore < 70 ? "ثبات وقت النوم ورفع مدته تدريجياً قد يحسن النتيجة." : "نمط النوم قريب من النطاق الصحي العام.",
        input.activeDays < 3 ? "ابدأ بثلاثة أيام حركة أسبوعياً ولو بمشي سريع قصير." : "مستوى النشاط الأسبوعي يدعم النتيجة الحالية.",
        input.stressLevel > 6 ? "تقليل فترات الضغط وإضافة استراحات قصيرة أولوية واضحة." : "مستوى الضغط المبلغ عنه ضمن نطاق مقبول.",
      ]
    : [
        sleepScore < 70 ? "A more consistent sleep schedule may improve the result." : "Your sleep pattern is close to the general healthy range.",
        input.activeDays < 3 ? "Start with three active days per week, even with short brisk walks." : "Your weekly activity supports the current score.",
        input.stressLevel > 6 ? "Reducing sustained stress and adding short recovery breaks is a clear priority." : "Your reported stress level is within a manageable range.",
      ];
  return { biologicalAge, healthScore, sleepScore, recommendedSteps, insights };
}
