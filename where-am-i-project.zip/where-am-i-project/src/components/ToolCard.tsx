import { Link } from "react-router-dom";
import { ArrowUpRight } from "lucide-react";
import { ToolDefinition } from "../data/toolRegistry";
import { useLanguage } from "../i18n/LanguageContext";

export default function ToolCard({ tool }: { tool: ToolDefinition }) {
  const { lang } = useLanguage();
  const Icon = tool.icon;
  return (
    <Link
      to={`/tools/${tool.slug}`}
      className="group hover-lift glass-card relative overflow-hidden p-5"
    >
      {/* توهّج خفيف يظهر عند التحويم */}
      <div
        className="pointer-events-none absolute -top-10 -right-10 h-28 w-28 rounded-full bg-glow/20 opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-100"
        aria-hidden="true"
      />

      <div className="relative mb-5 flex items-start justify-between gap-4">
        <span className="icon-badge group-hover:border-gold/50 group-hover:from-gold/25 group-hover:to-gold/5 group-hover:text-goldBright">
          <Icon className="h-5 w-5" />
        </span>
        {tool.featured && (
          <span className="rounded-full border border-gold/30 bg-gold/10 px-2 py-0.5 text-[10px] font-display font-bold text-goldBright">
            {lang === "ar" ? "مميّز" : "Featured"}
          </span>
        )}
      </div>

      <h3 className="relative font-display font-bold text-ivory">{tool.title[lang]}</h3>
      <p className="relative mt-2 text-xs leading-relaxed text-muted">{tool.description[lang]}</p>

      <div className="relative mt-4 flex items-center gap-1 text-xs font-display font-bold text-muted transition-colors group-hover:text-gold">
        {lang === "ar" ? "جرّبها الآن" : "Try it now"}
        <ArrowUpRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5 rtl:group-hover:-translate-x-0.5" />
      </div>
    </Link>
  );
}
