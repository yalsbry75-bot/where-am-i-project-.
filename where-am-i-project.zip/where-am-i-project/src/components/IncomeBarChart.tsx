interface Bar {
  label: string;
  valueUSD: number;
  highlight?: boolean;
}

export default function IncomeBarChart({ bars }: { bars: Bar[] }) {
  const max = Math.max(...bars.map((b) => b.valueUSD), 1);

  return (
    <div className="space-y-3">
      {bars.map((b, i) => (
        <div key={i}>
          <div className="flex justify-between text-xs font-display text-muted mb-1">
            <span>{b.label}</span>
            <span className="font-num">${Math.round(b.valueUSD).toLocaleString()}</span>
          </div>
          <div className="h-2.5 rounded-full bg-line/50 overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-700"
              style={{
                width: `${Math.min(100, (b.valueUSD / max) * 100)}%`,
                background: b.highlight
                  ? "linear-gradient(90deg,#D4AF37,#F2C94C)"
                  : "linear-gradient(90deg,#2A3564,#4C7CFF)",
              }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}
