import { Country } from "../data/countries";

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

export function countrySlug(country: Country): string {
  return `${slugify(country.nameEn)}-salary-ranking`;
}

export function countryPageMeta(country: Country, lang: "ar" | "en") {
  if (lang === "ar") {
    return {
      title: `متوسط الراتب في ${country.name} ومقارنته بالعالم | أين أنا من العالم؟`,
      description: `اكتشف متوسط الراتب الشهري في ${country.name} (${Math.round(
        country.avgMonthlyUSD
      )}$ تقريباً)، ومقارنته بمتوسط الدخل العالمي ومؤشر تكلفة المعيشة.`,
    };
  }
  return {
    title: `Average Salary in ${country.nameEn} vs the World | Where Am I In The World?`,
    description: `Discover the average monthly salary in ${country.nameEn} (~$${Math.round(
      country.avgMonthlyUSD
    )}), compared to the global income average and cost of living index.`,
  };
}
