interface BarItem {
  label: string;
  value: number;
  displayValue?: string;
}

interface BarComparisonProps {
  items: BarItem[];
}

export default function BarComparison({ items }: BarComparisonProps) {
  const max = Math.max(1, ...items.map((item) => item.value));
  return (
    <div className="space-y-4 rounded-2xl border border-line/70 bg-void/45 p-5">
      {items.map((item) => (
        <div key={item.label}>
          <div className="mb-1.5 flex items-center justify-between gap-3 text-xs">
            <span className="text-muted">{item.label}</span>
            <span className="font-num text-ivory">{item.displayValue ?? Math.round(item.value).toLocaleString()}</span>
          </div>
          <div className="h-2.5 overflow-hidden rounded-full bg-line/40">
            <div className="h-full rounded-full bg-gradient-to-r from-glow to-gold transition-all duration-500" style={{ width: `${Math.max(2, item.value / max * 100)}%` }} />
          </div>
        </div>
      ))}
    </div>
  );
}
