import { useEffect, useState } from "react";
import { Country } from "../data/countries";
import { getEffectiveCountries } from "../lib/countryStore";

export function useCountries(): Country[] {
  const [countries, setCountries] = useState<Country[]>(getEffectiveCountries);

  useEffect(() => {
    // يعيد القراءة لو تغيّرت بيانات admin في تبويب آخر لنفس المتصفح
    const handler = (e: StorageEvent) => {
      if (e.key === "waitw_country_overrides") setCountries(getEffectiveCountries());
    };
    window.addEventListener("storage", handler);
    return () => window.removeEventListener("storage", handler);
  }, []);

  return countries;
}
