import { useLanguage } from "../i18n/LanguageContext";
import Reveal from "./Reveal";

export default function WhySection() {
  const { t } = useLanguage();

  return (
    <section className="py-14">
      <Reveal>
        <h2 className="font-display font-extrabold text-2xl md:text-3xl text-center mb-8">{t.whyTitle}</h2>
      </Reveal>
      <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-4">
        {t.whyItems.map((item, i) => (
          <Reveal key={i} delay={i * 70}>
            <div className="glass-card hover-lift p-5">
              <div className="font-num text-glow text-sm mb-2">{String(i + 1).padStart(2, "0")}</div>
              <div className="font-display font-bold mb-1.5">{item.title}</div>
              <div className="text-sm text-muted font-display leading-relaxed">{item.desc}</div>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
