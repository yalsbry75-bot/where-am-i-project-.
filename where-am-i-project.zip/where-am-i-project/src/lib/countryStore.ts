import { COUNTRIES, Country } from "../data/countries";

// ⚠️ نفس ملاحظة analytics.ts: تعديلات الأدمن هنا تُخزَّن محلياً في متصفح الأدمن نفسه فقط.
// معناها التعديلات ما تنعكس على زوار الموقع الفعليين إلا بعد ربط هذا بباكيند حقيقي يخدم البيانات لكل الزوار.
// اعتبر هذا "معاينة تفاعلية" لكيف راح تشتغل لوحة التحكم، مو نظام إدارة محتوى جاهز للإنتاج.

const STORAGE_KEY = "waitw_country_overrides";

export type CountryOverride = Partial<Pick<Country, "avgMonthlyUSD" | "costOfLivingIndex" | "rateToUSD">>;

function readOverrides(): Record<string, CountryOverride> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function writeOverrides(overrides: Record<string, CountryOverride>) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(overrides));
  } catch {
    // تجاهل
  }
}

export function getEffectiveCountries(): Country[] {
  const overrides = readOverrides();
  return COUNTRIES.map((c) => (overrides[c.code] ? { ...c, ...overrides[c.code] } : c));
}

export function setCountryOverride(code: string, patch: CountryOverride) {
  const overrides = readOverrides();
  overrides[code] = { ...overrides[code], ...patch };
  writeOverrides(overrides);
}

export function resetCountryOverrides() {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    // تجاهل
  }
}

export function hasOverride(code: string): boolean {
  const overrides = readOverrides();
  return Boolean(overrides[code]);
}
