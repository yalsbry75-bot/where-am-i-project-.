import { useEffect, useState } from "react";
import { getSponsorBanner, SponsorBanner } from "../lib/adsStore";

export function useSponsorBanner(): SponsorBanner {
  const [banner, setBanner] = useState<SponsorBanner>(getSponsorBanner);

  useEffect(() => {
    const handler = (e: StorageEvent) => {
      if (e.key === "waitw_sponsor_banner") setBanner(getSponsorBanner());
    };
    window.addEventListener("storage", handler);
    return () => window.removeEventListener("storage", handler);
  }, []);

  return banner;
}
