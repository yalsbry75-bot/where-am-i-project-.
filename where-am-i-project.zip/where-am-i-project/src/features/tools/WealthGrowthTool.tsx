import { useMemo, useState } from "react";
import { CalendarRange, Gem, TrendingUp } from "lucide-react";
import NumberField from "../../components/ui/NumberField";
import MetricCard from "../../components/ui/MetricCard";
import LineChart from "../../components/charts/LineChart";
import AIInsightPanel from "../../components/AIInsightPanel";
import ReportActions from "../../components/ReportActions";
import { calculateWealthGrowth } from "../../lib/financial";
import { formatCurrency } from "../../lib/format";
import { useLanguage } from "../../i18n/LanguageContext";

export default function WealthGrowthTool() {
  const { lang } = useLanguage();
  const locale = lang === "ar" ? "ar-SA" : "en-US";
  const [wealth, setWealth] = useState(25000);
  const [monthly, setMonthly] = useState(750);
  const [annualReturn, setAnnualReturn] = useState(6);
  const result = useMemo(() => calculateWealthGrowth({ currentWealth: wealth, initialInvestment: wealth, monthlyContribution: monthly, annualReturn, years: 20 }), [wealth, monthly, annualReturn]);
  const recommendations = useMemo(() => lang === "ar" ? ["راجع توزيع الأصول دورياً ولا تعتمد على عائد ثابت مضمون.", "زيادة المساهمة الشهرية المبكرة ترفع أثر التراكم على المدى الطويل.", "افصل صندوق الطوارئ عن محفظة النمو طويلة الأجل."] : ["Review asset allocation periodically and do not treat a fixed return as guaranteed.", "Earlier contribution increases have a larger long-term compounding effect.", "Keep the emergency fund separate from long-term growth assets."], [lang]);

  return (
    <div className="tool-grid">
      <section className="tool-form-card">
        <h2 className="tool-section-title">{lang === "ar" ? "افتراضات نمو الثروة" : "Wealth assumptions"}</h2>
        <div className="space-y-5">
          <NumberField label={lang === "ar" ? "الثروة الحالية" : "Current wealth"} value={wealth} onChange={setWealth} suffix="USD" />
          <NumberField label={lang === "ar" ? "الإضافة الشهرية" : "Monthly addition"} value={monthly} onChange={setMonthly} suffix="USD" />
          <NumberField label={lang === "ar" ? "العائد السنوي المتوقع" : "Expected annual return"} value={annualReturn} onChange={setAnnualReturn} min={-20} max={50} step={0.1} suffix="%" />
        </div>
      </section>
      <div className="space-y-6 min-w-0">
        <section className="grid gap-4 sm:grid-cols-3">
          <MetricCard label={lang === "ar" ? "بعد 5 سنوات" : "After 5 years"} value={formatCurrency(result.after5, "USD", locale)} icon={<CalendarRange className="h-4 w-4 text-glow" />} />
          <MetricCard label={lang === "ar" ? "بعد 10 سنوات" : "After 10 years"} value={formatCurrency(result.after10, "USD", locale)} icon={<TrendingUp className="h-4 w-4 text-gold" />} emphasis />
          <MetricCard label={lang === "ar" ? "بعد 20 سنة" : "After 20 years"} value={formatCurrency(result.after20, "USD", locale)} icon={<Gem className="h-4 w-4 text-gold" />} />
        </section>
        <LineChart labels={result.projection.map((point) => point.label)} series={[{ name: lang === "ar" ? "الثروة المتوقعة" : "Projected wealth", values: result.projection.map((point) => point.value) }]} valueFormatter={(value) => formatCurrency(value, "USD", locale)} />
        <AIInsightPanel tool={lang === "ar" ? "نمو الثروة" : "Wealth Growth"} metrics={{ currentWealth: wealth, monthlyContribution: monthly, annualReturn, after20Years: result.after20 }} />
        <ReportActions toolName="Where Am I Financial Center" title={lang === "ar" ? "تقرير نمو الثروة" : "Wealth growth report"} summary={lang === "ar" ? "توقعات لمدة 20 سنة وفق مساهمة وعائد افتراضيين." : "A 20-year projection using the selected contribution and return assumptions."} userInfo={[{ label: lang === "ar" ? "الثروة الحالية" : "Current wealth", value: formatCurrency(wealth, "USD", locale) }, { label: lang === "ar" ? "الإضافة الشهرية" : "Monthly addition", value: formatCurrency(monthly, "USD", locale) }, { label: lang === "ar" ? "العائد السنوي" : "Annual return", value: `${annualReturn}%` }]} metrics={[{ label: lang === "ar" ? "بعد 5 سنوات" : "After 5 years", value: formatCurrency(result.after5, "USD", locale) }, { label: lang === "ar" ? "بعد 10 سنوات" : "After 10 years", value: formatCurrency(result.after10, "USD", locale) }, { label: lang === "ar" ? "بعد 20 سنة" : "After 20 years", value: formatCurrency(result.after20, "USD", locale) }]} recommendations={recommendations} calculator="wealth-growth" />
      </div>
    </div>
  );
}
