import {
  BadgeDollarSign,
  Banknote,
  BarChart3,
  Globe2,
  HeartPulse,
  Landmark,
  LineChart,
  Route,
  type LucideIcon,
} from "lucide-react";

export type ToolCategory = "finance" | "global" | "health" | "planning";

export interface ToolDefinition {
  slug: string;
  category: ToolCategory;
  icon: LucideIcon;
  title: { ar: string; en: string };
  description: { ar: string; en: string };
  seoDescription: { ar: string; en: string };
  featured?: boolean;
}

export const TOOL_REGISTRY: ToolDefinition[] = [
  {
    slug: "savings-calculator",
    category: "finance",
    icon: Banknote,
    featured: true,
    title: { ar: "حاسبة الادخار", en: "Savings Calculator" },
    description: { ar: "خطط ادخارك الشهري واعرف رصيدك المستقبلي.", en: "Plan monthly savings and project your future balance." },
    seoDescription: { ar: "حاسبة ادخار شهرية مع رسوم وتوقعات زمنية.", en: "Monthly savings calculator with charts and future projections." },
  },
  {
    slug: "wealth-growth",
    category: "finance",
    icon: LineChart,
    featured: true,
    title: { ar: "نمو الثروة", en: "Wealth Growth" },
    description: { ar: "توقع ثروتك بعد 5 و10 و20 سنة.", en: "Forecast your wealth after 5, 10, and 20 years." },
    seoDescription: { ar: "توقع نمو الثروة بناءً على الادخار والعائد.", en: "Forecast wealth growth from savings and investment returns." },
  },
  {
    slug: "compound-interest",
    category: "finance",
    icon: BadgeDollarSign,
    title: { ar: "الفائدة المركبة", en: "Compound Interest" },
    description: { ar: "شاهد أثر الاستثمار المنتظم والعائد التراكمي.", en: "Visualize recurring investment and compounding returns." },
    seoDescription: { ar: "حاسبة فائدة مركبة احترافية مع رسم سنوي.", en: "Professional compound interest calculator with annual charts." },
  },
  {
    slug: "debt-payoff",
    category: "finance",
    icon: Landmark,
    title: { ar: "سداد الديون", en: "Debt Payoff" },
    description: { ar: "احسب الفائدة والمدة وجدول السداد.", en: "Calculate interest, payoff time, and repayment schedule." },
    seoDescription: { ar: "حاسبة سداد الديون وجدول الأقساط الشهري.", en: "Debt payoff calculator with monthly amortization schedule." },
  },
  {
    slug: "living-comparison",
    category: "global",
    icon: Globe2,
    featured: true,
    title: { ar: "مقارنة المعيشة العالمية", en: "Global Living Comparison" },
    description: { ar: "اعرف أفضل دولة لراتبك وقارن الإيجار والغذاء والوقود والإنترنت.", en: "Find the best country for your salary and compare major living costs." },
    seoDescription: { ar: "قارن تكلفة المعيشة والقوة الشرائية بين الدول.", en: "Compare cost of living and purchasing power across countries." },
  },
  {
    slug: "global-ranking",
    category: "global",
    icon: BarChart3,
    featured: true,
    title: { ar: "الترتيب العالمي", en: "Global Ranking" },
    description: { ar: "حلّل ترتيب دخلك عالمياً ومحلياً وفرصة دخول أعلى 1٪.", en: "Analyze global and country income rank and top 1% eligibility." },
    seoDescription: { ar: "تحليل ترتيب الدخل والقوة الشرائية ومستوى المعيشة.", en: "Income ranking, purchasing power, and living standard analysis." },
  },
  {
    slug: "lifestyle-insights",
    category: "health",
    icon: HeartPulse,
    title: { ar: "الصحة ونمط الحياة", en: "Health & Lifestyle" },
    description: { ar: "العمر الحيوي، جودة النوم، الدرجة الصحية، والخطوات اليومية.", en: "Biological age, sleep quality, health score, and daily steps." },
    seoDescription: { ar: "تقييم مبسط لنمط الحياة والصحة العامة.", en: "A simple lifestyle and general wellness assessment." },
  },
  {
    slug: "financial-journey",
    category: "planning",
    icon: Route,
    featured: true,
    title: { ar: "رحلة الحياة المالية", en: "Financial Life Journey" },
    description: { ar: "خط زمني تفاعلي لأول سيارة ومنزل ومليون.", en: "An interactive timeline to your first car, home, and million." },
    seoDescription: { ar: "خطط مراحل حياتك المالية حسب الراتب والادخار.", en: "Plan financial milestones from salary, expenses, and savings." },
  },
];

export function getTool(slug?: string): ToolDefinition | undefined {
  return TOOL_REGISTRY.find((tool) => tool.slug === slug);
}
