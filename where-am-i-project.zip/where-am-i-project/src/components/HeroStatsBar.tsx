import { Wrench, Globe2, Users, Calculator } from "lucide-react";
import { useLanguage } from "../i18n/LanguageContext";
import { TOOL_REGISTRY } from "../data/toolRegistry";
import { COUNTRIES } from "../data/countries";
import AnimatedCounter from "./AnimatedCounter";

export default function HeroStatsBar() {
  const { t } = useLanguage();

  // عدد الأدوات الفعلي: أدوات المركز المالي المسجّلة + الحاسبات الأصلية المستقلة (دخل/قوة شرائية/وقت/دول/عمر صحي)
  const totalTools = TOOL_REGISTRY.length + 5;

  const stats = [
    { icon: Wrench, target: totalTools, suffix: "+", label: t.statToolsLabel },
    { icon: Globe2, target: COUNTRIES.length, suffix: "+", label: t.statCountriesLabel },
    { icon: Users, target: 8.1, suffix: "B", label: t.statPeopleLabel, decimals: 1 },
    { icon: Calculator, target: 60, suffix: "s", label: t.statCalcLabel },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 max-w-3xl mx-auto">
      {stats.map((s, i) => (
        <div key={i} className="glass-card p-4 text-center hover-lift">
          <s.icon className="w-4 h-4 mx-auto mb-2 text-gold" />
          <div className="font-num font-bold text-xl md:text-2xl text-ivory">
            <AnimatedCounter target={s.target} suffix={s.suffix} decimals={s.decimals ?? 0} />
          </div>
          <div className="text-[11px] font-display text-muted mt-1">{s.label}</div>
        </div>
      ))}
    </div>
  );
}
