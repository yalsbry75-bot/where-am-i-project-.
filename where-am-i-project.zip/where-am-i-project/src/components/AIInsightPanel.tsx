import { useEffect, useMemo, useState } from "react";
import { Bot, Sparkles } from "lucide-react";
import { aiProvider } from "../lib/aiAssistant";
import { useLanguage } from "../i18n/LanguageContext";

interface AIInsightPanelProps {
  tool: string;
  metrics: Record<string, number | string | boolean>;
  additionalInsights?: string[];
}

export default function AIInsightPanel({ tool, metrics, additionalInsights = [] }: AIInsightPanelProps) {
  const { lang } = useLanguage();
  const [insights, setInsights] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const serializedMetrics = useMemo(() => JSON.stringify(metrics), [metrics]);
  const serializedAdditional = useMemo(() => JSON.stringify(additionalInsights), [additionalInsights]);

  useEffect(() => {
    let active = true;
    setLoading(true);
    void aiProvider.explain({ tool, metrics, lang }).then((items) => {
      if (active) setInsights([...additionalInsights, ...items]);
    }).catch(() => {
      if (active) setInsights(additionalInsights);
    }).finally(() => {
      if (active) setLoading(false);
    });
    return () => { active = false; };
  }, [tool, lang, serializedMetrics, serializedAdditional]);

  return (
    <section className="rounded-2xl border border-glow/40 bg-glow/5 p-5 md:p-6">
      <div className="mb-4 flex items-center gap-3">
        <span className="rounded-xl bg-glow/15 p-2 text-glow"><Bot className="h-5 w-5" /></span>
        <div>
          <h3 className="font-display font-bold">{lang === "ar" ? "المساعد الذكي" : "AI Assistant"}</h3>
          <p className="text-[11px] text-muted">{lang === "ar" ? "تفسير محلي فوري، مع بنية جاهزة لربط API خارجي." : "Instant local explanation with an API-ready provider architecture."}</p>
        </div>
      </div>
      {loading ? (
        <div className="space-y-2 animate-pulse"><div className="h-3 rounded bg-line/50" /><div className="h-3 w-4/5 rounded bg-line/40" /></div>
      ) : (
        <ul className="space-y-3 text-sm leading-relaxed text-ivory/90">
          {insights.map((insight, index) => (
            <li key={`${insight}-${index}`} className="flex gap-2.5"><Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-gold" /><span>{insight}</span></li>
          ))}
        </ul>
      )}
    </section>
  );
}
