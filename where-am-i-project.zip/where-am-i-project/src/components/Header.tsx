import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { Link, NavLink, useLocation } from "react-router-dom";
import { useLanguage } from "../i18n/LanguageContext";

export default function Header() {
  const { t, lang, toggleLang } = useLanguage();
  const [open, setOpen] = useState(false);
  const location = useLocation();
  useEffect(() => setOpen(false), [location.pathname]);
  const links = [
    { to: "/", ar: "الرئيسية", en: "Home", end: true },
    { to: "/tools", ar: "مركز الأدوات", en: "Tools Center", end: false },
    { to: "/tools/financial-journey", ar: "الرحلة المالية", en: "Financial Journey", end: true },
    { to: "/tools/living-comparison", ar: "مقارنة المعيشة", en: "Living Comparison", end: true },
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-line/40 bg-void/85 backdrop-blur-xl">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-4 md:px-6">
        <Link to="/" className="flex min-w-0 items-center gap-2 font-display font-extrabold">
          <svg width="28" height="28" viewBox="0 0 96 96" className="shrink-0" aria-hidden="true">
            <circle cx="48" cy="48" r="44" fill="none" stroke="#2A3564" strokeWidth="2" />
            <circle cx="48" cy="48" r="30" fill="none" stroke="#2A3564" strokeWidth="2" strokeDasharray="3 6" />
            <circle cx="48" cy="48" r="12" fill="#4C7CFF" />
            <circle cx="90" cy="48" r="6" fill="#D4AF37" />
          </svg>
          <span className="truncate text-sm sm:text-base">{t.siteName}</span>
          <span className="hidden rounded-full border border-gold/30 bg-gold/10 px-2 py-0.5 font-num text-[9px] text-gold sm:inline">V2.0</span>
        </Link>
        <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary navigation">
          {links.map((link) => <NavLink key={link.to} to={link.to} end={link.end} className={({ isActive }) => `rounded-lg px-3 py-2 text-xs transition ${isActive ? "bg-panel/70 text-gold" : "text-muted hover:bg-panel/40 hover:text-ivory"}`}>{lang === "ar" ? link.ar : link.en}</NavLink>)}
        </nav>
        <div className="flex items-center gap-2">
          <button onClick={toggleLang} className="rounded-full border border-line px-3 py-1.5 text-xs text-muted transition hover:border-glow hover:text-ivory">{t.langSwitch}</button>
          <button onClick={() => setOpen((value) => !value)} className="rounded-lg border border-line p-2 text-muted lg:hidden" aria-label={lang === "ar" ? "فتح القائمة" : "Open menu"}>{open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}</button>
        </div>
      </div>
      {open && <nav className="border-t border-line/40 px-5 py-3 lg:hidden">{links.map((link) => <NavLink key={link.to} to={link.to} end={link.end} className={({ isActive }) => `block rounded-xl px-4 py-3 text-sm ${isActive ? "bg-panel/70 text-gold" : "text-muted"}`}>{lang === "ar" ? link.ar : link.en}</NavLink>)}</nav>}
    </header>
  );
}
