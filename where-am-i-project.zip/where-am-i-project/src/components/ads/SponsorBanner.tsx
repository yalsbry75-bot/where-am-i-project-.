import { Megaphone } from "lucide-react";
import { useSponsorBanner } from "../../hooks/useSponsorBanner";
import { track } from "../../lib/analytics";

export default function SponsorBanner() {
  const banner = useSponsorBanner();

  if (!banner.enabled || !banner.title || !banner.linkUrl) return null;

  return (
    <a
      href={banner.linkUrl}
      target="_blank"
      rel="noopener noreferrer sponsored"
      onClick={() => track({ type: "share_click", calculator: "sponsor_banner", platform: "click" })}
      className="block rounded-xl p-4 bg-gold/5 border border-gold/25 hover:border-gold/50 transition-colors"
    >
      <div className="flex items-start gap-3">
        <div className="w-8 h-8 rounded-lg bg-void flex items-center justify-center shrink-0">
          <Megaphone className="w-3.5 h-3.5 text-goldBright" />
        </div>
        <div className="min-w-0">
          <p className="font-display font-bold text-sm truncate">{banner.title}</p>
          {banner.description && (
            <p className="text-xs text-muted font-display mt-0.5 leading-relaxed">{banner.description}</p>
          )}
          {banner.sponsorName && (
            <p className="text-[10px] text-muted/60 font-display mt-1.5">برعاية {banner.sponsorName}</p>
          )}
        </div>
      </div>
    </a>
  );
}
