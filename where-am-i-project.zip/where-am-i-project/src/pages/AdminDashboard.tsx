import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, RotateCcw, TriangleAlert } from "lucide-react";
import { useCountries } from "../hooks/useCountries";
import { setCountryOverride, resetCountryOverrides, hasOverride } from "../lib/countryStore";
import { summarize, clearLog, AnalyticsSummary } from "../lib/analytics";
import { getSponsorBanner, setSponsorBanner, SponsorBanner } from "../lib/adsStore";

// ⚠️ كلمة مرور ثابتة بالكود = حماية شكلية فقط، مو أمان حقيقي.
// قبل الإطلاق الفعلي (المرحلة 15) لازم تُستبدل بمصادقة حقيقية عبر باكيند (جلسة، JWT، إلخ).
const ADMIN_PASSWORD = "admin123";
const SESSION_KEY = "waitw_admin_session";

export default function AdminDashboard() {
  const [authed, setAuthed] = useState(() => sessionStorage.getItem(SESSION_KEY) === "1");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      sessionStorage.setItem(SESSION_KEY, "1");
      setAuthed(true);
      setError(false);
    } else {
      setError(true);
    }
  };

  if (!authed) {
    return (
      <main className="max-w-sm mx-auto px-6 pt-24">
        <form onSubmit={handleLogin} className="rounded-2xl p-6 bg-panel/25 border border-line">
          <h1 className="font-display font-bold text-lg mb-1">دخول لوحة التحكم</h1>
          <p className="text-xs text-muted font-display mb-5">هذي منطقة داخلية — للفريق فقط.</p>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="كلمة المرور"
            className="w-full font-display bg-void border border-line rounded-xl px-3 py-2.5 outline-none focus:border-glow transition-colors mb-3"
          />
          {error && <p className="text-xs text-red-400 font-display mb-3">كلمة المرور غير صحيحة.</p>}
          <button
            type="submit"
            className="w-full font-display font-bold rounded-xl py-2.5 bg-gradient-to-l from-gold to-goldBright text-panel"
          >
            دخول
          </button>
          <Link to="/" className="block text-center text-xs font-display text-muted mt-4 hover:text-ivory">
            رجوع للموقع
          </Link>
        </form>
      </main>
    );
  }

  return <DashboardContent />;
}

function DashboardContent() {
  const COUNTRIES = useCountries();
  const [summary, setSummary] = useState<AnalyticsSummary>(summarize());
  const [edits, setEdits] = useState<Record<string, { avgMonthlyUSD: string; costOfLivingIndex: string }>>({});

  useEffect(() => {
    setSummary(summarize());
  }, []);

  const calculatorLabels: Record<string, string> = {
    income: "ترتيب الدخل",
    purchasing_power: "القوة الشرائية",
    time_value: "قيمة الوقت",
    country_comparison: "مقارنة الدول",
    wellness_age: "العمر الصحي",
  };

  const saveCountry = (code: string) => {
    const edit = edits[code];
    if (!edit) return;
    const patch: any = {};
    if (edit.avgMonthlyUSD !== undefined && edit.avgMonthlyUSD !== "") {
      patch.avgMonthlyUSD = parseFloat(edit.avgMonthlyUSD);
    }
    if (edit.costOfLivingIndex !== undefined && edit.costOfLivingIndex !== "") {
      patch.costOfLivingIndex = parseFloat(edit.costOfLivingIndex);
    }
    setCountryOverride(code, patch);
    setEdits((prev) => ({ ...prev, [code]: undefined as any }));
    window.location.reload();
  };

  return (
    <main className="max-w-5xl mx-auto px-6 py-10">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display font-extrabold text-2xl">لوحة التحكم</h1>
          <p className="text-xs text-muted font-display">إحصائيات وإدارة بيانات — المرحلة 13</p>
        </div>
        <Link to="/" className="text-xs font-display text-muted hover:text-ivory flex items-center gap-1">
          <ArrowLeft className="w-3.5 h-3.5 rotate-180" />
          رجوع للموقع
        </Link>
      </div>

      <div className="rounded-xl p-4 mb-8 bg-gold/5 border border-gold/30 flex items-start gap-3">
        <TriangleAlert className="w-4 h-4 text-goldBright shrink-0 mt-0.5" />
        <p className="text-xs font-display text-ivory/90 leading-relaxed">
          الإحصائيات هنا مقروءة من متصفحك الحالي بس (localStorage) — مو من كل زوار الموقع. هذي معاينة تفاعلية
          لشكل لوحة التحكم، وتحتاج ربط بباكيند وقاعدة بيانات حقيقية قبل الإطلاق (راجع README).
        </p>
      </div>

      {/* الإحصائيات */}
      <section className="mb-12">
        <h2 className="font-display font-bold text-lg mb-4">الإحصائيات</h2>
        <div className="grid sm:grid-cols-3 gap-4 mb-6">
          <StatCard label="إجمالي الأحداث المسجّلة" value={summary.totalEvents} />
          <StatCard label="زيارات الصفحات" value={summary.pageViews} />
          <StatCard
            label="مرات استخدام الحاسبات"
            value={Object.values(summary.calculatorUsage).reduce((a, b) => a + b, 0)}
          />
        </div>

        <div className="grid sm:grid-cols-2 gap-4 mb-6">
          <div className="rounded-xl p-4 bg-panel/25 border border-line">
            <p className="font-display font-bold text-sm mb-3">أكثر الحاسبات استخداماً</p>
            {Object.keys(summary.calculatorUsage).length === 0 ? (
              <EmptyNote />
            ) : (
              <BarList
                items={Object.entries(summary.calculatorUsage).map(([id, count]) => ({
                  label: calculatorLabels[id] || id,
                  count,
                }))}
              />
            )}
          </div>
          <div className="rounded-xl p-4 bg-panel/25 border border-line">
            <p className="font-display font-bold text-sm mb-3">نتائج المشاركة (حسب المنصة)</p>
            {Object.keys(summary.shareClicks).length === 0 ? (
              <EmptyNote />
            ) : (
              <BarList
                items={Object.entries(summary.shareClicks).map(([platform, count]) => ({
                  label: platform,
                  count,
                }))}
              />
            )}
          </div>
        </div>

        <div className="rounded-xl p-4 bg-panel/25 border border-line mb-4">
          <p className="font-display font-bold text-sm mb-3">الدول الأكثر اختياراً</p>
          {summary.topCountries.length === 0 ? (
            <EmptyNote />
          ) : (
            <BarList
              items={summary.topCountries.map((c) => ({
                label: COUNTRIES.find((co) => co.code === c.code)?.name || c.code,
                count: c.count,
              }))}
            />
          )}
        </div>

        <button
          onClick={() => {
            clearLog();
            setSummary(summarize());
          }}
          className="text-xs font-display text-muted underline hover:text-ivory"
        >
          تفريغ سجل الإحصائيات المحلي
        </button>
      </section>

      {/* إدارة بيانات الدول */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display font-bold text-lg">إدارة بيانات الدول والأسعار</h2>
          <button
            onClick={() => {
              resetCountryOverrides();
              window.location.reload();
            }}
            className="text-xs font-display text-muted hover:text-ivory flex items-center gap-1"
          >
            <RotateCcw className="w-3 h-3" />
            استعادة كل القيم الافتراضية
          </button>
        </div>

        <div className="rounded-xl border border-line overflow-x-auto">
          <table className="w-full text-sm font-display min-w-[600px]">
            <thead>
              <tr className="border-b border-line text-right text-muted text-xs">
                <th className="p-3">الدولة</th>
                <th className="p-3">متوسط الراتب ($)</th>
                <th className="p-3">مؤشر تكلفة المعيشة</th>
                <th className="p-3"></th>
              </tr>
            </thead>
            <tbody>
              {COUNTRIES.map((c) => (
                <tr key={c.code} className="border-b border-line/50">
                  <td className="p-3">
                    {c.name}
                    {hasOverride(c.code) && (
                      <span className="text-[10px] text-goldBright mr-2">(مُعدَّل)</span>
                    )}
                  </td>
                  <td className="p-3">
                    <input
                      type="number"
                      defaultValue={c.avgMonthlyUSD}
                      onChange={(e) =>
                        setEdits((prev) => ({
                          ...prev,
                          [c.code]: { ...prev[c.code], avgMonthlyUSD: e.target.value } as any,
                        }))
                      }
                      className="w-24 font-num bg-void border border-line rounded-lg px-2 py-1 outline-none focus:border-glow"
                    />
                  </td>
                  <td className="p-3">
                    <input
                      type="number"
                      defaultValue={c.costOfLivingIndex}
                      onChange={(e) =>
                        setEdits((prev) => ({
                          ...prev,
                          [c.code]: { ...prev[c.code], costOfLivingIndex: e.target.value } as any,
                        }))
                      }
                      className="w-20 font-num bg-void border border-line rounded-lg px-2 py-1 outline-none focus:border-glow"
                    />
                  </td>
                  <td className="p-3">
                    <button
                      onClick={() => saveCountry(c.code)}
                      className="text-xs font-display px-3 py-1.5 rounded-lg bg-gold/10 text-goldBright border border-gold/30"
                    >
                      حفظ
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* الإعلانات */}
      <section className="mt-12">
        <h2 className="font-display font-bold text-lg mb-4">الإعلانات</h2>
        <SponsorBannerAdmin />
        <div className="rounded-xl p-4 mt-4 border border-line border-dashed">
          <p className="text-xs text-muted font-display leading-relaxed">
            إعلانات Google AdSense تُدار من ملف <code className="text-goldBright">src/config.ts</code> مباشرة
            (ADSENSE_CLIENT_ID) — تحتاج حساب AdSense حقيقي وموافقة من جوجل أول، مو شي يُفعَّل من هنا.
          </p>
        </div>
      </section>
    </main>
  );
}

function SponsorBannerAdmin() {
  const [banner, setBanner] = useState<SponsorBanner>(getSponsorBanner());
  const [saved, setSaved] = useState(false);

  const update = (patch: Partial<SponsorBanner>) => setBanner((prev) => ({ ...prev, ...patch }));

  const save = () => {
    setSponsorBanner(banner);
    setSaved(true);
    setTimeout(() => setSaved(false), 1500);
  };

  return (
    <div className="rounded-xl p-5 bg-panel/25 border border-line">
      <div className="flex items-center justify-between mb-4">
        <p className="font-display font-bold text-sm">بانر داخلي (Sponsor Banner)</p>
        <label className="flex items-center gap-2 text-xs font-display text-muted cursor-pointer">
          <input
            type="checkbox"
            checked={banner.enabled}
            onChange={(e) => update({ enabled: e.target.checked })}
            className="w-4 h-4 accent-[#D4AF37]"
          />
          مفعّل
        </label>
      </div>

      <div className="grid sm:grid-cols-2 gap-3 mb-3">
        <input
          placeholder="اسم الراعي"
          value={banner.sponsorName}
          onChange={(e) => update({ sponsorName: e.target.value })}
          className="font-display text-sm bg-void border border-line rounded-lg px-3 py-2 outline-none focus:border-glow"
        />
        <input
          placeholder="رابط الإعلان"
          value={banner.linkUrl}
          onChange={(e) => update({ linkUrl: e.target.value })}
          className="font-display text-sm bg-void border border-line rounded-lg px-3 py-2 outline-none focus:border-glow"
        />
      </div>
      <input
        placeholder="عنوان الإعلان"
        value={banner.title}
        onChange={(e) => update({ title: e.target.value })}
        className="w-full font-display text-sm bg-void border border-line rounded-lg px-3 py-2 outline-none focus:border-glow mb-3"
      />
      <textarea
        placeholder="وصف قصير"
        value={banner.description}
        onChange={(e) => update({ description: e.target.value })}
        rows={2}
        className="w-full font-display text-sm bg-void border border-line rounded-lg px-3 py-2 outline-none focus:border-glow mb-4 resize-none"
      />

      <button
        onClick={save}
        className="font-display text-xs font-bold px-4 py-2 rounded-lg bg-gradient-to-l from-gold to-goldBright text-panel"
      >
        {saved ? "تم الحفظ ✓" : "حفظ البانر"}
      </button>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-xl p-4 bg-void/40 border border-line text-center">
      <div className="font-num font-bold text-2xl text-goldBright mb-1">{value}</div>
      <div className="text-xs font-display text-muted">{label}</div>
    </div>
  );
}

function BarList({ items }: { items: { label: string; count: number }[] }) {
  const max = Math.max(...items.map((i) => i.count), 1);
  return (
    <div className="space-y-2">
      {items
        .sort((a, b) => b.count - a.count)
        .map((item) => (
          <div key={item.label}>
            <div className="flex justify-between text-xs text-muted mb-1">
              <span>{item.label}</span>
              <span className="font-num">{item.count}</span>
            </div>
            <div className="h-1.5 rounded-full bg-void/60 overflow-hidden">
              <div
                className="h-full rounded-full"
                style={{ width: `${(item.count / max) * 100}%`, background: "linear-gradient(90deg,#4C7CFF,#D4AF37)" }}
              />
            </div>
          </div>
        ))}
    </div>
  );
}

function EmptyNote() {
  return <p className="text-xs text-muted/70 font-display">ما فيه بيانات بعد — جرّب استخدام الحاسبات أول.</p>;
}
