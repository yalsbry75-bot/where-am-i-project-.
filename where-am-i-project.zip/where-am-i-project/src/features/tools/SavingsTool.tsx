import { useEffect, useMemo, useState } from "react";
import { PiggyBank, TrendingUp, WalletCards } from "lucide-react";
import NumberField from "../../components/ui/NumberField";
import MetricCard from "../../components/ui/MetricCard";
import LineChart from "../../components/charts/LineChart";
import AIInsightPanel from "../../components/AIInsightPanel";
import ReportActions from "../../components/ReportActions";
import { calculateSavings } from "../../lib/financial";
import { formatCurrency, formatNumber } from "../../lib/format";
import { useLanguage } from "../../i18n/LanguageContext";
import { publishWidgetSnapshot } from "../../lib/widgetBridge";

export default function SavingsTool() {
  const { lang } = useLanguage();
  const locale = lang === "ar" ? "ar-SA" : "en-US";
  const [income, setIncome] = useState(3500);
  const [expenses, setExpenses] = useState(2200);
  const [rate, setRate] = useState(20);
  const [months, setMonths] = useState(36);
  const result = useMemo(() => calculateSavings({ monthlyIncome: income, monthlyExpenses: expenses, savingsRate: rate, months }), [income, expenses, rate, months]);
  const recommendations = useMemo(() => lang === "ar"
    ? [result.effectiveRate < 10 ? "رفع معدل الادخار إلى 10٪ على الأقل سيحسن المرونة المالية." : "معدل الادخار الحالي يوفر أساساً جيداً للخطة.", "أنشئ تحويلًا تلقائياً للادخار مباشرة بعد نزول الراتب.", "احتفظ بصندوق طوارئ يغطي 3–6 أشهر من المصروفات."]
    : [result.effectiveRate < 10 ? "Raising the savings rate to at least 10% would improve financial resilience." : "Your current savings rate provides a solid planning base.", "Automate the transfer immediately after income arrives.", "Maintain an emergency fund covering 3–6 months of expenses."], [lang, result.effectiveRate]);

  useEffect(() => {
    publishWidgetSnapshot({ id: "savings", title: lang === "ar" ? "إجمالي الادخار" : "Total savings", primaryValue: formatCurrency(result.totalSavings), secondaryValue: `${formatNumber(result.effectiveRate)}%`, updatedAt: new Date().toISOString(), deepLink: "/tools/savings-calculator" });
  }, [lang, result.totalSavings, result.effectiveRate]);

  return (
    <div className="tool-grid">
      <section className="tool-form-card">
        <h2 className="tool-section-title">{lang === "ar" ? "بيانات خطة الادخار" : "Savings plan inputs"}</h2>
        <div className="space-y-5">
          <NumberField label={lang === "ar" ? "الدخل الشهري" : "Monthly income"} value={income} onChange={setIncome} suffix="USD" />
          <NumberField label={lang === "ar" ? "المصروفات الشهرية" : "Monthly expenses"} value={expenses} onChange={setExpenses} suffix="USD" />
          <NumberField label={lang === "ar" ? "نسبة الادخار المستهدفة" : "Target savings rate"} value={rate} onChange={setRate} min={0} max={100} suffix="%" />
          <NumberField label={lang === "ar" ? "الفترة الزمنية" : "Time period"} value={months} onChange={setMonths} min={1} max={600} suffix={lang === "ar" ? "شهر" : "months"} />
        </div>
      </section>
      <div className="space-y-6 min-w-0">
        <section className="grid gap-4 sm:grid-cols-3">
          <MetricCard label={lang === "ar" ? "الادخار الشهري" : "Monthly savings"} value={formatCurrency(result.monthlySavings, "USD", locale)} icon={<PiggyBank className="h-4 w-4 text-gold" />} emphasis />
          <MetricCard label={lang === "ar" ? "إجمالي الادخار" : "Total savings"} value={formatCurrency(result.totalSavings, "USD", locale)} icon={<WalletCards className="h-4 w-4 text-glow" />} />
          <MetricCard label={lang === "ar" ? "المعدل الفعلي" : "Effective rate"} value={`${formatNumber(result.effectiveRate, locale)}%`} icon={<TrendingUp className="h-4 w-4 text-glow" />} />
        </section>
        <section>
          <h2 className="tool-section-title">{lang === "ar" ? "التوقع المستقبلي" : "Future projection"}</h2>
          <LineChart labels={result.projection.map((point) => point.label)} series={[{ name: lang === "ar" ? "الرصيد" : "Balance", values: result.projection.map((point) => point.value) }]} valueFormatter={(value) => formatCurrency(value, "USD", locale)} />
        </section>
        <AIInsightPanel tool={lang === "ar" ? "حاسبة الادخار" : "Savings Calculator"} metrics={{ income, expenses, savingsRate: result.effectiveRate, totalSavings: result.totalSavings }} additionalInsights={recommendations.slice(0, 1)} />
        <ReportActions toolName="Where Am I Financial Center" title={lang === "ar" ? "تقرير خطة الادخار" : "Savings plan report"} summary={lang === "ar" ? "ملخص خطة الادخار المبنية على الدخل والمصروفات والفترة الحالية." : "A summary of the savings plan based on current income, expenses, and time horizon."} userInfo={[{ label: lang === "ar" ? "الدخل الشهري" : "Monthly income", value: formatCurrency(income, "USD", locale) }, { label: lang === "ar" ? "المصروفات الشهرية" : "Monthly expenses", value: formatCurrency(expenses, "USD", locale) }, { label: lang === "ar" ? "نسبة الادخار" : "Savings rate", value: `${rate}%` }, { label: lang === "ar" ? "الفترة" : "Period", value: `${months} ${lang === "ar" ? "شهر" : "months"}` }]} metrics={[{ label: lang === "ar" ? "الادخار الشهري" : "Monthly savings", value: formatCurrency(result.monthlySavings, "USD", locale) }, { label: lang === "ar" ? "إجمالي الادخار" : "Total savings", value: formatCurrency(result.totalSavings, "USD", locale) }, { label: lang === "ar" ? "معدل الادخار" : "Savings rate", value: `${formatNumber(result.effectiveRate, locale)}%` }]} recommendations={recommendations} calculator="savings-calculator" />
      </div>
    </div>
  );
}
