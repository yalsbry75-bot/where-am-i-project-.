import { useEffect, useRef } from "react";
import { ADSENSE_CLIENT_ID } from "../../config";

interface Props {
  slotId: string;
  label?: string;
}

let scriptLoaded = false;

function loadAdsenseScript() {
  if (scriptLoaded || ADSENSE_CLIENT_ID.includes("0000000000000000")) return;
  const script = document.createElement("script");
  script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${ADSENSE_CLIENT_ID}`;
  script.async = true;
  script.crossOrigin = "anonymous";
  document.head.appendChild(script);
  scriptLoaded = true;
}

export default function AdSlot({ slotId, label = "إعلان" }: Props) {
  const ref = useRef<HTMLModElement>(null);
  const isPlaceholder = ADSENSE_CLIENT_ID.includes("0000000000000000");

  useEffect(() => {
    if (isPlaceholder) return;
    loadAdsenseScript();
    try {
      // @ts-ignore — adsbygoogle يُحقن بجافاسكربت خارجي، ما عنده types رسمية
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch {
      // تجاهل — يفشل لو السكربت لسا ما تحمّل
    }
  }, [isPlaceholder]);

  if (isPlaceholder) {
    // ⚠️ ما فيه معرّف AdSense حقيقي بعد — نعرض إطار مكانه بدل ما نخفيه بالكامل
    // عشان تصميم الصفحة يبقى صحيح لما يُفعَّل الإعلان الحقيقي لاحقاً.
    return (
      <div className="rounded-xl border border-line border-dashed py-6 text-center">
        <p className="text-[11px] text-muted/60 font-display">مساحة إعلانية ({label}) — بانتظار حساب AdSense</p>
      </div>
    );
  }

  return (
    <ins
      ref={ref}
      className="adsbygoogle block"
      style={{ display: "block" }}
      data-ad-client={ADSENSE_CLIENT_ID}
      data-ad-slot={slotId}
      data-ad-format="auto"
      data-full-width-responsive="true"
    />
  );
}
