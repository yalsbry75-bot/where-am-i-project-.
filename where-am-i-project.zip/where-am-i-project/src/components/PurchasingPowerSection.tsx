import { useEffect } from "react";
import { Smartphone, Laptop, Tv, Plane, Car, Home as HomeIcon, Lock } from "lucide-react";
import { useLanguage } from "../i18n/LanguageContext";
import { PURCHASE_ITEMS } from "../data/purchaseItems";
import { workdaysNeeded, formatWorkDuration } from "../lib/purchasingPower";
import ShareCard from "./ShareCard";
import { track } from "../lib/analytics";

const ICONS: Record<string, React.ElementType> = {
  Smartphone,
  Laptop,
  Tv,
  Plane,
  Car,
  Home: HomeIcon,
};

interface Props {
  monthlyUSD: number | null;
}

export default function PurchasingPowerSection({ monthlyUSD }: Props) {
  const { t, lang } = useLanguage();

  useEffect(() => {
    if (monthlyUSD !== null) track({ type: "calculator_used", calculator: "purchasing_power" });
  }, [monthlyUSD !== null]);

  return (
    <section id="purchasing-power" className="py-14 border-t border-line/40 scroll-mt-8">
      <h2 className="font-display font-extrabold text-2xl md:text-3xl text-center mb-2">{t.ppTitle}</h2>
      <p className="text-sm text-muted font-display text-center mb-8">{t.ppSubtitle}</p>

      {monthlyUSD === null ? (
        <div className="max-w-md mx-auto rounded-xl p-6 border border-line border-dashed text-center flex flex-col items-center gap-2">
          <Lock className="w-5 h-5 text-muted" />
          <p className="text-sm text-muted font-display">{t.ppLocked}</p>
        </div>
      ) : (
        <>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
            {PURCHASE_ITEMS.map((item) => {
              const Icon = ICONS[item.icon] ?? Smartphone;
              const days = workdaysNeeded(item.priceUSD, monthlyUSD);
              return (
                <div key={item.id} className="rounded-xl p-5 bg-panel/25 border border-line">
                  <div className="flex items-center gap-2 mb-3">
                    <Icon className="w-4 h-4 text-glow" />
                    <span className="font-display font-bold text-sm">
                      {lang === "ar" ? item.name : item.nameEn}
                    </span>
                  </div>
                  <div className="font-num font-bold text-xl text-goldBright">
                    {formatWorkDuration(days, lang)}
                  </div>
                  <div className="text-xs text-muted font-num mt-1">${item.priceUSD.toLocaleString()}</div>
                </div>
              );
            })}
          </div>
          <p className="text-[11px] text-muted/70 font-display text-center mt-6">{t.ppNote}</p>
          <ShareCard text={buildShareText(monthlyUSD, lang)} calculator="purchasing_power" />
        </>
      )}
    </section>
  );
}

function buildShareText(monthlyUSD: number, lang: "ar" | "en"): string {
  const phone = PURCHASE_ITEMS.find((i) => i.id === "phone")!;
  const days = workdaysNeeded(phone.priceUSD, monthlyUSD);
  const duration = formatWorkDuration(days, lang);
  return lang === "ar"
    ? `📱 أحتاج ${duration} بس لشراء هاتف حديث! شوف قوتك الشرائية أنت كم`
    : `📱 I only need ${duration} to buy a modern smartphone! Check your purchasing power`;
}
