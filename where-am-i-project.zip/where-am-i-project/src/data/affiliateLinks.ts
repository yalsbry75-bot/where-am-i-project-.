// ⚠️ روابط تجريبية Placeholder — لازم تُستبدل بروابط أفلييت حقيقية بعد التسجيل
// في برامج فعلية (مثال: Bayt.com للوظائف، Coursera/Udemy للتعليم، Wise/Payoneer للخدمات المالية).
// شكل الرابط أدناه (?ref=whereami) توضيحي فقط لتوضيح مكان بارامتر التتبع.

export interface AffiliateLink {
  id: string;
  category: "jobs" | "education" | "finance";
  title: string;
  titleEn: string;
  description: string;
  descriptionEn: string;
  url: string;
}

export const AFFILIATE_LINKS: AffiliateLink[] = [
  {
    id: "remote-jobs",
    category: "jobs",
    title: "فرص عمل عن بُعد",
    titleEn: "Remote job opportunities",
    description: "وظائف بدخل أعلى تقدر تشتغلها من أي مكان",
    descriptionEn: "Higher-paying jobs you can do from anywhere",
    url: "https://example.com/jobs?ref=whereami",
  },
  {
    id: "online-courses",
    category: "education",
    title: "دورات تطوّر مهاراتك",
    titleEn: "Skill-building courses",
    description: "مهارات مطلوبة بسوق العمل تزيد فرصك بدخل أعلى",
    descriptionEn: "In-demand skills that boost your income potential",
    url: "https://example.com/courses?ref=whereami",
  },
  {
    id: "money-transfer",
    category: "finance",
    title: "تحويل وإدارة أموالك دولياً",
    titleEn: "International money management",
    description: "حسابات وتحويلات بأقل رسوم لو دخلك بعملة مختلفة",
    descriptionEn: "Low-fee accounts and transfers if you earn in another currency",
    url: "https://example.com/finance?ref=whereami",
  },
];
