export interface Country {
  code: string;
  name: string;
  nameEn: string;
  currency: string;
  currencyEn: string;
  rateToUSD: number; // كم وحدة من العملة المحلية يساوي ١ دولار (تقريبي)
  avgMonthlyUSD: number; // متوسط دخل شهري تقريبي بالدولار (تقديري توضيحي)
  costOfLivingIndex: number; // مؤشر تكلفة معيشة تقريبي (نيويورك = 100، تقديري توضيحي)
  continent: string;
  continentEn: string;
}

// ⚠️ الأرقام هنا تقديرية توضيحية لأغراض العرض فقط، وليست بيانات اقتصادية رسمية.
// في مرحلة لاحقة يجب استبدالها بمصدر بيانات حي وموثوق (World Bank / Numbeo API / exchange-rate API).
export const COUNTRIES: Country[] = [
  { code: "YE", name: "اليمن", nameEn: "Yemen", currency: "ريال يمني", currencyEn: "YER", rateToUSD: 535, avgMonthlyUSD: 60, costOfLivingIndex: 20, continent: "آسيا", continentEn: "Asia" },
  { code: "SA", name: "السعودية", nameEn: "Saudi Arabia", currency: "ريال سعودي", currencyEn: "SAR", rateToUSD: 3.75, avgMonthlyUSD: 2500, costOfLivingIndex: 55, continent: "آسيا", continentEn: "Asia" },
  { code: "AE", name: "الإمارات", nameEn: "UAE", currency: "درهم إماراتي", currencyEn: "AED", rateToUSD: 3.67, avgMonthlyUSD: 3000, costOfLivingIndex: 70, continent: "آسيا", continentEn: "Asia" },
  { code: "EG", name: "مصر", nameEn: "Egypt", currency: "جنيه مصري", currencyEn: "EGP", rateToUSD: 49, avgMonthlyUSD: 250, costOfLivingIndex: 25, continent: "أفريقيا", continentEn: "Africa" },
  { code: "JO", name: "الأردن", nameEn: "Jordan", currency: "دينار أردني", currencyEn: "JOD", rateToUSD: 0.71, avgMonthlyUSD: 500, costOfLivingIndex: 40, continent: "آسيا", continentEn: "Asia" },
  { code: "IQ", name: "العراق", nameEn: "Iraq", currency: "دينار عراقي", currencyEn: "IQD", rateToUSD: 1310, avgMonthlyUSD: 400, costOfLivingIndex: 35, continent: "آسيا", continentEn: "Asia" },
  { code: "MA", name: "المغرب", nameEn: "Morocco", currency: "درهم مغربي", currencyEn: "MAD", rateToUSD: 9.7, avgMonthlyUSD: 350, costOfLivingIndex: 30, continent: "أفريقيا", continentEn: "Africa" },
  { code: "DZ", name: "الجزائر", nameEn: "Algeria", currency: "دينار جزائري", currencyEn: "DZD", rateToUSD: 134, avgMonthlyUSD: 300, costOfLivingIndex: 28, continent: "أفريقيا", continentEn: "Africa" },
  { code: "TN", name: "تونس", nameEn: "Tunisia", currency: "دينار تونسي", currencyEn: "TND", rateToUSD: 3.1, avgMonthlyUSD: 300, costOfLivingIndex: 28, continent: "أفريقيا", continentEn: "Africa" },
  { code: "KW", name: "الكويت", nameEn: "Kuwait", currency: "دينار كويتي", currencyEn: "KWD", rateToUSD: 0.31, avgMonthlyUSD: 3200, costOfLivingIndex: 60, continent: "آسيا", continentEn: "Asia" },
  { code: "QA", name: "قطر", nameEn: "Qatar", currency: "ريال قطري", currencyEn: "QAR", rateToUSD: 3.64, avgMonthlyUSD: 3500, costOfLivingIndex: 65, continent: "آسيا", continentEn: "Asia" },
  { code: "BH", name: "البحرين", nameEn: "Bahrain", currency: "دينار بحريني", currencyEn: "BHD", rateToUSD: 0.376, avgMonthlyUSD: 2000, costOfLivingIndex: 55, continent: "آسيا", continentEn: "Asia" },
  { code: "OM", name: "عمان", nameEn: "Oman", currency: "ريال عماني", currencyEn: "OMR", rateToUSD: 0.385, avgMonthlyUSD: 1800, costOfLivingIndex: 50, continent: "آسيا", continentEn: "Asia" },
  { code: "LB", name: "لبنان", nameEn: "Lebanon", currency: "دولار (نقدي)", currencyEn: "USD", rateToUSD: 1, avgMonthlyUSD: 300, costOfLivingIndex: 35, continent: "آسيا", continentEn: "Asia" },
  { code: "SD", name: "السودان", nameEn: "Sudan", currency: "جنيه سوداني", currencyEn: "SDG", rateToUSD: 600, avgMonthlyUSD: 50, costOfLivingIndex: 20, continent: "أفريقيا", continentEn: "Africa" },
  { code: "SY", name: "سوريا", nameEn: "Syria", currency: "ليرة سورية", currencyEn: "SYP", rateToUSD: 13000, avgMonthlyUSD: 60, costOfLivingIndex: 20, continent: "آسيا", continentEn: "Asia" },
  { code: "PS", name: "فلسطين", nameEn: "Palestine", currency: "شيكل", currencyEn: "ILS", rateToUSD: 3.7, avgMonthlyUSD: 400, costOfLivingIndex: 40, continent: "آسيا", continentEn: "Asia" },
  { code: "TR", name: "تركيا", nameEn: "Turkey", currency: "ليرة تركية", currencyEn: "TRY", rateToUSD: 32, avgMonthlyUSD: 700, costOfLivingIndex: 35, continent: "آسيا", continentEn: "Asia" },
  { code: "IN", name: "الهند", nameEn: "India", currency: "روبية هندية", currencyEn: "INR", rateToUSD: 83, avgMonthlyUSD: 400, costOfLivingIndex: 25, continent: "آسيا", continentEn: "Asia" },
  { code: "PK", name: "باكستان", nameEn: "Pakistan", currency: "روبية باكستانية", currencyEn: "PKR", rateToUSD: 278, avgMonthlyUSD: 250, costOfLivingIndex: 20, continent: "آسيا", continentEn: "Asia" },
  { code: "US", name: "الولايات المتحدة", nameEn: "United States", currency: "دولار أمريكي", currencyEn: "USD", rateToUSD: 1, avgMonthlyUSD: 5500, costOfLivingIndex: 70, continent: "أمريكا الشمالية", continentEn: "North America" },
  { code: "GB", name: "بريطانيا", nameEn: "United Kingdom", currency: "جنيه إسترليني", currencyEn: "GBP", rateToUSD: 0.78, avgMonthlyUSD: 4200, costOfLivingIndex: 65, continent: "أوروبا", continentEn: "Europe" },
  { code: "DE", name: "ألمانيا", nameEn: "Germany", currency: "يورو", currencyEn: "EUR", rateToUSD: 0.92, avgMonthlyUSD: 4300, costOfLivingIndex: 60, continent: "أوروبا", continentEn: "Europe" },
  { code: "FR", name: "فرنسا", nameEn: "France", currency: "يورو", currencyEn: "EUR", rateToUSD: 0.92, avgMonthlyUSD: 3800, costOfLivingIndex: 62, continent: "أوروبا", continentEn: "Europe" },
  { code: "BR", name: "البرازيل", nameEn: "Brazil", currency: "ريال برازيلي", currencyEn: "BRL", rateToUSD: 5.4, avgMonthlyUSD: 900, costOfLivingIndex: 35, continent: "أمريكا الجنوبية", continentEn: "South America" },
  { code: "NG", name: "نيجيريا", nameEn: "Nigeria", currency: "نايرا", currencyEn: "NGN", rateToUSD: 1550, avgMonthlyUSD: 250, costOfLivingIndex: 25, continent: "أفريقيا", continentEn: "Africa" },
  { code: "ZA", name: "جنوب أفريقيا", nameEn: "South Africa", currency: "راند", currencyEn: "ZAR", rateToUSD: 18.5, avgMonthlyUSD: 800, costOfLivingIndex: 30, continent: "أفريقيا", continentEn: "Africa" },
  { code: "CN", name: "الصين", nameEn: "China", currency: "يوان صيني", currencyEn: "CNY", rateToUSD: 7.2, avgMonthlyUSD: 1300, costOfLivingIndex: 40, continent: "آسيا", continentEn: "Asia" },
  { code: "JP", name: "اليابان", nameEn: "Japan", currency: "ين ياباني", currencyEn: "JPY", rateToUSD: 150, avgMonthlyUSD: 3000, costOfLivingIndex: 65, continent: "آسيا", continentEn: "Asia" },
];
