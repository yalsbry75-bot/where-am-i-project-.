import { Country } from "../data/countries";

export interface LivingBasket {
  rent: number;
  food: number;
  fuel: number;
  internet: number;
  total: number;
}

export interface LivingCountryResult {
  country: Country;
  basket: LivingBasket;
  disposableIncome: number;
  purchasingPower: number;
  affordabilityScore: number;
}

const BASE_BASKET = { rent: 1200, food: 480, fuel: 140, internet: 65 };

function regionalFactor(country: Country): number {
  switch (country.continentEn) {
    case "North America": return 1.08;
    case "Europe": return 1.02;
    case "Asia": return 0.92;
    case "Africa": return 0.82;
    case "South America": return 0.88;
    default: return 1;
  }
}

export function estimateLivingBasket(country: Country): LivingBasket {
  const indexFactor = Math.max(0.15, country.costOfLivingIndex / 70);
  const region = regionalFactor(country);
  const rent = BASE_BASKET.rent * indexFactor * region;
  const food = BASE_BASKET.food * indexFactor * (0.92 + region * 0.08);
  const fuel = BASE_BASKET.fuel * Math.sqrt(indexFactor) * (country.continentEn === "Europe" ? 1.25 : 0.9);
  const internet = BASE_BASKET.internet * (0.55 + indexFactor * 0.45);
  return { rent, food, fuel, internet, total: rent + food + fuel + internet };
}

export function rankCountriesForSalary(monthlySalaryUSD: number, countries: Country[]): LivingCountryResult[] {
  const salary = Math.max(0, monthlySalaryUSD);
  return countries
    .map((country) => {
      const basket = estimateLivingBasket(country);
      const disposableIncome = salary - basket.total;
      const purchasingPower = salary / Math.max(1, country.costOfLivingIndex / 100);
      const affordabilityScore = Math.max(0, Math.min(100, 50 + disposableIncome / Math.max(1, basket.total) * 35));
      return { country, basket, disposableIncome, purchasingPower, affordabilityScore };
    })
    .sort((a, b) => b.affordabilityScore - a.affordabilityScore);
}
