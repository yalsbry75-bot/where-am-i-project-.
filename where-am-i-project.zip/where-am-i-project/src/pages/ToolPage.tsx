import { ComponentType, LazyExoticComponent, Suspense, lazy } from "react";
import { Navigate, useParams } from "react-router-dom";
import ToolShell from "../components/ToolShell";
import { getTool } from "../data/toolRegistry";
import { useLanguage } from "../i18n/LanguageContext";
import { useSEO } from "../hooks/useSEO";

const TOOL_COMPONENTS: Record<string, LazyExoticComponent<ComponentType>> = {
  "savings-calculator": lazy(() => import("../features/tools/SavingsTool")),
  "wealth-growth": lazy(() => import("../features/tools/WealthGrowthTool")),
  "compound-interest": lazy(() => import("../features/tools/CompoundInterestTool")),
  "debt-payoff": lazy(() => import("../features/tools/DebtPayoffTool")),
  "living-comparison": lazy(() => import("../features/tools/LivingComparisonTool")),
  "global-ranking": lazy(() => import("../features/tools/GlobalRankingTool")),
  "lifestyle-insights": lazy(() => import("../features/tools/LifestyleInsightsTool")),
  "financial-journey": lazy(() => import("../features/tools/FinancialJourneyTool")),
};

export default function ToolPage() {
  const { slug } = useParams();
  const { lang } = useLanguage();
  const tool = getTool(slug);
  const ToolComponent = slug ? TOOL_COMPONENTS[slug] : undefined;

  useSEO({
    title: tool ? `${tool.title[lang]} | Where Am I` : "Where Am I",
    description: tool?.seoDescription[lang] ?? "Where Am I tools",
    path: tool ? `/tools/${tool.slug}` : "/tools",
    structuredData: tool ? {
      "@context": "https://schema.org",
      "@type": "SoftwareApplication",
      name: tool.title[lang],
      applicationCategory: "FinanceApplication",
      operatingSystem: "Web",
      description: tool.seoDescription[lang],
      offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
    } : undefined,
  });

  if (!tool || !ToolComponent) return <Navigate to="/tools" replace />;

  return (
    <ToolShell tool={tool}>
      <Suspense fallback={<div className="tool-loading"><span /><span /><span /></div>}>
        <ToolComponent />
      </Suspense>
    </ToolShell>
  );
}
