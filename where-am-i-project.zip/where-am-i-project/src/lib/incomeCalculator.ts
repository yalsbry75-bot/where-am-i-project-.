import { Country } from "../data/countries";
import { UserData } from "../types";

// نقاط توزيع الدخل العالمي (دخل سنوي بالدولار → المئين المقابل)
// ⚠️ تقديرات توضيحية لأغراض العرض، وليست بيانات اقتصادية رسمية دقيقة.
// يجب استبدالها لاحقاً بمصدر بيانات موثوق (World Inequality Database / World Bank).
export const BREAKPOINTS = [
  { pct: 1, usd: 80 },
  { pct: 5, usd: 250 },
  { pct: 10, usd: 450 },
  { pct: 20, usd: 900 },
  { pct: 30, usd: 1500 },
  { pct: 40, usd: 2300 },
  { pct: 50, usd: 3300 },
  { pct: 60, usd: 4700 },
  { pct: 70, usd: 6800 },
  { pct: 80, usd: 10500 },
  { pct: 90, usd: 19000 },
  { pct: 95, usd: 34000 },
  { pct: 99, usd: 110000 },
  { pct: 99.9, usd: 450000 },
  { pct: 100, usd: 3000000 },
];

// متوسط الدخل الشهري التقريبي لكل قارة (تقديري توضيحي)
export const CONTINENT_AVG_USD: Record<string, { ar: string; en: string; avgMonthlyUSD: number }> = {
  "آسيا": { ar: "آسيا", en: "Asia", avgMonthlyUSD: 900 },
  "أفريقيا": { ar: "أفريقيا", en: "Africa", avgMonthlyUSD: 350 },
  "أمريكا الشمالية": { ar: "أمريكا الشمالية", en: "North America", avgMonthlyUSD: 5000 },
  "أوروبا": { ar: "أوروبا", en: "Europe", avgMonthlyUSD: 4000 },
  "أمريكا الجنوبية": { ar: "أمريكا الجنوبية", en: "South America", avgMonthlyUSD: 900 },
};

export const WORLD_POPULATION = 8_100_000_000;
const GLOBAL_MEDIAN_MONTHLY_USD = 3300 / 12;

export function getGlobalPercentile(annualUSD: number): number {
  const bp = BREAKPOINTS;
  if (annualUSD <= 0) return 0;
  if (annualUSD <= bp[0].usd) return bp[0].pct * (annualUSD / bp[0].usd);
  if (annualUSD >= bp[bp.length - 1].usd) return 100;

  for (let i = 0; i < bp.length - 1; i++) {
    const a = bp[i];
    const b = bp[i + 1];
    if (annualUSD >= a.usd && annualUSD <= b.usd) {
      const t = (Math.log(annualUSD) - Math.log(a.usd)) / (Math.log(b.usd) - Math.log(a.usd));
      return a.pct + t * (b.pct - a.pct);
    }
  }
  return 50;
}

export interface IncomeResult {
  monthlyUSD: number;
  annualUSD: number;
  globalPercentile: number;
  approxPeopleBelow: number;
  countryRatioPct: number; // % فرق عن متوسط الدولة (+/-)
  continentRatioPct: number; // % فرق عن متوسط القارة (+/-)
  continentAvgUSD: number;
  globalMedianMonthlyUSD: number;
}

export function calculateIncomeResult(userData: UserData, country: Country): IncomeResult {
  const monthlyUSD = userData.monthlyIncome / country.rateToUSD;
  const annualUSD = monthlyUSD * 12;
  const globalPercentile = getGlobalPercentile(annualUSD);
  const continentInfo = CONTINENT_AVG_USD[country.continent];
  const continentAvgUSD = continentInfo ? continentInfo.avgMonthlyUSD : GLOBAL_MEDIAN_MONTHLY_USD;

  return {
    monthlyUSD,
    annualUSD,
    globalPercentile,
    approxPeopleBelow: Math.round((globalPercentile / 100) * WORLD_POPULATION),
    countryRatioPct: Math.round(((monthlyUSD - country.avgMonthlyUSD) / country.avgMonthlyUSD) * 100),
    continentRatioPct: Math.round(((monthlyUSD - continentAvgUSD) / continentAvgUSD) * 100),
    continentAvgUSD,
    globalMedianMonthlyUSD: GLOBAL_MEDIAN_MONTHLY_USD,
  };
}

export function formatApproxPeople(n: number, lang: "ar" | "en"): string {
  const billions = n / 1_000_000_000;
  const millions = n / 1_000_000;
  if (billions >= 1) {
    const v = billions.toFixed(billions >= 10 ? 0 : 1);
    return lang === "ar" ? `${v} مليار شخص` : `${v}B people`;
  }
  const v = millions.toFixed(millions >= 10 ? 0 : 1);
  return lang === "ar" ? `${v} مليون شخص` : `${v}M people`;
}
