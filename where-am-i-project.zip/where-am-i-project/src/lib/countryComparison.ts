import { Country } from "../data/countries";

export interface CountryComparisonResult {
  salaryDiffPct: number; // فرق راتب A عن B بالنسبة المئوية
  colDiffPct: number; // فرق تكلفة معيشة A عن B
  purchasingPowerA: number; // مؤشر قوة شرائية حقيقية تقريبي
  purchasingPowerB: number;
  purchasingPowerDiffPct: number;
}

export function compareCountries(a: Country, b: Country): CountryComparisonResult {
  const purchasingPowerA = a.avgMonthlyUSD / (a.costOfLivingIndex / 100);
  const purchasingPowerB = b.avgMonthlyUSD / (b.costOfLivingIndex / 100);

  return {
    salaryDiffPct: Math.round(((a.avgMonthlyUSD - b.avgMonthlyUSD) / b.avgMonthlyUSD) * 100),
    colDiffPct: Math.round(((a.costOfLivingIndex - b.costOfLivingIndex) / b.costOfLivingIndex) * 100),
    purchasingPowerA,
    purchasingPowerB,
    purchasingPowerDiffPct: Math.round(((purchasingPowerA - purchasingPowerB) / purchasingPowerB) * 100),
  };
}
